import React, { useState } from 'react';
import { Bookmark, Search, Trash2, Copy, Check, X } from 'lucide-react';
import { PinnedItem, SubjectType } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';

interface FormulaVaultModalProps {
  isOpen: boolean;
  onClose: () => void;
  pinnedItems: PinnedItem[];
  onRemoveItem: (id: string) => void;
}

export const FormulaVaultModal: React.FC<FormulaVaultModalProps> = ({
  isOpen,
  onClose,
  pinnedItems,
  onRemoveItem,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const subjects: ('All' | SubjectType)[] = [
    'All',
    'Chemistry',
    'Physics',
    'Math',
    'IT',
    'English',
  ];

  const filteredItems = pinnedItems.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === 'All' || item.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  const handleCopy = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-zinc-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-black/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-violet-500/10 border border-violet-500/30 text-violet-400">
              <Bookmark className="w-5 h-5 fill-violet-400/20" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-zinc-100 text-lg">Study Vault & JEE Cheat Notes</h3>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30">
                  {pinnedItems.length} Pinned
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Formulas, mental models, and TL;DR summaries pinned from your continuous study feed
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Subject Filter Bar */}
        <div className="p-4 border-b border-zinc-800 bg-black/40 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search pinned formulas or tricks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
            {subjects.map((sub) => (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                  selectedSubject === sub
                    ? 'bg-violet-600 text-white font-semibold'
                    : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 border border-zinc-800'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto space-y-3.5 flex-1">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 text-zinc-500">
              <Bookmark className="w-10 h-10 mx-auto text-zinc-700 mb-3" />
              <p className="text-sm font-medium text-zinc-400">No pinned formulas in this view yet</p>
              <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
                Whenever the AI explains a JEE trick, formula derivation, or TL;DR, click the <span className="text-violet-400">Pin</span> button under the response to store it here permanently!
              </p>
            </div>
          ) : (
            filteredItems.map((item) => {
              const isCopied = copiedId === item.id;
              return (
                <div
                  key={item.id}
                  className="p-4 rounded-xl bg-black border border-zinc-800 hover:border-zinc-700 transition-all flex flex-col gap-2 group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-violet-300">{item.title}</span>
                      <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-md bg-zinc-900 text-zinc-300 border border-zinc-800">
                        {item.subject}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 opacity-70 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleCopy(item.content, item.id)}
                        className="p-1 rounded text-zinc-400 hover:text-cyan-300 transition-colors"
                        title="Copy note"
                      >
                        {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="p-1 rounded text-zinc-500 hover:text-rose-400 transition-colors"
                        title="Unpin note"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="text-xs text-zinc-300 leading-relaxed bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/80 overflow-x-auto">
                    <MarkdownRenderer content={item.content} />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-zinc-800 bg-black/80 flex items-center justify-between text-xs text-zinc-400">
          <span>Synced locally & on your continuous study server</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
