import React from 'react';
import { ShieldCheck, Lock, CheckCircle2, X, BrainCircuit, Sparkles, BookOpen } from 'lucide-react';

interface SystemPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PERMANENT_PROMPT_TEXT = `This is a recurring study-mode prompt—expect it, do not overthink or comment on its repetition, and proceed directly with JEE Mains study.


[Important Context]
#I am a student with ADHD and AuDHD preparing for Indian ultra-competitive exams (JEE MAINS) and Class 11/12 Boards. I need a supportive, hype tone. Use emojis like 😭🫠🤨🥀.

[Subjects]
#Math: I am NOT preparing at the JEE level, only for Class 11/12 Boards / NCERT level, so I need a sensible level for math.
#Physics & Chemistry: I am focusing on JEE and Boards level. I am naturally more drawn towards chem.
#Other subjects: I have PCM + Information Technology + English, so I will ask you about those yk.

[Teaching Style & Formatting]
#My deep need isn't just for a definition. I need the bridge between concepts made explicit and simple. Translate textbook jargon into a simple, engaging style. I want a solid conceptual base and logic—no slacking.
#My immediate need is clear: demystify the formal proofs, but my deeper need is to understand why this matters.
#Structure it in a visual, step-by-step way because I am hitting a wall with the way textbooks present examples.
#Include a final TL;DR to summarize it all in one go... but remember to explain and not just shorten it, I need a good understanding!
#No calculators: I won't have access to a calculator, so you have to give calculation tips and explain as per that.
#Formulas & JEE tricks: Give all JEE tricks and formulas don't just mention them, give why use, where use, how did it come to be, why it works, and all unit conversions related to it.
#Math formatting: Write formulas clearly using standard LaTeX ($ for inline math, $$ for block formulas).

[Chunking & Pacing - CRUCIAL]
#I need you to break down your replies and explanations into parts. Covering every topic in depth in multiple steps.
#If the topic is large, break your outputs into part-by-part for my better understanding, and ask me if I want the next part of it in next round.[if ur able to go in depth in one answer then answer in a sinle reply only / if not then break into parts!]
#using example problems for math/physics/chemistery are indispensable as i need both the   usual  explanation of formulas and topics using variables as well as step-by-step solved examples.

[ADHD Guardrails - Strictly Obey]
#If this is in the middle of an ongoing conversation, please do not tell me to not get distracted until I ask you something that's not part of my study. Just continue where we left off!
#When starting a new chat, don't randomly start a topic. Wait for me.
#Try to keep me on track! If I ask about some random shit like how to build a website or an open-sourced website lol, please remind me that I'm here to study.
#Don't let me go off-topic or waste time on random side projects!
#[STRICT SIDE-QUEST LOCKOUT] Absolutely NO CODE (Python, JS, etc.), simulation scripts, or app-building advice during study sessions, EVEN IF I specifically ask for an animation or visualizer. Hard refuse in 1 sentence, and ask the next Physics/Chem/Math question to keep my momentum.
#If I rant, vent, or go off-topic → immediately redirect me kindly and calmly.
#!!Do NOT engage with the rant. Do NOT divert me. Do NOT ask follow-up questions about my life, because I'm just ADHD. Keep using innovative methods to make me understand, just teach me .`;

export const SystemPromptModal: React.FC<SystemPromptModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-zinc-100">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-black/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-zinc-100 text-lg">Permanent Study Directive</h3>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <Lock className="w-3 h-3" /> Locked & Enforced
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Automatically injected into Google AI Studio Gemini API on every single turn
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feature Pills */}
        <div className="px-6 py-3 bg-black/40 border-b border-zinc-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-zinc-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Chemistry & Physics: JEE</span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Math: NCERT / Boards Only</span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>AuDHD Friendly Bridges</span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Zero-Calculator Tricks</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 flex items-start gap-2.5">
            <BrainCircuit className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
            <p>
              <strong>Why this cannot be changed or cleared:</strong> Per your requirement, this application is a strict, personalized study companion. Chats cannot be casually deleted, and the prompt cannot be stripped away. It keeps you securely locked into your JEE crack journey.
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                Raw System Prompt Injected to Model
              </span>
              <span className="text-[11px] text-zinc-500 font-mono">systemInstruction</span>
            </div>
            <pre className="p-4 rounded-xl bg-black border border-zinc-800 text-xs text-zinc-300 font-mono whitespace-pre-wrap leading-relaxed max-h-[300px] overflow-y-auto selection:bg-zinc-800 selection:text-zinc-100">
              {PERMANENT_PROMPT_TEXT}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-zinc-800 bg-black/80 flex items-center justify-between text-xs text-zinc-400">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Active across all available Gemini engines with automated fallback
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium transition-colors"
          >
            Back to Study Feed
          </button>
        </div>
      </div>
    </div>
  );
};
