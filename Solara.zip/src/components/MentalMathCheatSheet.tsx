import React, { useState } from 'react';
import { Calculator, X, Sparkles, Copy, Check, Zap, Lightbulb } from 'lucide-react';

interface MentalMathCheatSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MentalMathCheatSheet: React.FC<MentalMathCheatSheetProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const sections = [
    {
      title: '⚡ JEE Mains Physical Constants (Calculation Hacks)',
      items: [
        { label: 'Planck × Light Speed (hc)', val: '1240 eV·nm  or  12400 eV·Å', hint: 'Use directly in photo-electric & Bohr model! Don\'t multiply h and c!' },
        { label: 'Gas Constant (R in Joules)', val: 'R ≈ 25/3 ≈ 8.314 J/(mol·K)', hint: 'Multiply by 25 and divide by 3 instead of 8.314' },
        { label: 'Gas Constant (R in L·atm)', val: 'R ≈ 1/12 ≈ 0.0821 L·atm/(mol·K)', hint: 'Divide by 12 instead of multiplying 0.0821' },
        { label: 'Electrostatic (1 / 4πε₀)', val: '9 × 10⁹ N·m²/C²', hint: 'Standard JEE plug-and-chug' },
        { label: 'Faraday Constant (F)', val: '96500 C/mol e⁻', hint: 'Q = I × t / 96500' },
        { label: 'g vs π²', val: 'g ≈ 9.8 m/s² ≈ π² (≈ 9.87)', hint: 'In pendulum & gravity questions, g and π² often cancel out!' },
      ],
    },
    {
      title: '📈 Logarithms Memorization (The JEE Must-Knows)',
      items: [
        { label: 'log₁₀(2)', val: '0.3010  (≈ 0.30)', hint: 'Half-life: t½ = 0.693/k = 2.303×0.301/k' },
        { label: 'log₁₀(3)', val: '0.4771  (≈ 0.48)', hint: 'Helps find log(6) = log 2 + log 3 ≈ 0.78' },
        { label: 'log₁₀(5)', val: '0.6990  (≈ 0.70)', hint: 'log 5 = 1 - log 2 = 1 - 0.301 = 0.699' },
        { label: 'log₁₀(7)', val: '0.8450  (≈ 0.85)', hint: 'Crucial for radio-decay & pH problems' },
        { label: 'ln(x) to log₁₀(x)', val: 'ln(x) = 2.303 × log₁₀(x)', hint: '2.303 × R ≈ 19.14 J/mol·K' },
        { label: 'pH estimation', val: 'pH = -log[H⁺] = n - log(m) for m×10⁻ⁿ', hint: 'Example: 4×10⁻⁵ M -> pH = 5 - log 4 = 5 - 0.60 = 4.40' },
      ],
    },
    {
      title: '🧮 Fast Mental Math Fractions & Roots',
      items: [
        { label: '√2 & √3', val: '√2 ≈ 1.414, √3 ≈ 1.732', hint: '1/√2 ≈ 0.707, 1/√3 ≈ 0.577' },
        { label: '1 / 7', val: '≈ 0.1428', hint: 'Repeatable: 14, 28, 57...' },
        { label: '1 / 8 & 1 / 16', val: '0.125 & 0.0625', hint: 'Helps in mole concept and stoichiometry' },
        { label: 'Binomial approx', val: '(1 + x)ⁿ ≈ 1 + nx  (when x << 1)', hint: 'Saves 5 minutes on thermal expansion & error analysis' },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-zinc-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-black/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-zinc-100 text-lg">No-Calculator JEE Hacks</h3>
                <span className="text-[11px] font-semibold uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Exam Ready
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                Mental math shortcuts for JEE Mains (Where calculators are strictly prohibited)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="px-6 py-3 bg-zinc-900 border-b border-zinc-800 flex items-start gap-2.5 text-xs text-amber-200">
          <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            Every explanation from your AI tutor breaks down calculations using these tricks so you never get stuck solving long decimals during the actual exam.
          </p>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {sections.map((section, idx) => (
            <div key={idx} className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                {section.title}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {section.items.map((item, itemIdx) => {
                  const key = `${idx}-${itemIdx}`;
                  const isCopied = copiedKey === key;
                  return (
                    <div
                      key={itemIdx}
                      className="p-3 rounded-xl bg-black border border-zinc-800/90 hover:border-zinc-700 transition-all flex flex-col justify-between group"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-xs font-semibold text-zinc-300">{item.label}</span>
                        <button
                          onClick={() => handleCopy(item.val, key)}
                          className="opacity-60 group-hover:opacity-100 transition-opacity text-zinc-400 hover:text-cyan-300"
                          title="Copy to clipboard"
                        >
                          {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <div className="font-mono text-sm font-bold text-cyan-300 my-1">
                        {item.val}
                      </div>
                      <p className="text-[11px] text-zinc-400 leading-snug">
                        {item.hint}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-zinc-800 bg-black/80 flex items-center justify-between text-xs text-zinc-400">
          <span className="flex items-center gap-1.5 text-zinc-400">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            Tip: You can ask the AI "Break this down with mental math tricks" anytime!
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
