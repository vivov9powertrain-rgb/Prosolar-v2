import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Flame, Coffee, Settings2, Bell, Check, ChevronDown, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface FocusTimerProps {
  onSessionComplete?: () => void;
}

// Clean Web Audio API synthesis for a crystalline focus chime / ping (Zero external mp3 dependencies)
const playTimerPing = () => {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const now = ctx.currentTime;

    // Harmonic crystalline bell ping: 880Hz (A5) -> 1760Hz (A6) with exponential decay
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.exponentialRampToValueAtTime(1760, now + 0.12);
    gain1.gain.setValueAtTime(0.35, now);
    gain1.gain.exponentialRampToValueAtTime(0.0001, now + 1.4);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 1.4);

    // Subtle resonance harmonic
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1320, now + 0.05); // E6
    gain2.gain.setValueAtTime(0.18, now + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.0001, now + 1.5);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.05);
    osc2.stop(now + 1.5);
  } catch (err) {
    console.log('Audio playback error:', err);
  }
};

export const FocusTimer: React.FC<FocusTimerProps> = ({ onSessionComplete }) => {
  // Load saved study duration (default 25 min)
  const [studyMinutes, setStudyMinutes] = useState<number>(() => {
    const saved = localStorage.getItem('focus_study_duration_min');
    return saved ? Math.max(1, parseInt(saved, 10)) : 25;
  });

  const [timeLeft, setTimeLeft] = useState<number>(() => {
    const saved = localStorage.getItem('focus_study_duration_min');
    const mins = saved ? Math.max(1, parseInt(saved, 10)) : 25;
    return mins * 60;
  });

  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [isAdjustOpen, setIsAdjustOpen] = useState<boolean>(false);
  const [customInputMins, setCustomInputMins] = useState<string>('');
  const [pingPlayed, setPingPlayed] = useState<boolean>(false);
  const [streakCount, setStreakCount] = useState<number>(() => {
    return parseInt(localStorage.getItem('focus_streak') || '0', 10);
  });

  const popoverRef = useRef<HTMLDivElement>(null);

  // Close adjustment popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        setIsAdjustOpen(false);
      }
    };
    if (isAdjustOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isAdjustOpen]);

  // Timer countdown loop
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (isRunning && timeLeft === 0) {
      // Play timer completion ping sound!
      playTimerPing();
      setPingPlayed(true);
      setTimeout(() => setPingPlayed(false), 3000);

      if (mode === 'study') {
        const newStreak = streakCount + 1;
        setStreakCount(newStreak);
        localStorage.setItem('focus_streak', newStreak.toString());
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 },
          });
        } catch (_) {}

        // Break duration scaled to study length (5 min for short, 10 min for 60m+)
        const breakDurationSec = studyMinutes >= 60 ? 10 * 60 : 5 * 60;
        setMode('break');
        setTimeLeft(breakDurationSec);
        onSessionComplete?.();
      } else {
        setMode('study');
        setTimeLeft(studyMinutes * 60);
      }
      setIsRunning(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft, mode, streakCount, studyMinutes, onSessionComplete]);

  const toggleTimer = () => {
    // Warm up audio context on user click to prevent mobile browser autoplay blocks
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const tempCtx = new AudioCtx();
        if (tempCtx.state === 'suspended') tempCtx.resume();
      }
    } catch (_) {}

    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    if (mode === 'study') {
      setTimeLeft(studyMinutes * 60);
    } else {
      const breakDurationSec = studyMinutes >= 60 ? 10 * 60 : 5 * 60;
      setTimeLeft(breakDurationSec);
    }
  };

  // Set new custom study duration
  const applyDuration = (mins: number) => {
    const validMins = Math.max(1, Math.min(240, mins));
    setStudyMinutes(validMins);
    localStorage.setItem('focus_study_duration_min', validMins.toString());
    if (mode === 'study') {
      setTimeLeft(validMins * 60);
      setIsRunning(false);
    }
    setIsAdjustOpen(false);
    setCustomInputMins('');
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(customInputMins, 10);
    if (!isNaN(parsed) && parsed > 0) {
      applyDuration(parsed);
    }
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  const totalDuration = mode === 'study' ? studyMinutes * 60 : (studyMinutes >= 60 ? 10 * 60 : 5 * 60);
  const progressPercent = Math.min(100, Math.max(0, ((totalDuration - timeLeft) / totalDuration) * 100));

  const PRESET_OPTIONS = [25, 34, 45, 60, 90];

  return (
    <div className="relative flex items-center gap-2.5 sm:gap-3 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-xs select-none">
      {/* Mode & Adjustable Time Display */}
      <button
        onClick={() => setIsAdjustOpen(!isAdjustOpen)}
        className="flex items-center gap-1.5 font-semibold text-zinc-300 hover:text-white transition-colors cursor-pointer group"
        title="Click to adjust focus timer duration (e.g. 25m, 34m, 45m, 90m)"
      >
        {mode === 'study' ? (
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Sprint
          </span>
        ) : (
          <span className="flex items-center gap-1 text-sky-400">
            <Coffee className="w-3.5 h-3.5" />
            Break
          </span>
        )}
        <span className="font-mono text-zinc-100 font-bold ml-1 group-hover:text-cyan-300 transition-colors">
          {formattedTime}
        </span>
        <ChevronDown className="w-3 h-3 text-zinc-500 group-hover:text-cyan-400 transition-transform" />
      </button>

      {/* Progress mini bar */}
      <div className="w-10 sm:w-12 h-1.5 rounded-full bg-zinc-800 overflow-hidden hidden sm:block">
        <div
          className={`h-full transition-all duration-300 ${mode === 'study' ? 'bg-emerald-500' : 'bg-sky-500'}`}
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Play/Pause & Reset Controls */}
      <div className="flex items-center gap-1">
        <button
          onClick={toggleTimer}
          className="p-1 rounded-full text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
          title={isRunning ? 'Pause Timer' : 'Start Focus Timer'}
        >
          {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
        </button>
        <button
          onClick={resetTimer}
          className="p-1 rounded-full text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 transition-colors"
          title="Reset Timer"
        >
          <RotateCcw className="w-3 h-3" />
        </button>
      </div>

      {/* Streak Indicator */}
      {streakCount > 0 && (
        <div className="flex items-center gap-1 pl-2 border-l border-zinc-800 text-amber-400 font-semibold">
          <Flame className="w-3.5 h-3.5 fill-amber-400" />
          <span>{streakCount}</span>
        </div>
      )}

      {/* Duration Customization Popover */}
      {isAdjustOpen && (
        <div
          ref={popoverRef}
          className="absolute top-full mt-2 left-0 sm:left-auto sm:right-0 w-64 p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl z-50 text-zinc-200 animate-in fade-in zoom-in-95 duration-150"
        >
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800 mb-2.5">
            <div className="flex items-center gap-1.5 font-bold text-xs text-zinc-100">
              <Settings2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Set Sprint Duration</span>
            </div>
            <button
              onClick={playTimerPing}
              className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-cyan-300 transition-colors p-1 rounded hover:bg-zinc-900"
              title="Test completion chime ping"
            >
              <Bell className="w-3 h-3 text-cyan-400" />
              <span>Test Ping</span>
            </button>
          </div>

          {/* Quick Presets */}
          <div className="text-[11px] font-medium text-zinc-400 mb-1.5">Quick Presets:</div>
          <div className="grid grid-cols-5 gap-1.5 mb-3">
            {PRESET_OPTIONS.map((mins) => (
              <button
                key={mins}
                onClick={() => applyDuration(mins)}
                className={`py-1 rounded-lg text-xs font-semibold transition-all border ${
                  studyMinutes === mins
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                    : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border-zinc-800'
                }`}
              >
                {mins}m
              </button>
            ))}
          </div>

          {/* Custom Duration Input */}
          <form onSubmit={handleCustomSubmit} className="space-y-2">
            <div className="text-[11px] font-medium text-zinc-400">Custom Minutes:</div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="240"
                placeholder={studyMinutes.toString()}
                value={customInputMins}
                onChange={(e) => setCustomInputMins(e.target.value)}
                autoFocus
                className="w-full px-2.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-100 focus:outline-none focus:border-cyan-500 font-mono"
              />
              <button
                type="submit"
                disabled={!customInputMins || parseInt(customInputMins, 10) <= 0}
                className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-xs font-semibold text-white transition-colors"
              >
                Set
              </button>
            </div>
            <p className="text-[10px] text-zinc-500 leading-tight">
              Adjust to any length (e.g. 34m, 45m, 90m). Plays a crystalline ping when time finishes.
            </p>
          </form>
        </div>
      )}
    </div>
  );
};
