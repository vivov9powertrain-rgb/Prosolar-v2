import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  ShieldCheck,
  Zap,
  Bookmark,
  Calculator,
  Send,
  Milestone,
  BookOpen,
  Atom,
  Check,
  Copy,
  Plus,
  Flame,
  Filter,
  Paperclip,
  Image as ImageIcon,
  FileText,
  X,
  Maximize2,
  FileCheck,
  Eraser,
  Trash2,
  Cpu,
  Volume2,
  VolumeX,
  Globe,
  Pause,
  Play,
  Activity,
  Edit3,
  Search,
  GripVertical,
  Download,
  Upload,
  RotateCcw,
} from 'lucide-react';
import { Reorder } from 'motion/react';
import { ChatMessage, PinnedItem, SubjectType, ModelPreference, AttachmentItem } from './types';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { SystemPromptModal } from './components/SystemPromptModal';
import { FormulaVaultModal } from './components/FormulaVaultModal';
import { FocusTimer } from './components/FocusTimer';
import { MiniPromptDrawer } from './components/MiniPromptDrawer';
import { AuthGateModal } from './components/AuthGateModal';
import { sanitizeForSpeech, splitIntoSpeechChunks } from './utils/speechSanitizer';

const ThoughtSection: React.FC<{ thought: string; isLive?: boolean }> = ({ thought, isLive = false }) => {
  const [isOpen, setIsOpen] = useState(isLive);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isLive) {
      setIsOpen(true);
    }
  }, [isLive]);

  useEffect(() => {
    if (isLive && isOpen && contentRef.current) {
      contentRef.current.scrollTop = contentRef.current.scrollHeight;
    }
  }, [thought, isLive, isOpen]);

  return (
    <div className={`mb-3 rounded-xl border transition-all ${isLive ? 'border-purple-500/40 bg-purple-950/20 shadow-sm' : 'border-zinc-800 bg-zinc-950/40'} p-2.5 text-xs text-zinc-400`}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 font-medium text-zinc-300 hover:text-white transition-colors w-full text-left cursor-pointer"
      >
        <span className="text-sm">🧠</span>
        <span className="text-[11px] uppercase tracking-wider font-semibold flex-1 flex items-center gap-1.5 text-purple-300">
          <span>{isLive ? 'Deep Reasoning Active' : 'Thinking Process'}</span>
          {isLive && <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping inline-block" />}
        </span>
        <span className="text-[10px] text-zinc-500 font-mono">{isOpen ? '▲ Hide' : '▼ Show'}</span>
      </button>
      {isOpen && (
        <div
          ref={contentRef}
          className="mt-2.5 pl-3 border-l-2 border-purple-500/50 text-zinc-300 leading-relaxed text-[11px] whitespace-pre-wrap max-h-72 overflow-y-auto font-mono/relaxed bg-black/30 p-2 rounded-r-lg"
        >
          {thought}
        </div>
      )}
    </div>
  );
};

const INITIAL_GREETING_MESSAGE: ChatMessage = {
  id: 'init-1',
  role: 'model',
  text: `### 🚀 Continuous JEE Study Journal 🧪✨

Your **permanent strict study directive** is locked and enforced on every single turn:
- **Chemistry & Physics**: Deep conceptual bridges, demystified proofs, visual step-by-step logic, and supportive hype tone for **JEE Mains**. 🧪⚡
- **Math**: Sensibly anchored at **Class 11/12 Boards & NCERT level** (no overcomplicated JEE rabbit holes). 📐
- **No-Calculator Tricks**: Mental math shortcuts, log approximations, and physical constant tricks provided on every numerical problem. 🧮
- **AuDHD Redirect Guard**: Tangents or 40-tab rants get kindly and calmly redirected back to study mode. 🚨🥀
- **Multimodal Ready**: Paste diagrams, question paper screenshots, or textbook PDFs directly into the text box.

**Zero chats get wiped or deleted.** What topic are we breaking down today?`,
  timestamp: Date.now(),
  subject: 'General',
  modelUsed: 'Gemini 3.8 Flash (Auto Cascade)',
};

const RETENTION_6_DAYS_MS = 6 * 24 * 60 * 60 * 1000;

export const HYDROGEN_4_MODEL = 'gemini-4-hydrogen';
export const FLASH_36_MODEL = 'gemini-3.6-flash';

export const FLASH_CASCADE = [
  'gemini-flash-latest',
  HYDROGEN_4_MODEL,
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-flash-lite-latest',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemma-4-26b-a4b-it',
  'gemma-4-31b-it',
];

export const FLASH_LITE_CASCADE = [
  'gemini-flash-lite-latest',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-flash-latest',
  HYDROGEN_4_MODEL,
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemma-4-26b-a4b-it',
  'gemma-4-31b-it',
];

export type GeminiCascadeKey = 'auto' | 'flash-lite' | 'flash' | 'gemma' | 'thinkHarder';
export type ThinkingTierKey = 'xhigh' | 'high';
export type CascadeEditorTab = GeminiCascadeKey | 'think-xhigh' | 'think-high' | 'groq';

export const DEFAULT_GROQ_MODELS = [
  'openai/gpt-oss-120b',
  'qwen/qwen3.8-27b',
];

export const DEFAULT_GEMINI_CASCADES: Record<GeminiCascadeKey, string[]> = {
  'auto': [...FLASH_LITE_CASCADE],
  'flash-lite': [...FLASH_LITE_CASCADE],
  'flash': [...FLASH_CASCADE],
  'gemma': [
    'gemma-4-26b-a4b-it',
    'gemma-4-31b-it',
    'gemini-flash-lite-latest',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-flash-latest',
    HYDROGEN_4_MODEL,
    'gemini-3.8-flash',
    'gemini-3.6-flash',
  ],
  'thinkHarder': [
    HYDROGEN_4_MODEL,
    'gemini-3.8-flash',
    'gemini-flash-latest',
    'gemini-3.6-flash',
    'gemini-flash-lite-latest',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemma-4-26b-a4b-it',
    'gemma-4-31b-it',
  ],
};

export const DEFAULT_THINKING_LEVELS: Record<ThinkingTierKey, string[]> = {
  'xhigh': [HYDROGEN_4_MODEL],
  'high': [
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-flash-latest',
    'gemini-flash-lite-latest',
  ],
};

const normalizeClientModelId = (raw: string): string => {
  const cleaned = raw.trim().replace(/^models\//i, '');
  if (/^gemini_/i.test(cleaned)) {
    return cleaned.replace(/_/g, '-');
  }
  return cleaned;
};

// 1. Put this helper outside the component to handle Pacific Time midnight resets
const getPTDateString = () => {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Los_Angeles',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
};

const CASCADE_STORAGE_KEY = 'focus_jee_cascade_config';

interface StoredCascadeConfig {
  cascades: Record<GeminiCascadeKey, string[]>;
  thinkingLevels: Record<ThinkingTierKey, string[]>;
  groqModels: string[];
  updatedAt: number;
}

const readCascadeConfigFromLocalStorage = (): StoredCascadeConfig | null => {
  try {
    const raw = localStorage.getItem(CASCADE_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    const cascadeKeys: GeminiCascadeKey[] = ['auto', 'flash-lite', 'flash', 'gemma', 'thinkHarder'];
    const cascades: Record<GeminiCascadeKey, string[]> = {
      'auto': Array.isArray(parsed?.cascades?.['auto']) ? parsed.cascades['auto'] : [...DEFAULT_GEMINI_CASCADES['auto']],
      'flash-lite': Array.isArray(parsed?.cascades?.['flash-lite']) ? parsed.cascades['flash-lite'] : [...DEFAULT_GEMINI_CASCADES['flash-lite']],
      'flash': Array.isArray(parsed?.cascades?.['flash']) ? parsed.cascades['flash'] : [...DEFAULT_GEMINI_CASCADES['flash']],
      'gemma': Array.isArray(parsed?.cascades?.['gemma']) ? parsed.cascades['gemma'] : [...DEFAULT_GEMINI_CASCADES['gemma']],
      'thinkHarder': Array.isArray(parsed?.cascades?.['thinkHarder']) ? parsed.cascades['thinkHarder'] : [...DEFAULT_GEMINI_CASCADES['thinkHarder']],
    };
    const hasAllKeys = parsed.cascades && cascadeKeys.every((k) => Array.isArray(parsed.cascades[k]));
    if (!hasAllKeys) return null;
    const thinkingLevels: Record<ThinkingTierKey, string[]> = {
      'xhigh': Array.isArray(parsed?.thinkingLevels?.xhigh) ? parsed.thinkingLevels.xhigh : [...DEFAULT_THINKING_LEVELS['xhigh']],
      'high': Array.isArray(parsed?.thinkingLevels?.high) ? parsed.thinkingLevels.high : [...DEFAULT_THINKING_LEVELS['high']],
    };
    const groqModels = Array.isArray(parsed?.groqModels) ? parsed.groqModels : [...DEFAULT_GROQ_MODELS];
    const updatedAt = typeof parsed?.updatedAt === 'number' && Number.isFinite(parsed.updatedAt) ? parsed.updatedAt : 0;
    return { cascades, thinkingLevels, groqModels, updatedAt };
  } catch (_) {
    return null;
  }
};

const writeCascadeConfigToLocalStorage = (cfg: StoredCascadeConfig) => {
  try {
    localStorage.setItem(CASCADE_STORAGE_KEY, JSON.stringify(cfg));
  } catch (_) {}
};

export interface ModelHealthResponse {
  timestamp: number;
  status: 'healthy' | 'warning';
  totalAvailableUpstream: number;
  active: string[];
  deprecated_or_missing: string[];
  disabledInSession: string[];
}

export default function App() {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('focus_jee_messages');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const now = Date.now();
          const pruned = parsed.filter(m => !m.timestamp || (now - m.timestamp <= RETENTION_6_DAYS_MS));
          return pruned.length > 0 ? pruned : [INITIAL_GREETING_MESSAGE];
        }
      }
    } catch (_) {}
    return [INITIAL_GREETING_MESSAGE];
  });

  const [pinnedVault, setPinnedVault] = useState<PinnedItem[]>(() => {
    try {
      const saved = localStorage.getItem('focus_jee_vault');
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return [];
  });

  const [inputPrompt, setInputPrompt] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<AttachmentItem[]>([]);
  const [activeSubjectFilter, setActiveSubjectFilter] = useState<SubjectType | 'All'>('All');
  const [currentSubject, setCurrentSubject] = useState<SubjectType>('Chemistry');
  const [modelPreference, setModelPreference] = useState<ModelPreference>('auto');
  const [thinkHarder, setThinkHarder] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('focus_jee_think_harder');
      if (saved !== null) return JSON.parse(saved);
    } catch (_) {}
    return false;
  });

  useEffect(() => {
    localStorage.setItem('focus_jee_think_harder', JSON.stringify(thinkHarder));
  }, [thinkHarder]);

  const [isLoading, setIsLoading] = useState(false);
  const [activeStreamingText, setActiveStreamingText] = useState('');
  const [activeModelUsed, setActiveModelUsed] = useState<string>('gemini-flash-lite-latest');
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);

  // 2. Add accordion state inside the component
  const [expandedProviders, setExpandedProviders] = useState<Record<string, boolean>>({
    'Google AI Studio': true,
    'Groq': true,
    'OpenRouter': true,
    'BazaarLink': true
  });

  const toggleProvider = (provider: string) => {
    setExpandedProviders(prev => ({ ...prev, [provider]: !prev[provider] }));
  };

  // Modals & previews
  const [isSystemPromptOpen, setIsSystemPromptOpen] = useState(false);
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isMilestoneModalOpen, setIsMilestoneModalOpen] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [milestoneTitleInput, setMilestoneTitleInput] = useState('');
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [deletingMessageId, setDeletingMessageId] = useState<string | null>(null);
  const [isQuotaPopupOpen, setIsQuotaPopupOpen] = useState(false);
  const [isMiniPromptOpen, setIsMiniPromptOpen] = useState(false);
  const miniPromptTriggerRef = useRef<HTMLButtonElement>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const abortControllerRef = useRef<AbortController | null>(null);
  const isUserAbortedRef = useRef<boolean>(false);
  const [chatSearchQuery, setChatSearchQuery] = useState('');
  const [isChatSearchOpen, setIsChatSearchOpen] = useState(false);
  const chatSearchInputRef = useRef<HTMLInputElement>(null);
  const [authToken, setAuthToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem('study_auth_token');
    } catch (_) {
      return null;
    }
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(true);

  const getAuthHeaders = (): Record<string, string> => {
    const token = authToken || (typeof localStorage !== 'undefined' ? localStorage.getItem('study_auth_token') : '') || '';
    return {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    };
  };

  const [historyLimit, setHistoryLimit] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('focus_jee_history_limit');
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (parsed >= 1 && parsed <= 20) return parsed;
      }
    } catch (_) {}
    return 12; // default to a very comfortable 12 messages history
  });

  useEffect(() => {
    localStorage.setItem('focus_jee_history_limit', String(historyLimit));
  }, [historyLimit]);

  // Purely Local Text Size Scaling Level (1 = Comfort, 2 = Large +15%, 3 = Extra Large +30%)
  const [textSizeLevel, setTextSizeLevel] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('focus_jee_text_size_level');
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (parsed >= 1 && parsed <= 3) return parsed;
      }
    } catch (_) {}
    return 1;
  });

  useEffect(() => {
    localStorage.setItem('focus_jee_text_size_level', String(textSizeLevel));
  }, [textSizeLevel]);

  // Hidden Model Deprecation & Health Checker state
  const [isHealthModalOpen, setIsHealthModalOpen] = useState(false);
  const [healthData, setHealthData] = useState<ModelHealthResponse | null>(null);
  const [isCheckingHealth, setIsCheckingHealth] = useState(false);
  const [copiedHealthPrompt, setCopiedHealthPrompt] = useState(false);
  const [titleClickCount, setTitleClickCount] = useState(0);
  const [confirmClearDisabled, setConfirmClearDisabled] = useState(false);
  const [isClearingDisabled, setIsClearingDisabled] = useState(false);
  const [disabledResetNotice, setDisabledResetNotice] = useState<string | null>(null);

  // Persistent Gemini Cascades & Thinking-Level Editor state
  const initialStoredCascadeRef = useRef<StoredCascadeConfig | null>(readCascadeConfigFromLocalStorage());
  const [geminiCascades, setGeminiCascades] = useState<Record<GeminiCascadeKey, string[]>>(() =>
    initialStoredCascadeRef.current
      ? initialStoredCascadeRef.current.cascades
      : {
          'auto': [...DEFAULT_GEMINI_CASCADES['auto']],
          'flash-lite': [...DEFAULT_GEMINI_CASCADES['flash-lite']],
          'flash': [...DEFAULT_GEMINI_CASCADES['flash']],
          'gemma': [...DEFAULT_GEMINI_CASCADES['gemma']],
          'thinkHarder': [...DEFAULT_GEMINI_CASCADES['thinkHarder']],
        }
  );
  const [geminiThinkingLevels, setGeminiThinkingLevels] = useState<Record<ThinkingTierKey, string[]>>(() =>
    initialStoredCascadeRef.current
      ? initialStoredCascadeRef.current.thinkingLevels
      : {
          'xhigh': [...DEFAULT_THINKING_LEVELS['xhigh']],
          'high': [...DEFAULT_THINKING_LEVELS['high']],
        }
  );
  const [groqModels, setGroqModels] = useState<string[]>(() =>
    initialStoredCascadeRef.current ? initialStoredCascadeRef.current.groqModels : [...DEFAULT_GROQ_MODELS]
  );
  const cascadeUpdatedAtRef = useRef<number>(initialStoredCascadeRef.current?.updatedAt || 0);
  const [isCascadeModalOpen, setIsCascadeModalOpen] = useState(false);
  const [activeEditorTab, setActiveEditorTab] = useState<CascadeEditorTab>('auto');
  const [newModelInput, setNewModelInput] = useState('');
  const [addPosition, setAddPosition] = useState<'top' | 'end'>('top');
  const [addThinkingChoice, setAddThinkingChoice] = useState<'unchanged' | 'high' | 'xhigh'>('unchanged');
  const [cascadeSaving, setCascadeSaving] = useState(false);
  const [cascadeNotice, setCascadeNotice] = useState<string | null>(null);
  const latestCascadesRef = useRef(geminiCascades);
  const latestThinkingLevelsRef = useRef(geminiThinkingLevels);
  const latestGroqModelsRef = useRef(groqModels);
  const dragOrderChangedRef = useRef(false);
  const cascadeImportInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    latestCascadesRef.current = geminiCascades;
  }, [geminiCascades]);

  useEffect(() => {
    latestThinkingLevelsRef.current = geminiThinkingLevels;
  }, [geminiThinkingLevels]);

  useEffect(() => {
    latestGroqModelsRef.current = groqModels;
  }, [groqModels]);

  // Normalize and map any incoming model name or version into exact tracking IDs
  const getTrackingModelKey = (rawModel: string): string => {
    const lower = (rawModel || '').toLowerCase();
    if (lower.includes('bzl') || lower.includes('bazaarlink')) return 'bzl';
    if (lower.includes('openrouter')) return 'openrouter';
    if (lower.includes('gpt-oss') || lower.includes('120b')) return 'openai/gpt-oss-120b';
    if (lower.includes('qwen')) return 'qwen/qwen3.8-27b';
    if (lower.includes('gemma-4-26b') || lower.includes('26b')) return 'gemma-4-26b-a4b-it';
    if (lower.includes('gemma-4-31b') || lower.includes('31b') || lower.includes('gemma')) return 'gemma-4-31b-it';
    if (lower.includes('hydrogen') || lower.includes('4-hydrogen')) return HYDROGEN_4_MODEL;
    if (lower.includes('3.8-flash') || lower.includes('3.8 flash')) return 'gemini-3.8-flash';
    if (lower.includes('3.5-flash-lite') || lower.includes('3.5 flash-lite')) return 'gemini-3.5-flash-lite';
    if (lower.includes('3.1-flash-lite') || lower.includes('3.1 flash-lite')) return 'gemini-3.1-flash-lite';
    if (lower.includes('flash-lite-latest') || lower.includes('flash-lite') || lower.includes('flash lite')) return 'gemini-flash-lite-latest';
    if (lower.includes('3.6-flash') || lower.includes('3.6 flash')) return 'gemini-3.6-flash';
    if (lower.includes('flash-latest') || lower.includes('flash latest')) return 'gemini-flash-latest';
    if (lower.includes('flash')) return 'gemini-3.8-flash';
    return rawModel;
  };

  const recordUsage = (modelId: string) => {
    try {
      const todayPT = getPTDateString();
      let quotaData = JSON.parse(localStorage.getItem('applet_daily_quota') || '{"date": "", "usage": {}}');
      if (quotaData.date !== todayPT) {
        quotaData = { date: todayPT, usage: {} };
      }
      const trackingKey = getTrackingModelKey(modelId);
      quotaData.usage[trackingKey] = (quotaData.usage[trackingKey] || 0) + 1;
      localStorage.setItem('applet_daily_quota', JSON.stringify(quotaData));
    } catch (e) {
      console.error('Error recording quota:', e);
    }
  };

  // Speech playback queue ref to ensure long responses never freeze in Chrome/WebKit
  const speechQueueRef = useRef<{
    messageId: string;
    chunks: string[];
    currentIndex: number;
  }>({
    messageId: '',
    chunks: [],
    currentIndex: 0,
  });

  // Preload voices and cancel speech on component unmount
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const handleVoicesChanged = () => {
        window.speechSynthesis.getVoices();
      };
      window.speechSynthesis.addEventListener('voiceschanged', handleVoicesChanged);
      window.speechSynthesis.getVoices();
      return () => {
        window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
        window.speechSynthesis.cancel();
      };
    }
  }, []);

  const playSpeechChunk = (index: number, chunks: string[], id: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (index >= chunks.length || speechQueueRef.current.messageId !== id) {
      setSpeakingMessageId(null);
      setIsPaused(false);
      speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 };
      return;
    }

    const chunk = chunks[index];
    const utterance = new SpeechSynthesisUtterance(chunk);
    utterance.rate = 1.05;
    utterance.pitch = 1.15;

    const voices = window.speechSynthesis.getVoices();
    const preferredVoice =
      voices.find(
        (v) =>
          /samantha|victoria|karen|moira|zira|aria|jenny|google us english|en-us/i.test(v.name) &&
          v.lang.startsWith('en')
      ) ||
      voices.find((v) => v.lang.startsWith('en-US')) ||
      voices.find((v) => v.lang.startsWith('en'));

    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onend = () => {
      if (speechQueueRef.current.messageId === id) {
        speechQueueRef.current.currentIndex = index + 1;
        playSpeechChunk(index + 1, chunks, id);
      }
    };

    utterance.onerror = (e: any) => {
      // Don't treat user-initiated cancel or interrupt as fatal error
      if (e?.error === 'canceled' || e?.error === 'interrupted') return;
      if (speechQueueRef.current.messageId === id) {
        speechQueueRef.current.currentIndex = index + 1;
        playSpeechChunk(index + 1, chunks, id);
      }
    };

    window.speechSynthesis.speak(utterance);
  };

  const handlePauseResume = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    if (window.speechSynthesis.paused || isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const handleReadAloud = (rawText: string, id: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported in this browser.');
      return;
    }

    // Toggle off if currently reading the same message
    if (speakingMessageId === id) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      setIsPaused(false);
      speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 };
      return;
    }

    window.speechSynthesis.cancel();
    setIsPaused(false);

    // Thoroughly strip all markdown syntax, emojis, LaTeX, HTML, and dingbats
    const cleanText = sanitizeForSpeech(rawText);
    if (!cleanText) return;

    // Sentence-sized chunks prevent Chromium/WebKit 15-second freeze
    const chunks = splitIntoSpeechChunks(cleanText);
    if (chunks.length === 0) return;

    speechQueueRef.current = {
      messageId: id,
      chunks,
      currentIndex: 0,
    };
    setSpeakingMessageId(id);
    playSpeechChunk(0, chunks, id);
  };

  const [activeStreamingThought, setActiveStreamingThought] = useState('');
  const [isThinkingActive, setIsThinkingActive] = useState(false);

  const checkModelHealth = async () => {
    setIsCheckingHealth(true);
    try {
      const res = await fetch('/api/check-models', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          cascades: latestCascadesRef.current,
          thinkingLevels: latestThinkingLevelsRef.current,
          groqModels: latestGroqModelsRef.current,
          updatedAt: cascadeUpdatedAtRef.current,
        }),
      });
      if (res.status === 401) {
        setIsAuthenticated(false);
        try { localStorage.removeItem('study_auth_token'); } catch (_) {}
        return;
      }
      if (!res.ok) throw new Error('Failed to fetch model health status');
      const data: ModelHealthResponse = await res.json();
      setHealthData(data);
      setConfirmClearDisabled(false);
      setDisabledResetNotice(null);
      setIsHealthModalOpen(true);
    } catch (err) {
      console.error('Error checking model health:', err);
    } finally {
      setIsCheckingHealth(false);
    }
  };

  const handleClearDisabledModels = async () => {
    setIsClearingDisabled(true);
    setDisabledResetNotice(null);
    try {
      const res = await fetch('/api/reset-disabled-models', {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      if (res.status === 401) {
        setIsAuthenticated(false);
        try { localStorage.removeItem('study_auth_token'); } catch (_) {}
        return;
      }
      if (!res.ok) throw new Error('Failed to clear disabled models');
      setConfirmClearDisabled(false);
      setDisabledResetNotice('Session-disabled models list cleared.');
      setCascadeNotice('Cleared session-disabled models cache (cascades unchanged).');
      if (healthData) {
        try {
          const refreshRes = await fetch('/api/check-models', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
              cascades: latestCascadesRef.current,
              thinkingLevels: latestThinkingLevelsRef.current,
              groqModels: latestGroqModelsRef.current,
              updatedAt: cascadeUpdatedAtRef.current,
            }),
          });
          if (refreshRes.ok) {
            const refreshed: ModelHealthResponse = await refreshRes.json();
            setHealthData(refreshed);
          }
        } catch (_) {}
      }
    } catch (err) {
      console.error('Error clearing disabled models:', err);
      setDisabledResetNotice('Failed to clear disabled models.');
      setCascadeNotice('Failed to clear disabled models.');
    } finally {
      setIsClearingDisabled(false);
    }
  };

  const handleBrandClick = () => {
    setTitleClickCount((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        checkModelHealth();
        return 0;
      }
      return next;
    });
  };

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const safeSaveMessagesToLocalStorage = (msgs: ChatMessage[]) => {
    try {
      localStorage.setItem('focus_jee_messages', JSON.stringify(msgs));
    } catch (_) {
      try {
        const compacted = msgs.map((m) =>
          m.attachments?.length
            ? {
                ...m,
                attachments: m.attachments.map(({ id, name, mimeType, size }) => ({
                  id,
                  name,
                  mimeType,
                  size,
                })),
              }
            : m
        );
        localStorage.setItem('focus_jee_messages', JSON.stringify(compacted));
      } catch (_) {}
    }
  };

  // Sync to localStorage with 6-day retention
  useEffect(() => {
    const now = Date.now();
    const activeMessages = messages.filter((m) => !m.timestamp || now - m.timestamp <= RETENTION_6_DAYS_MS);
    safeSaveMessagesToLocalStorage(activeMessages);
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('focus_jee_vault', JSON.stringify(pinnedVault));
  }, [pinnedVault]);

  // Sync with backend persistent state on initial load
  useEffect(() => {
    // Remove any previously cached client-side key from localStorage for security
    try {
      localStorage.removeItem('openrouter_api_key');
    } catch (_) {}

    // Enforce daily quota reset at Midnight PT safely in effect
    try {
      const todayPT = getPTDateString();
      const stored = localStorage.getItem('applet_daily_quota');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.date !== todayPT) {
          localStorage.setItem('applet_daily_quota', JSON.stringify({ date: todayPT, usage: {} }));
        }
      } else {
        localStorage.setItem('applet_daily_quota', JSON.stringify({ date: todayPT, usage: {} }));
      }
    } catch (_) {}

    const storedToken = typeof localStorage !== 'undefined' ? localStorage.getItem('study_auth_token') : null;
    if (storedToken) {
      fetch('/api/auth/status', {
        headers: {
          'Authorization': `Bearer ${storedToken}`,
        },
      })
        .then((res) => res.json())
        .then((data) => {
          if (data && data.authenticated) {
            setIsAuthenticated(true);
            loadStudyState(storedToken);
          } else {
            setIsAuthenticated(false);
            try { localStorage.removeItem('study_auth_token'); } catch (_) {}
          }
        })
        .catch(() => {
          setIsAuthenticated(false);
        })
        .finally(() => {
          setIsAuthChecking(false);
        });
    } else {
      setIsAuthenticated(false);
      setIsAuthChecking(false);
    }
  }, []);

  const loadStudyState = (tokenToUse?: string) => {
    const currentToken = tokenToUse || authToken || (typeof localStorage !== 'undefined' ? localStorage.getItem('study_auth_token') : '') || '';
    fetch('/api/study-state', {
      headers: {
        'Content-Type': 'application/json',
        ...(currentToken ? { 'Authorization': `Bearer ${currentToken}` } : {}),
      },
    })
      .then((res) => {
        if (res.status === 401) {
          setIsAuthenticated(false);
          try { localStorage.removeItem('study_auth_token'); } catch (_) {}
          return null;
        }
        return res.json();
      })
      .then((data) => {
        if (!data) return;
        if (data.messages && data.messages.length > 0 && messages.length <= 1) {
          setMessages(data.messages);
        }
        if (data.pinnedVault && data.pinnedVault.length > 0 && pinnedVault.length === 0) {
          setPinnedVault(data.pinnedVault);
        }
      })
      .catch((err) => console.log('State sync info:', err));

    fetch('/api/cascade-config', {
      headers: {
        'Content-Type': 'application/json',
        ...(currentToken ? { 'Authorization': `Bearer ${currentToken}` } : {}),
      },
    })
      .then((res) => {
        if (res.status === 401) {
          setIsAuthenticated(false);
          try { localStorage.removeItem('study_auth_token'); } catch (_) {}
          return null;
        }
        if (!res.ok) return null;
        return res.json();
      })
      .then((cfg) => {
        if (!cfg) return;
        const serverUpdatedAt = typeof cfg.updatedAt === 'number' ? cfg.updatedAt : 0;
        const localSaved = readCascadeConfigFromLocalStorage();
        if (localSaved && localSaved.updatedAt > serverUpdatedAt) {
          // Client has newer configuration (e.g. Cloud Run instance restarted with cold/default state)
          saveCascadeConfigToServer(
            localSaved.cascades,
            localSaved.thinkingLevels,
            undefined,
            localSaved.groqModels,
            localSaved.updatedAt
          );
          return;
        }
        const nextCascades = cfg.cascades || latestCascadesRef.current;
        const nextLevels = cfg.thinkingLevels || latestThinkingLevelsRef.current;
        const nextGroq = Array.isArray(cfg.groqModels) ? cfg.groqModels : latestGroqModelsRef.current;
        if (cfg.cascades) setGeminiCascades(cfg.cascades);
        if (cfg.thinkingLevels) setGeminiThinkingLevels(cfg.thinkingLevels);
        if (Array.isArray(cfg.groqModels)) setGroqModels(cfg.groqModels);
        cascadeUpdatedAtRef.current = serverUpdatedAt;
        if (serverUpdatedAt > 0) {
          writeCascadeConfigToLocalStorage({
            cascades: nextCascades,
            thinkingLevels: nextLevels,
            groqModels: nextGroq,
            updatedAt: serverUpdatedAt,
          });
        }
      })
      .catch((err) => console.log('Cascade config sync info:', err));
  };

  const getSmartDefaultCascadeTab = (): CascadeEditorTab => {
    if (modelPreference === 'groq') return 'groq';
    if (thinkHarder) return 'thinkHarder';
    if (modelPreference === 'auto' || modelPreference === 'flash-lite' || modelPreference === 'flash' || modelPreference === 'gemma') {
      return modelPreference;
    }
    return 'auto';
  };

  const openCascadeEditorModal = () => {
    setActiveEditorTab(getSmartDefaultCascadeTab());
    setNewModelInput('');
    setAddThinkingChoice('unchanged');
    setCascadeNotice(null);
    setConfirmClearDisabled(false);
    setDisabledResetNotice(null);
    setIsCascadeModalOpen(true);

    // Non-blocking sync check: pull server changes only if newer than local, or push local if server cold-started
    fetch('/api/cascade-config', {
      headers: getAuthHeaders(),
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((cfg) => {
        if (!cfg) return;
        const serverUpdatedAt = typeof cfg.updatedAt === 'number' ? cfg.updatedAt : 0;
        const localUpdatedAt = cascadeUpdatedAtRef.current || 0;
        if (serverUpdatedAt > localUpdatedAt) {
          const nextCascades = cfg.cascades || latestCascadesRef.current;
          const nextLevels = cfg.thinkingLevels || latestThinkingLevelsRef.current;
          const nextGroq = Array.isArray(cfg.groqModels) ? cfg.groqModels : latestGroqModelsRef.current;
          if (cfg.cascades) setGeminiCascades(cfg.cascades);
          if (cfg.thinkingLevels) setGeminiThinkingLevels(cfg.thinkingLevels);
          if (Array.isArray(cfg.groqModels)) setGroqModels(cfg.groqModels);
          cascadeUpdatedAtRef.current = serverUpdatedAt;
          writeCascadeConfigToLocalStorage({
            cascades: nextCascades,
            thinkingLevels: nextLevels,
            groqModels: nextGroq,
            updatedAt: serverUpdatedAt,
          });
        } else if (localUpdatedAt > serverUpdatedAt) {
          saveCascadeConfigToServer(
            latestCascadesRef.current,
            latestThinkingLevelsRef.current,
            undefined,
            latestGroqModelsRef.current,
            localUpdatedAt
          );
        }
      })
      .catch(() => {});
  };

  const getModelBehaviorBadge = (modelId: string): { label: string; style: string } => {
    if (modelId.toLowerCase().startsWith('gemma')) {
      return { label: 'Gemma Prompt', style: 'bg-sky-950/60 border-sky-700/50 text-sky-300' };
    }
    if (geminiThinkingLevels.xhigh.some(m => modelId === m)) {
      return { label: 'XHIGH', style: 'bg-purple-950/70 border-purple-500/60 text-purple-300' };
    }
    if (geminiThinkingLevels.high.some(m => modelId === m)) {
      return { label: 'HIGH', style: 'bg-indigo-950/60 border-indigo-600/50 text-indigo-300' };
    }
    return { label: 'Standard', style: 'bg-zinc-900 border-zinc-700 text-zinc-400' };
  };

  const saveCascadeConfigToServer = async (
    nextCascades: Record<GeminiCascadeKey, string[]>,
    nextThinkingLevels: Record<ThinkingTierKey, string[]>,
    successMessage?: string,
    nextGroqModels: string[] = groqModels,
    updatedAtOverride?: number
  ) => {
    const nextUpdatedAt = typeof updatedAtOverride === 'number' && updatedAtOverride > 0 ? updatedAtOverride : Date.now();
    latestCascadesRef.current = nextCascades;
    latestThinkingLevelsRef.current = nextThinkingLevels;
    latestGroqModelsRef.current = nextGroqModels;
    cascadeUpdatedAtRef.current = nextUpdatedAt;
    writeCascadeConfigToLocalStorage({
      cascades: nextCascades,
      thinkingLevels: nextThinkingLevels,
      groqModels: nextGroqModels,
      updatedAt: nextUpdatedAt,
    });
    setCascadeSaving(true);
    if (successMessage) setCascadeNotice(null);
    try {
      const res = await fetch('/api/cascade-config', {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          cascades: nextCascades,
          thinkingLevels: nextThinkingLevels,
          groqModels: nextGroqModels,
          updatedAt: nextUpdatedAt,
        }),
      });
      if (res.status === 401) {
        setIsAuthenticated(false);
        try { localStorage.removeItem('study_auth_token'); } catch (_) {}
        return;
      }
      if (!res.ok) throw new Error('Failed to save cascade configuration');
      const data = await res.json();
      const syncedCascades = data.cascades || nextCascades;
      const syncedLevels = data.thinkingLevels || nextThinkingLevels;
      const syncedGroq = Array.isArray(data.groqModels) ? data.groqModels : nextGroqModels;
      const syncedUpdatedAt = typeof data.updatedAt === 'number' && data.updatedAt > 0 ? data.updatedAt : nextUpdatedAt;
      latestCascadesRef.current = syncedCascades;
      latestThinkingLevelsRef.current = syncedLevels;
      latestGroqModelsRef.current = syncedGroq;
      if (data.cascades) setGeminiCascades(data.cascades);
      if (data.thinkingLevels) setGeminiThinkingLevels(data.thinkingLevels);
      if (Array.isArray(data.groqModels)) setGroqModels(data.groqModels);
      cascadeUpdatedAtRef.current = syncedUpdatedAt;
      writeCascadeConfigToLocalStorage({
        cascades: syncedCascades,
        thinkingLevels: syncedLevels,
        groqModels: syncedGroq,
        updatedAt: syncedUpdatedAt,
      });
      if (successMessage) setCascadeNotice(successMessage);
    } catch (err) {
      console.error('Error saving cascade config:', err);
      setCascadeNotice('Failed to save changes. Please retry.');
    } finally {
      setCascadeSaving(false);
    }
  };

  const handleResetAllCascades = async () => {
    setCascadeSaving(true);
    setCascadeNotice(null);
    try {
      const res = await fetch('/api/cascade-config/reset', {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      if (res.status === 401) {
        setIsAuthenticated(false);
        try { localStorage.removeItem('study_auth_token'); } catch (_) {}
        return;
      }
      if (!res.ok) throw new Error('Failed to reset cascade configuration');
      const data = await res.json();
      const resetCascades = data.cascades || {
        'auto': [...DEFAULT_GEMINI_CASCADES['auto']],
        'flash-lite': [...DEFAULT_GEMINI_CASCADES['flash-lite']],
        'flash': [...DEFAULT_GEMINI_CASCADES['flash']],
        'gemma': [...DEFAULT_GEMINI_CASCADES['gemma']],
        'thinkHarder': [...DEFAULT_GEMINI_CASCADES['thinkHarder']],
      };
      const resetLevels = data.thinkingLevels || {
        'xhigh': [...DEFAULT_THINKING_LEVELS['xhigh']],
        'high': [...DEFAULT_THINKING_LEVELS['high']],
      };
      const resetGroq = Array.isArray(data.groqModels) ? data.groqModels : [...DEFAULT_GROQ_MODELS];
      const resetUpdatedAt = typeof data.updatedAt === 'number' && data.updatedAt > 0 ? data.updatedAt : Date.now();
      latestCascadesRef.current = resetCascades;
      latestThinkingLevelsRef.current = resetLevels;
      latestGroqModelsRef.current = resetGroq;
      if (data.cascades) setGeminiCascades(data.cascades);
      if (data.thinkingLevels) setGeminiThinkingLevels(data.thinkingLevels);
      if (Array.isArray(data.groqModels)) setGroqModels(data.groqModels);
      cascadeUpdatedAtRef.current = resetUpdatedAt;
      writeCascadeConfigToLocalStorage({
        cascades: resetCascades,
        thinkingLevels: resetLevels,
        groqModels: resetGroq,
        updatedAt: resetUpdatedAt,
      });
      setNewModelInput('');
      setCascadeNotice('All cascades, thinking levels, and Groq models reset to defaults.');
    } catch (err) {
      console.error('Error resetting cascade config:', err);
      setCascadeNotice('Failed to reset configuration.');
    } finally {
      setCascadeSaving(false);
    }
  };

  const handleAddModelToActiveTab = async () => {
    const normalized = normalizeClientModelId(newModelInput);
    if (!normalized) return;

    if (activeEditorTab === 'groq') {
      const alreadyInGroq = groqModels.includes(normalized);
      const nextGroq = alreadyInGroq
        ? groqModels
        : addPosition === 'top'
        ? [normalized, ...groqModels]
        : [...groqModels, normalized];
      setGroqModels(nextGroq);
      latestGroqModelsRef.current = nextGroq;
      setNewModelInput('');
      await saveCascadeConfigToServer(
        geminiCascades,
        geminiThinkingLevels,
        alreadyInGroq ? `${normalized} is already in Groq cascade.` : `Added ${normalized} to Groq cascade.`,
        nextGroq
      );
      return;
    }

    const isGemmaModel = normalized.toLowerCase().startsWith('gemma');

    if (activeEditorTab === 'think-xhigh' || activeEditorTab === 'think-high') {
      if (isGemmaModel) {
        setCascadeNotice('Gemma models do not support thinkingConfig and use prompt mode automatically');
        return;
      }
      const targetTier: ThinkingTierKey = activeEditorTab === 'think-xhigh' ? 'xhigh' : 'high';
      const otherTier: ThinkingTierKey = targetTier === 'xhigh' ? 'high' : 'xhigh';
      const existingTarget = geminiThinkingLevels[targetTier];
      const nextTarget = existingTarget.includes(normalized)
        ? existingTarget
        : addPosition === 'top'
        ? [normalized, ...existingTarget]
        : [...existingTarget, normalized];
      const nextOther = geminiThinkingLevels[otherTier].filter((m) => m !== normalized);
      const nextLevels: Record<ThinkingTierKey, string[]> = {
        ...geminiThinkingLevels,
        [targetTier]: nextTarget,
        [otherTier]: nextOther,
      };
      setGeminiThinkingLevels(nextLevels);
      setNewModelInput('');
      await saveCascadeConfigToServer(
        geminiCascades,
        nextLevels,
        `Added ${normalized} to Think: ${targetTier.toUpperCase()}.`
      );
      return;
    }

    const cascadeKey = activeEditorTab as GeminiCascadeKey;
    const currentList = geminiCascades[cascadeKey] || [];
    const alreadyInCascade = currentList.includes(normalized);
    const nextList = alreadyInCascade
      ? currentList
      : addPosition === 'top'
      ? [normalized, ...currentList]
      : [...currentList, normalized];

    const nextCascades: Record<GeminiCascadeKey, string[]> = {
      ...geminiCascades,
      [cascadeKey]: nextList,
    };

    let nextLevels: Record<ThinkingTierKey, string[]> = {
      xhigh: [...geminiThinkingLevels.xhigh],
      high: [...geminiThinkingLevels.high],
    };

    if (!isGemmaModel && (addThinkingChoice === 'high' || addThinkingChoice === 'xhigh')) {
      const targetTier: ThinkingTierKey = addThinkingChoice;
      const otherTier: ThinkingTierKey = targetTier === 'xhigh' ? 'high' : 'xhigh';
      if (!nextLevels[targetTier].includes(normalized)) {
        nextLevels[targetTier] = [...nextLevels[targetTier], normalized];
      }
      nextLevels[otherTier] = nextLevels[otherTier].filter((m) => m !== normalized);
    }

    setGeminiCascades(nextCascades);
    setGeminiThinkingLevels(nextLevels);
    setNewModelInput('');
    await saveCascadeConfigToServer(
      nextCascades,
      nextLevels,
      alreadyInCascade
        ? `${normalized} is already in ${cascadeKey}${!isGemmaModel && addThinkingChoice !== 'unchanged' ? ` (thinking set to ${addThinkingChoice.toUpperCase()})` : ''}.`
        : `Added ${normalized} to ${cascadeKey}.`
    );
  };

  const handleDeleteModelFromActiveTab = async (modelId: string) => {
    if (activeEditorTab === 'groq') {
      const nextGroq = groqModels.filter((m) => m !== modelId);
      setGroqModels(nextGroq);
      latestGroqModelsRef.current = nextGroq;
      await saveCascadeConfigToServer(
        geminiCascades,
        geminiThinkingLevels,
        `Removed ${modelId} from Groq cascade.`,
        nextGroq
      );
      return;
    }

    if (activeEditorTab === 'think-xhigh' || activeEditorTab === 'think-high') {
      const tier: ThinkingTierKey = activeEditorTab === 'think-xhigh' ? 'xhigh' : 'high';
      const nextLevels: Record<ThinkingTierKey, string[]> = {
        ...geminiThinkingLevels,
        [tier]: geminiThinkingLevels[tier].filter((m) => m !== modelId),
      };
      setGeminiThinkingLevels(nextLevels);
      await saveCascadeConfigToServer(geminiCascades, nextLevels, `Removed ${modelId} from Think: ${tier.toUpperCase()}.`);
      return;
    }

    const cascadeKey = activeEditorTab as GeminiCascadeKey;
    const nextCascades: Record<GeminiCascadeKey, string[]> = {
      ...geminiCascades,
      [cascadeKey]: geminiCascades[cascadeKey].filter((m) => m !== modelId),
    };
    setGeminiCascades(nextCascades);
    await saveCascadeConfigToServer(nextCascades, geminiThinkingLevels, `Removed ${modelId} from ${cascadeKey}.`);
  };

  const handleLiveReorder = (newOrder: string[]) => {
    if (activeEditorTab === 'groq') {
      const prev = latestGroqModelsRef.current;
      if (prev.length === newOrder.length && prev.every((m, idx) => m === newOrder[idx])) {
        return;
      }
      dragOrderChangedRef.current = true;
      latestGroqModelsRef.current = newOrder;
      setGroqModels(newOrder);
      return;
    }

    if (activeEditorTab === 'think-xhigh' || activeEditorTab === 'think-high') {
      const tier: ThinkingTierKey = activeEditorTab === 'think-xhigh' ? 'xhigh' : 'high';
      const prev = latestThinkingLevelsRef.current[tier];
      if (prev.length === newOrder.length && prev.every((m, idx) => m === newOrder[idx])) {
        return;
      }
      dragOrderChangedRef.current = true;
      const nextLevels: Record<ThinkingTierKey, string[]> = {
        ...latestThinkingLevelsRef.current,
        [tier]: newOrder,
      };
      latestThinkingLevelsRef.current = nextLevels;
      setGeminiThinkingLevels(nextLevels);
      return;
    }

    const cascadeKey = activeEditorTab as GeminiCascadeKey;
    const prev = latestCascadesRef.current[cascadeKey];
    if (prev.length === newOrder.length && prev.every((m, idx) => m === newOrder[idx])) {
      return;
    }
    dragOrderChangedRef.current = true;
    const nextCascades: Record<GeminiCascadeKey, string[]> = {
      ...latestCascadesRef.current,
      [cascadeKey]: newOrder,
    };
    latestCascadesRef.current = nextCascades;
    setGeminiCascades(nextCascades);
  };

  const handleDragReorderCommit = async () => {
    if (!dragOrderChangedRef.current) return;
    dragOrderChangedRef.current = false;
    await saveCascadeConfigToServer(
      latestCascadesRef.current,
      latestThinkingLevelsRef.current,
      'Order updated and saved.',
      latestGroqModelsRef.current
    );
  };

  const handleExportCascadeConfig = () => {
    try {
      const payload = {
        cascades: geminiCascades,
        thinkingLevels: geminiThinkingLevels,
        groqModels,
        exportedAt: new Date().toISOString(),
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `gemini-cascade-config-${getPTDateString().replace(/\//g, '-')}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setCascadeNotice('Exported cascade configuration JSON.');
    } catch (err) {
      console.error('Error exporting cascade config:', err);
      setCascadeNotice('Failed to export configuration.');
    }
  };

  const handleImportCascadeConfig = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    try {
      const rawText = await file.text();
      const parsed = JSON.parse(rawText);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        setCascadeNotice('Invalid configuration file: expected JSON object.');
        return;
      }

      const cascadeKeys: GeminiCascadeKey[] = ['auto', 'flash-lite', 'flash', 'gemma', 'thinkHarder'];
      const hasValidCascades =
        parsed.cascades &&
        typeof parsed.cascades === 'object' &&
        cascadeKeys.some((k) => Array.isArray(parsed.cascades[k]));
      const hasValidThinking =
        parsed.thinkingLevels &&
        typeof parsed.thinkingLevels === 'object' &&
        (Array.isArray(parsed.thinkingLevels.xhigh) || Array.isArray(parsed.thinkingLevels.high));
      const hasValidGroq = Array.isArray(parsed.groqModels);

      if (!hasValidCascades && !hasValidThinking && !hasValidGroq) {
        setCascadeNotice('Invalid configuration file: missing cascades, thinkingLevels, or groqModels arrays.');
        return;
      }

      const nextCascades: Record<GeminiCascadeKey, string[]> = {
        'auto': Array.isArray(parsed?.cascades?.['auto']) ? parsed.cascades['auto'] : [...geminiCascades['auto']],
        'flash-lite': Array.isArray(parsed?.cascades?.['flash-lite']) ? parsed.cascades['flash-lite'] : [...geminiCascades['flash-lite']],
        'flash': Array.isArray(parsed?.cascades?.['flash']) ? parsed.cascades['flash'] : [...geminiCascades['flash']],
        'gemma': Array.isArray(parsed?.cascades?.['gemma']) ? parsed.cascades['gemma'] : [...geminiCascades['gemma']],
        'thinkHarder': Array.isArray(parsed?.cascades?.['thinkHarder']) ? parsed.cascades['thinkHarder'] : [...geminiCascades['thinkHarder']],
      };

      const nextThinkingLevels: Record<ThinkingTierKey, string[]> = {
        'xhigh': Array.isArray(parsed?.thinkingLevels?.xhigh) ? parsed.thinkingLevels.xhigh : [...geminiThinkingLevels.xhigh],
        'high': Array.isArray(parsed?.thinkingLevels?.high) ? parsed.thinkingLevels.high : [...geminiThinkingLevels.high],
      };

      const nextGroqModels: string[] = Array.isArray(parsed?.groqModels)
        ? parsed.groqModels
        : [...groqModels];

      await saveCascadeConfigToServer(
        nextCascades,
        nextThinkingLevels,
        'Imported and saved cascade configuration.',
        nextGroqModels
      );
    } catch (err) {
      console.error('Error importing cascade config:', err);
      setCascadeNotice('Invalid JSON file. Please select a valid cascade config backup.');
    }
  };

  // Save back to backend persistently (6-day chat retention + permanent formula vault)
  const saveStateToBackend = (newMsgs: ChatMessage[], newVault: PinnedItem[]) => {
    const now = Date.now();
    const activeMsgs = newMsgs.filter((m) => !m.timestamp || now - m.timestamp <= RETENTION_6_DAYS_MS);
    fetch('/api/study-state', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        messages: activeMsgs,
        pinnedVault: newVault, // Permanently preserved
        activeSubject: currentSubject,
      }),
    }).catch((e) => console.error('Failed to sync state to server:', e));
  };

  // Auto-scroll is fully disabled per user preference

  // Auto-resize textarea
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputPrompt(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  };

  const handleInsertMiniPrompt = (snippet: string) => {
    setInputPrompt((prev) => {
      const trimmed = prev.trim();
      if (!trimmed) return snippet;
      return `${trimmed} ${snippet}`;
    });
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
      }
    }, 10);
  };

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      isUserAbortedRef.current = true;
      abortControllerRef.current.abort();
    }
  };

  const handleStartEditMessage = (msg: ChatMessage) => {
    setEditingMessageId(msg.id);
    setEditText(msg.text);
  };

  const handleSaveAndResend = (msgId: string) => {
    const trimmed = editText.trim();
    if (!trimmed) return;

    const msgIndex = messages.findIndex((m) => m.id === msgId);
    if (msgIndex === -1) return;

    if (abortControllerRef.current) {
      isUserAbortedRef.current = true;
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoading(false);

    const targetMsg = messages[msgIndex];
    const updatedUserMsg: ChatMessage = {
      ...targetMsg,
      text: trimmed,
      timestamp: Date.now(),
    };

    const newHistory = [...messages.slice(0, msgIndex), updatedUserMsg];
    setMessages(newHistory);
    setEditingMessageId(null);
    setEditText('');

    setTimeout(() => {
      sendMessage(trimmed, newHistory);
    }, 60);
  };

  // Process incoming files (from paste, file picker, or drag-and-drop)
  const processFiles = (files: FileList | File[]) => {
    const fileArray = Array.from(files);
    for (const file of fileArray) {
      if (file.size > 20 * 1024 * 1024) {
        alert(`File "${file.name}" exceeds 20MB limit.`);
        continue;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = (e.target?.result as string) || '';
        const base64Data = dataUrl.split(',')[1] || '';
        const mime = file.type || (file.name.endsWith('.pdf') ? 'application/pdf' : 'text/plain');

        const newAttachment: AttachmentItem = {
          id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          name: file.name,
          mimeType: mime,
          data: base64Data,
          dataUrl: dataUrl,
          size: file.size,
        };
        setPendingAttachments((prev) => [...prev, newAttachment]);
      };
      reader.readAsDataURL(file);
    }
  };

  // Clipboard Paste handler (Ctrl+V directly into text box)
  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    if (e.clipboardData.files && e.clipboardData.files.length > 0) {
      e.preventDefault();
      processFiles(e.clipboardData.files);
    }
  };

  // Drag and drop handler
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const removePendingAttachment = (id: string) => {
    setPendingAttachments((prev) => prev.filter((a) => a.id !== id));
  };



  // Insert a Chapter / Topic Milestone Anchor without deleting the chat
  const handleAddMilestone = (title: string) => {
    if (!title.trim()) return;
    const milestoneMessage: ChatMessage = {
      id: `milestone-${Date.now()}`,
      role: 'user',
      text: `📍 [TOPIC MILESTONE: ${title.trim()} - Subject: ${currentSubject}] Continuing study session here!`,
      timestamp: Date.now(),
      subject: currentSubject,
      milestoneTitle: title.trim(),
    };

    const updated = [...messages, milestoneMessage];
    setMessages(updated);
    saveStateToBackend(updated, pinnedVault);
    setIsMilestoneModalOpen(false);
    setMilestoneTitleInput('');

    sendMessage(milestoneMessage.text, updated);
  };

  const sendMessage = async (textToSend?: string, currentHistory?: ChatMessage[]) => {
    const prompt = (textToSend || inputPrompt).trim();
    const attachmentsToSend = [...pendingAttachments];

    if (!isAuthenticated || (!prompt && attachmentsToSend.length === 0) || isLoading) return;

    if (!textToSend) {
      setInputPrompt('');
      setPendingAttachments([]);
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
    }

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: prompt,
      timestamp: Date.now(),
      subject: currentSubject,
      attachments: attachmentsToSend.length > 0 ? attachmentsToSend : undefined,
    };

    const newHistory = currentHistory ? [...currentHistory] : [...messages, userMessage];
    if (!currentHistory) {
      setMessages(newHistory);
    }

    setIsLoading(true);
    setActiveStreamingText('');
    setActiveStreamingThought('');
    setIsThinkingActive(false);
    setFallbackNotice(null);

    const controller = new AbortController();
    abortControllerRef.current = controller;
    isUserAbortedRef.current = false;

    let resolvedModelName = modelPreference === 'groq' ? 'Groq Llama 3.3' : modelPreference === 'openrouter' ? 'OpenRouter Free' : modelPreference === 'bzl' ? 'BazaarLink (vm/my-router)' : 'Gemini 3.8 Flash';

    // Filter out previous messages before the last context boundary to prevent token waste
    const getEffectiveHistoryForApi = (history: ChatMessage[]): ChatMessage[] => {
      const boundaryIndex = history.map(m => !!m.isContextBoundary).lastIndexOf(true);
      if (boundaryIndex !== -1) {
        return history.slice(boundaryIndex + 1);
      }
      return history;
    };

    const effectiveHistory = getEffectiveHistoryForApi(newHistory);

    // Choose dedicated stream and fallback endpoints for Groq or Gemini cascade
    const streamEndpoint = '/api/chat/stream';
    const fallbackEndpoint = '/api/chat';

    let accumulatedText = '';
    let accumulatedThought = '';

    try {
      const response = await fetch(streamEndpoint, {
        method: 'POST',
        headers: getAuthHeaders(),
        signal: controller.signal,
        body: JSON.stringify({
          messages: effectiveHistory.map((m) => ({
            role: m.role,
            text: m.text,
            subject: m.subject,
            attachments: m.attachments?.map(({ id, name, mimeType, data }) => ({ id, name, mimeType, data })),
          })),
          modelPreference,
          thinkHarder,
          historyLimit,
          cascadeConfig: {
            cascades: latestCascadesRef.current,
            thinkingLevels: latestThinkingLevelsRef.current,
            groqModels: latestGroqModelsRef.current,
            updatedAt: cascadeUpdatedAtRef.current,
          },
        }),
      });

      if (response.status === 401) {
        setIsAuthenticated(false);
        try { localStorage.removeItem('study_auth_token'); } catch (_) {}
        throw new Error('Access password required. Please unlock your study session.');
      }

      if (!response.ok || !response.body) {
        throw new Error('Streaming connection failed');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      let sseBuffer = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        sseBuffer += decoder.decode(value, { stream: true });
        const lines = sseBuffer.split('\n');
        sseBuffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith(':')) continue;
          if (trimmed.startsWith('data: ')) {
            const jsonStr = trimmed.slice(6).trim();
            if (!jsonStr || jsonStr === '[DONE]') continue;

            let eventData: any = null;
            try {
              eventData = JSON.parse(jsonStr);
            } catch (_) {
              continue;
            }

            if (eventData.type === 'error') {
              throw new Error(eventData.error || 'Stream returned error');
            } else if (eventData.type === 'model_init') {
              resolvedModelName = eventData.model;
              setActiveModelUsed(getTrackingModelKey(resolvedModelName));
            } else if (eventData.type === 'thinking') {
              setIsThinkingActive(true);
            } else if (eventData.type === 'thought') {
              setIsThinkingActive(true);
              accumulatedThought += eventData.text;
              setActiveStreamingThought(accumulatedThought);
            } else if (eventData.type === 'fallback_notice') {
              // Clean client-side reset on fallback:
              // If a previous model cut off mid-stream, clear the partial broken text
              // so the new fallback engine generates a clean, complete response from the start.
              accumulatedText = '';
              setActiveStreamingText('');
              accumulatedThought = '';
              setActiveStreamingThought('');
              setFallbackNotice(
                `Active Engine: Switched to ${eventData.nextModel} seamlessly without interruption. Reason: ${eventData.reason || 'Bypassing'}`
              );
              resolvedModelName = eventData.nextModel;
              setActiveModelUsed(getTrackingModelKey(resolvedModelName));
            } else if (eventData.type === 'chunk') {
              setIsThinkingActive(false);
              accumulatedText += eventData.text;
              setActiveStreamingText(accumulatedText);
            } else if (eventData.type === 'done') {
              if (eventData.modelUsed) {
                resolvedModelName = eventData.modelUsed;
                setActiveModelUsed(getTrackingModelKey(resolvedModelName));
              }
            }
          }
        }
      }

      // Process any trailing SSE buffer line if present
      if (sseBuffer.trim().startsWith('data: ')) {
        const jsonStr = sseBuffer.trim().slice(6).trim();
        if (jsonStr && jsonStr !== '[DONE]') {
          let eventData: any = null;
          try {
            eventData = JSON.parse(jsonStr);
          } catch (_) {}
          if (eventData) {
            if (eventData.type === 'error') {
              throw new Error(eventData.error || 'Stream returned error');
            } else if (eventData.type === 'chunk') {
              accumulatedText += eventData.text;
              setActiveStreamingText(accumulatedText);
            } else if (eventData.type === 'thought') {
              accumulatedThought += eventData.text;
              setActiveStreamingThought(accumulatedThought);
            }
          }
        }
      }

      // If no text chunks were accumulated, either use reasoning or trigger non-streaming fallback
      if (!accumulatedText.trim()) {
        if (accumulatedThought.trim()) {
          accumulatedText = accumulatedThought;
        } else {
          throw new Error('Streaming completed with no text content. Falling back to robust engine...');
        }
      }

      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'model',
        text: accumulatedText,
        thought: accumulatedThought || undefined,
        timestamp: Date.now(),
        subject: currentSubject,
        modelUsed: resolvedModelName,
      };

      const finalHistory = [...newHistory, aiMessage];
      setMessages(finalHistory);
      saveStateToBackend(finalHistory, pinnedVault);
      
      // Record actual usage on successful stream completion
      recordUsage(resolvedModelName);
    } catch (err: any) {
      // If stopped/paused by user, preserve partial stream without triggering fallback error
      if (err?.name === 'AbortError' || isUserAbortedRef.current) {
        const trimmedSoFar = accumulatedText.trim();
        const aiMessage: ChatMessage = {
          id: `ai-${Date.now()}`,
          role: 'model',
          text: trimmedSoFar ? `${trimmedSoFar}\n\n⏹️ *(Answer stopped)*` : '⏹️ *(Answer stopped)*',
          thought: accumulatedThought || undefined,
          timestamp: Date.now(),
          subject: currentSubject,
          modelUsed: resolvedModelName,
        };
        const finalHistory = [...newHistory, aiMessage];
        setMessages(finalHistory);
        saveStateToBackend(finalHistory, pinnedVault);
        return;
      }

      console.warn('Streaming error, invoking non-streaming fallback:', err);
      try {
        const fallbackRes = await fetch(fallbackEndpoint, {
          method: 'POST',
          headers: getAuthHeaders(),
          body: JSON.stringify({
            messages: effectiveHistory.map((m) => ({
              role: m.role,
              text: m.text,
              attachments: m.attachments?.map(({ id, name, mimeType, data }) => ({ id, name, mimeType, data })),
            })),
            modelPreference,
            thinkHarder,
            historyLimit,
            cascadeConfig: {
              cascades: latestCascadesRef.current,
              thinkingLevels: latestThinkingLevelsRef.current,
              groqModels: latestGroqModelsRef.current,
              updatedAt: cascadeUpdatedAtRef.current,
            },
          }),
        });

        if (fallbackRes.status === 401) {
          setIsAuthenticated(false);
          try { localStorage.removeItem('study_auth_token'); } catch (_) {}
          throw new Error('Access password required. Please unlock your study session.');
        }

        const fallbackData = await fallbackRes.json();
        if (fallbackData.text) {
          const aiMessage: ChatMessage = {
            id: `ai-${Date.now()}`,
            role: 'model',
            text: fallbackData.text,
            thought: fallbackData.reasoning || undefined,
            timestamp: Date.now(),
            subject: currentSubject,
            modelUsed: fallbackData.modelUsed || 'Gemini Flash',
          };
          setActiveModelUsed(getTrackingModelKey(fallbackData.modelUsed || 'Gemini Flash'));
          const finalHistory = [...newHistory, aiMessage];
          setMessages(finalHistory);
          saveStateToBackend(finalHistory, pinnedVault);

          // Record actual usage on fallback completion
          recordUsage(fallbackData.modelUsed || 'Gemini Flash');
        } else {
          throw new Error(fallbackData.error || 'Server error');
        }
      } catch (finalErr: any) {
        const errorMessage: ChatMessage = {
          id: `err-${Date.now()}`,
          role: 'model',
          text: `⚠️ Study connection momentarily interrupted: ${finalErr.message || 'Please retry'}. All previous notes and context are safely intact. Ask again and the engine cascade will answer.`,
          timestamp: Date.now(),
          subject: currentSubject,
          modelUsed: 'Offline Recovery',
        };
        setMessages((prev) => [...prev, errorMessage]);
      }
    } finally {
      setIsLoading(false);
      setActiveStreamingText('');
      setActiveStreamingThought('');
      setIsThinkingActive(false);
      setFallbackNotice(null);
      abortControllerRef.current = null;
      isUserAbortedRef.current = false;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleCopyMarkdown = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 1800);
  };

  const handlePinToVault = (msg: ChatMessage) => {
    const firstLine =
      msg.text.split('\n')[0].replace(/[#*`_]/g, '').trim() || `${msg.subject || 'Study'} Note`;
    const newPinnedItem: PinnedItem = {
      id: `pin-${Date.now()}`,
      messageId: msg.id,
      title: firstLine.length > 50 ? `${firstLine.slice(0, 50)}...` : firstLine,
      content: msg.text,
      type: 'formula',
      subject: msg.subject || 'General',
      timestamp: Date.now(),
    };

    const updated = [newPinnedItem, ...pinnedVault];
    setPinnedVault(updated);
    saveStateToBackend(messages, updated);
    setIsVaultOpen(true);
  };

  const handleRemovePinnedItem = (id: string) => {
    const updated = pinnedVault.filter((item) => item.id !== id);
    setPinnedVault(updated);
    saveStateToBackend(messages, updated);
  };

  // Clear chat history safely while completely preserving system instructions & formula vault
  const handleClearChatHistory = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingMessageId(null);
    setIsPaused(false);
    speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 };

    const fresh = [INITIAL_GREETING_MESSAGE];
    setMessages(fresh);
    safeSaveMessagesToLocalStorage(fresh);
    saveStateToBackend(fresh, pinnedVault);
    setShowClearConfirm(false);
  };

  // Filter messages by subject if selected
  const displayedMessages = messages.filter((msg) => {
    if (activeSubjectFilter === 'All') return true;
    return msg.subject === activeSubjectFilter || msg.subject === 'General';
  });

  return (
    <div
      onDragOver={(e) => e.preventDefault()}
      onDrop={handleDrop}
      className="flex flex-col h-screen w-screen bg-black text-zinc-100 overflow-hidden font-['Plus_Jakarta_Sans',sans-serif]"
    >
      {/* Top Navigation & Status Bar */}
      <header className="shrink-0 h-14 border-b border-zinc-800 bg-[#09090b] px-4 sm:px-6 flex items-center justify-between gap-3 sm:gap-4 overflow-x-auto z-30">
        {/* Brand & Tiny Non-Disturbing Clear Memory Button */}
        <div className="flex items-center gap-2.5 sm:gap-3 relative shrink-0">
          <div 
            onClick={() => {
              handleBrandClick();
              setIsQuotaPopupOpen(!isQuotaPopupOpen);
            }}
            className="flex items-center gap-2 sm:gap-2.5 cursor-pointer group"
            title="Click to view Estimated Quota (Triple-click for Model Health Check)"
          >
            <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-700 flex items-center justify-center font-black text-sm text-cyan-400 group-hover:border-cyan-500 transition-colors">
              ⚡
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-zinc-100 text-sm sm:text-base tracking-tight group-hover:text-cyan-300 transition-colors">
                  Solara
                </h1>
              </div>
            </div>
          </div>

          {/* Estimated Quota Popup Card */}
          {isQuotaPopupOpen && (
            <div 
              onClick={(e) => e.stopPropagation()}
              className="fixed top-14 left-4 sm:left-6 w-[340px] max-w-[calc(100vw-32px)] bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl p-4 z-50 text-left font-normal"
            >
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-base">📊</span>
                  <div>
                    <h3 className="font-bold text-zinc-100 text-xs">Estimated Daily Quota</h3>
                    <p className="text-[10px] text-zinc-400">Resets daily at Midnight (PT)</p>
                  </div>
                </div>
                <button onClick={() => setIsQuotaPopupOpen(false)} className="text-zinc-400 hover:text-zinc-100 text-xs px-1.5 py-0.5 rounded bg-zinc-800">✕</button>
              </div>

              {/* Local Text Size Scaler (0 API Quota Impact) */}
              <div className="flex items-center justify-between py-2 px-2.5 mb-3 rounded-lg bg-zinc-950/80 border border-zinc-800/90 shadow-inner">
                <div className="flex items-center gap-1.5 text-[11px] text-zinc-300 font-medium">
                  <span className="text-cyan-400 font-bold text-xs">Aa</span>
                  <span>Text Size:</span>
                  <span className="font-mono text-cyan-300 font-semibold text-[10px]">
                    {textSizeLevel === 1 ? '1x' : textSizeLevel === 2 ? '2x' : '3x'}
                  </span>
                </div>
                <div className="flex items-center gap-1 bg-zinc-900 p-0.5 rounded border border-zinc-800">
                  <button
                    type="button"
                    onClick={() => setTextSizeLevel((prev) => Math.max(1, prev - 1))}
                    disabled={textSizeLevel === 1}
                    className="w-5 h-5 flex items-center justify-center text-xs font-bold rounded bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 disabled:hover:bg-zinc-800 text-zinc-200 transition-colors cursor-pointer"
                    title="Decrease font size"
                  >
                    -
                  </button>
                  {[1, 2, 3].map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setTextSizeLevel(lvl)}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors cursor-pointer ${
                        textSizeLevel === lvl ? 'bg-cyan-500 text-black shadow-sm' : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
                      }`}
                      title={`Level ${lvl}: ${lvl === 1 ? 'Comfort (Default)' : lvl === 2 ? 'Large (+15%)' : 'Extra Large (+30%)'}`}
                    >
                      {lvl}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setTextSizeLevel((prev) => Math.min(3, prev + 1))}
                    disabled={textSizeLevel === 3}
                    className="w-5 h-5 flex items-center justify-center text-xs font-bold rounded bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 disabled:hover:bg-zinc-800 text-zinc-200 transition-colors cursor-pointer"
                    title="Increase font size"
                  >
                    +
                  </button>
                </div>
              </div>

              {(() => {
                // Fetch data safely without side-effects during render
                const todayPT = getPTDateString();
                let quotaData: { date: string; usage: Record<string, number> } = { date: todayPT, usage: {} };
                try {
                  const stored = localStorage.getItem('applet_daily_quota');
                  if (stored) {
                    const parsed = JSON.parse(stored);
                    if (parsed.date === todayPT && parsed.usage) {
                      quotaData = parsed;
                    }
                  }
                } catch (_) {}

                // Provider and distinct model limits map
                const providerData = [
                  {
                    name: 'Google AI Studio',
                    models: [
                      { id: HYDROGEN_4_MODEL, limit: 20 },
                      { id: 'gemini-3.8-flash', limit: 20 },
                      { id: 'gemini-3.6-flash', limit: 20 },
                      { id: 'gemini-flash-latest', limit: 20 },
                      { id: 'gemini-flash-lite-latest', limit: 500 }, { id: 'gemini-3.1-flash-lite', limit: 500 },
                      { id: 'gemini-3.5-flash-lite', limit: 500 },
                      { id: 'gemma-4-26b-a4b-it', limit: 14400 }, { id: 'gemma-4-31b-it', limit: 14400 }
                    ]
                  },
                  {
                    name: 'Groq',
                    models: (groqModels.length > 0 ? groqModels : DEFAULT_GROQ_MODELS).map((id) => ({
                      id,
                      limit: 1000,
                    })),
                  },
                  {
                    name: 'OpenRouter',
                    models: [
                      // Assuming OpenRouter dynamically passes the model, we track everything routed there under one OR limit
                      { id: 'openrouter', limit: 50 } 
                    ]
                  },
                  {
                    name: 'BazaarLink',
                    models: [
                      { id: 'bzl', limit: 60 }
                    ]
                  }
                ];

                const getBarColor = (pct: number) => {
                  if (pct >= 85) return 'bg-rose-500';
                  if (pct >= 60) return 'bg-amber-500';
                  return 'bg-cyan-500';
                };

                return (
                  <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1.5 scrollbar-thin">
                    {providerData.map((provider) => {
                      const isExpanded = expandedProviders[provider.name];

                      return (
                        <div key={provider.name} className="rounded-lg border bg-zinc-950/60 border-zinc-800/80 overflow-hidden">
                          {/* Provider Header */}
                          <div 
                            onClick={() => toggleProvider(provider.name)}
                            className="p-2.5 cursor-pointer flex items-center justify-between transition-colors hover:bg-zinc-800/40"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-zinc-500 text-[10px] w-3">{isExpanded ? '▼' : '▶'}</span>
                              <span className="text-[11px] font-bold text-zinc-200">{provider.name}</span>
                            </div>
                            <span className="text-[10px] text-zinc-500 font-mono">
                              {provider.models.length} model{provider.models.length > 1 ? 's' : ''}
                            </span>
                          </div>

                          {/* Individual Model Bars */}
                          {isExpanded && (
                            <div className="px-3 pb-3 pt-1 border-t border-zinc-800/50 bg-zinc-900/30 space-y-3">
                              {provider.models.map(model => {
                                // Normalize openrouter usage key
                                const trackingKey = provider.name === 'OpenRouter' ? 'openrouter' : model.id;
                                const modelUsage = quotaData.usage[trackingKey] || 0;
                                const isActive = trackingKey === activeModelUsed || (provider.name === 'OpenRouter' && activeModelUsed?.includes('openrouter'));
                                const pct = Math.min(100, Math.round((modelUsage / model.limit) * 100));

                                return (
                                  <div key={model.id} className="space-y-1">
                                    <div className="flex justify-between items-center text-[10px]">
                                      <span className={`${isActive ? 'text-cyan-400 font-bold' : 'text-zinc-400'}`}>
                                        {model.id} {isActive && <span className="text-[8px] bg-cyan-900/60 text-cyan-200 px-1 py-0.5 rounded-sm ml-1">ACTIVE</span>}
                                      </span>
                                      <span className="text-zinc-300 font-mono">
                                        {modelUsage} / {model.limit >= 1000 ? `${(model.limit / 1000).toFixed(1).replace('.0', '')}K` : model.limit} ({pct}%)
                                      </span>
                                    </div>
                                    <div className="h-1 w-full bg-zinc-800 rounded-full overflow-hidden">
                                      <div className={`h-full transition-all duration-300 ${getBarColor(pct)}`} style={{ width: `${Math.max(2, pct)}%` }} />
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                    <div className="pt-2 border-t border-zinc-800 text-[9px] text-zinc-500 text-center uppercase tracking-wider">
                      Zero API Overhead • Tracked Locally
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Very tiny, non-disturbing button to clear chat memory & eliminate lag */}
          <button
            onClick={() => setShowClearConfirm(true)}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-medium text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900 border border-transparent hover:border-zinc-800/80 transition-all cursor-pointer group shrink-0"
            title="Clear chat memory to stop lag (Formula Vault & Study Directives stay 100% safe)"
          >
            <Eraser className="w-3 h-3 text-zinc-500 group-hover:text-amber-400 transition-colors" />
            <span className="hidden sm:inline">Clear Chat</span>
          </button>

          {/* Fresh Thread Splitter Button */}
          <button
            onClick={() => {
              const boundaryMessage: ChatMessage = {
                id: `boundary-${Date.now()}`,
                role: 'model',
                text: `✂️ [CONTEXT BOUNDARY] A fresh context has been started here.`,
                timestamp: Date.now(),
                subject: currentSubject,
                isContextBoundary: true,
              };
              const updated = [...messages, boundaryMessage];
              setMessages(updated);
              saveStateToBackend(updated, pinnedVault);
            }}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-medium text-purple-400 hover:text-purple-300 hover:bg-purple-950/20 border border-transparent hover:border-purple-900/50 transition-all cursor-pointer group shrink-0"
            title="Start a fresh context here. Previous messages before this boundary are excluded from AI tokens for peak performance and speed!"
          >
            <span>✂️</span>
            <span className="hidden sm:inline">Fresh Thread</span>
          </button>
        </div>

        {/* Center / Controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Focus Timer */}
          <FocusTimer />

          <div className="relative flex items-center shrink-0">
            <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] shrink-0">
                <button
                  onClick={() => {
                    setModelPreference('auto');
                    setActiveModelUsed('gemini-flash-lite-latest');
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-all flex items-center gap-1 ${
                    modelPreference === 'auto'
                      ? 'bg-zinc-800 text-cyan-300 font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="Future-Proof Auto Cascade: gemini-flash-lite-latest + gemini-flash-latest + Gemma fallback"
                >
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  <span>Auto (Zero-Downtime Cascade)</span>
                </button>

                <button
                  onClick={() => {
                    setModelPreference('flash-lite');
                    setActiveModelUsed('gemini-flash-lite-latest');
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-all flex items-center gap-1 ${
                    modelPreference === 'flash-lite'
                      ? 'bg-zinc-800 text-emerald-300 font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="gemini-flash-lite-latest: Instant responses, 0ms queue, auto-rolling future version"
                >
                  <Zap className="w-3 h-3 text-emerald-400" />
                  <span>Flash Lite</span>
                </button>

                <button
                  onClick={() => {
                    setModelPreference('flash');
                    setActiveModelUsed('gemini-flash-latest');
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-all flex items-center gap-1 ${
                    modelPreference === 'flash'
                      ? 'bg-zinc-800 text-amber-300 font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="gemini-flash-latest: Cutting-edge multi-modal speed & precision, auto-rolling future version"
                >
                  <Zap className="w-3 h-3 text-amber-400" />
                  <span>Flash</span>
                </button>

                {/* Groq, OpenRouter & BazaarLink Toggle Button */}
                <button
                  onClick={() => {
                    if (modelPreference === 'groq') {
                      setModelPreference('openrouter');
                      setActiveModelUsed('openrouter');
                    } else if (modelPreference === 'openrouter') {
                      setModelPreference('bzl');
                      setActiveModelUsed('bzl');
                    } else if (modelPreference === 'bzl') {
                      setModelPreference('groq');
                      setActiveModelUsed(groqModels[0] || 'openai/gpt-oss-120b');
                    } else {
                      setModelPreference('groq');
                      setActiveModelUsed(groqModels[0] || 'openai/gpt-oss-120b');
                    }
                  }}
                  className={`px-2 py-0.5 rounded-md font-medium transition-all flex items-center gap-1 ${
                    modelPreference === 'bzl'
                      ? 'bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 font-semibold shadow-sm'
                      : modelPreference === 'openrouter'
                      ? 'bg-purple-950/80 border border-purple-500/50 text-purple-300 font-semibold shadow-sm'
                      : modelPreference === 'groq'
                      ? 'bg-orange-950/80 border border-orange-500/50 text-orange-300 font-semibold shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="Click to select Groq, click again for OpenRouter, 3rd click for bzl (BazaarLink vm/my-router)"
                >
                  {modelPreference === 'bzl' ? (
                    <>
                      <Zap className="w-3 h-3 text-cyan-400" />
                      <span>bzl</span>
                    </>
                  ) : modelPreference === 'openrouter' ? (
                    <>
                      <Globe className="w-3 h-3 text-purple-400" />
                      <span>OpenRouter (Free)</span>
                    </>
                  ) : modelPreference === 'groq' ? (
                    <>
                      <Cpu className="w-3 h-3 text-orange-400" />
                      <span>Groq (GPT OSS)</span>
                    </>
                  ) : (
                    <>
                      <Cpu className="w-3.5 h-3.5 text-zinc-400" />
                      <span>Groq / OpenRouter</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    setModelPreference('gemma');
                    setActiveModelUsed('gemma-4-26b-a4b-it');
                  }}
                  className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1 ${
                    modelPreference === 'gemma'
                      ? 'bg-zinc-800 text-sky-300 font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="Gemma 4 open foundation models with automated Gemini cascade"
                >
                  <BookOpen className="w-3.5 h-3.5 text-sky-400" />
                  <span>Gemma</span>
                </button>
              </div>
          </div>

          {/* Permanent Directive Shield Button */}
          <button
            onClick={() => setIsSystemPromptOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-emerald-500/40 text-emerald-400 text-xs font-semibold transition-all shrink-0"
            title="Inspect Locked Permanent JEE Study Directive"
          >
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span className="hidden lg:inline">Directive Locked</span>
          </button>

          {/* Formula Vault Button */}
          <button
            onClick={() => setIsVaultOpen(true)}
            className="relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold transition-all shrink-0"
            title="Formula & Tricks Vault"
          >
            <Bookmark className="w-4 h-4 text-violet-400 shrink-0" />
            <span className="hidden lg:inline">Vault</span>
            {pinnedVault.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-violet-600 text-white text-[10px] font-bold flex items-center justify-center">
                {pinnedVault.length}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Minimalist Subheader: Subject Filter Bar & Topic Shift */}
      <div className="shrink-0 px-4 sm:px-6 py-2 bg-black border-b border-zinc-800 flex items-center justify-between gap-3 overflow-x-auto text-xs">
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[11px] font-semibold text-zinc-500 uppercase tracking-wider mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Focus:
          </span>
          {(['All', 'Chemistry', 'Physics', 'Math', 'IT', 'English'] as const).map((sub) => (
            <button
              key={sub}
              onClick={() => setActiveSubjectFilter(sub)}
              className={`px-2 py-0.5 rounded-md transition-colors font-medium text-xs ${
                activeSubjectFilter === sub
                  ? 'bg-zinc-800 text-cyan-300 font-semibold border border-zinc-700'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              {sub === 'Chemistry'
                ? '🧪 Chem (Jam)'
                : sub === 'Physics'
                ? '⚡ Physics'
                : sub === 'Math'
                ? '📐 Math (NCERT)'
                : sub}
            </button>
          ))}

          {/* Teeny tiny Chat Search Button & Vault-style search input */}
          <div className="flex items-center gap-1.5 ml-1">
            <button
              type="button"
              onClick={() => {
                setIsChatSearchOpen(!isChatSearchOpen);
                if (!isChatSearchOpen) {
                  setTimeout(() => chatSearchInputRef.current?.focus(), 50);
                }
              }}
              className={`p-1 px-1.5 rounded-md text-xs transition-all flex items-center gap-1 cursor-pointer shrink-0 ${
                isChatSearchOpen || chatSearchQuery
                  ? 'bg-cyan-950/80 border border-cyan-500/50 text-cyan-300 font-semibold shadow-sm'
                  : 'bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
              title="Search current chat (like Vault search)"
            >
              <span className="text-xs leading-none">🔎</span>
              {chatSearchQuery.trim() && (
                <span className="text-[10px] font-mono text-cyan-400 font-bold">
                  {displayedMessages.filter((m) => {
                    const q = chatSearchQuery.toLowerCase();
                    return (
                      (m.text || '').toLowerCase().includes(q) ||
                      (m.thought || '').toLowerCase().includes(q) ||
                      (m.milestoneTitle || '').toLowerCase().includes(q)
                    );
                  }).length}
                </span>
              )}
            </button>

            {isChatSearchOpen && (
              <div className="relative flex items-center animate-in fade-in duration-150">
                <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  ref={chatSearchInputRef}
                  type="text"
                  placeholder="Search current chat..."
                  value={chatSearchQuery}
                  onChange={(e) => setChatSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') {
                      if (chatSearchQuery) {
                        setChatSearchQuery('');
                      } else {
                        setIsChatSearchOpen(false);
                      }
                    }
                  }}
                  className="w-36 sm:w-56 pl-7 pr-12 py-0.5 rounded-md bg-zinc-900 border border-zinc-700 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
                />
                <div className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center gap-0.5">
                  {chatSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setChatSearchQuery('')}
                      className="p-0.5 text-zinc-400 hover:text-zinc-100 text-[10px] rounded"
                      title="Clear search"
                    >
                      ✕
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setIsChatSearchOpen(false);
                      setChatSearchQuery('');
                    }}
                    className="p-0.5 text-zinc-500 hover:text-zinc-300 text-[10px] rounded"
                    title="Close search"
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2 px-2.5 py-1 rounded-md bg-zinc-900 border border-zinc-800 text-zinc-300 text-[11px] font-medium" title="Change how many past messages are sent with each new query (1 to 20)">
            <span className="text-zinc-400 whitespace-nowrap">
              History Limit: <span className="text-cyan-400 font-bold font-mono text-xs">{historyLimit}</span>
            </span>
            <input
              type="range"
              min="1"
              max="20"
              value={historyLimit}
              onChange={(e) => setHistoryLimit(parseInt(e.target.value, 10))}
              className="w-16 sm:w-24 accent-cyan-500 cursor-pointer h-1 rounded bg-zinc-800"
            />
          </div>

          <button
            onClick={() => setIsMilestoneModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-medium transition-colors"
            title="Anchor a new topic milestone without resetting or deleting past work"
          >
            <Milestone className="w-3.5 h-3.5 text-zinc-400" />
            <span>Shift Topic / Milestone</span>
          </button>
        </div>
      </div>

      {/* Continuous Messages Feed */}
      <main className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-6 bg-black">
        {/* Fallback Notice if triggered */}
        {fallbackNotice && (
          <div className="max-w-4xl mx-auto p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-amber-300 flex items-center gap-2 animate-in fade-in">
            <Zap className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{fallbackNotice}</span>
          </div>
        )}

        {/* Render Messages */}
        <div className="max-w-4xl mx-auto space-y-6">
          {chatSearchQuery.trim() && (
            <div className="p-2.5 rounded-lg bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-300 flex items-center justify-between animate-in fade-in">
              <div className="flex items-center gap-2">
                <span>🔎</span>
                <span>
                  Filtering chat for: <strong className="font-semibold text-white">&ldquo;{chatSearchQuery}&rdquo;</strong>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setChatSearchQuery('')}
                className="text-zinc-400 hover:text-white text-[11px] underline cursor-pointer"
              >
                Clear Search
              </button>
            </div>
          )}
          {displayedMessages.map((msg) => {
            if (chatSearchQuery.trim()) {
              const q = chatSearchQuery.toLowerCase();
              const textMatches = (msg.text || '').toLowerCase().includes(q);
              const thoughtMatches = (msg.thought || '').toLowerCase().includes(q);
              const milestoneMatches = (msg.milestoneTitle || '').toLowerCase().includes(q);
              if (!textMatches && !thoughtMatches && !milestoneMatches) {
                return null;
              }
            }
            const isUser = msg.role === 'user';
            const isMilestone = !!msg.milestoneTitle;

            if (msg.isContextBoundary) {
              return (
                <div key={msg.id} className="py-4 my-2 flex items-center gap-4 animate-in fade-in">
                  <div className="flex-1 h-px bg-purple-900/40" />
                  <div className="px-3.5 py-1.5 rounded-full bg-purple-950/30 border border-purple-500/20 text-purple-300 text-xs font-semibold flex items-center gap-2 shadow-sm">
                    <span>✂️</span>
                    <span>Fresh Thread Context (Prior messages excluded from AI tokens)</span>
                  </div>
                  <div className="flex-1 h-px bg-purple-900/40" />
                </div>
              );
            }

            if (isMilestone) {
              return (
                <div key={msg.id} className="py-4 my-2 flex items-center gap-4">
                  <div className="flex-1 h-px bg-zinc-800" />
                  <div className="px-3.5 py-1 rounded-full bg-zinc-900 border border-zinc-700 text-zinc-300 text-xs font-bold flex items-center gap-2">
                    <Milestone className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Topic Milestone: {msg.milestoneTitle}</span>
                  </div>
                  <div className="flex-1 h-px bg-zinc-800" />
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group`}
              >
                {/* Meta details above bubble */}
                <div className="flex items-center justify-between mb-1 px-1 text-[11px] text-zinc-500 w-full max-w-[94%] sm:max-w-[85%]">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-zinc-400">
                      {isUser ? 'You' : 'FocusJEE Coach'}
                    </span>
                    {msg.subject && (
                      <span className="px-1.5 py-0.2 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                        {msg.subject}
                      </span>
                    )}
                    {msg.modelUsed && !isUser && (
                      <span className="px-1.5 py-0.2 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                        {msg.modelUsed}
                      </span>
                    )}
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  {/* Edit and Delete Actions */}
                  <div className="flex items-center gap-1">
                    {isUser && editingMessageId !== msg.id && (
                      <button
                        onClick={() => handleStartEditMessage(msg)}
                        className="opacity-40 hover:opacity-100 transition-opacity p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-cyan-300 cursor-pointer"
                        title="Edit prompt"
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>
                    )}
                    {deletingMessageId === msg.id ? (
                      <div className="flex items-center gap-1 bg-rose-950/90 border border-rose-500/50 px-2 py-0.5 rounded text-[10px] text-rose-200 shadow-lg">
                        <span>Delete?</span>
                        <button
                          onClick={() => {
                            if (speakingMessageId === msg.id) {
                              if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                                window.speechSynthesis.cancel();
                              }
                              setSpeakingMessageId(null);
                              setIsPaused(false);
                              speechQueueRef.current = { messageId: '', chunks: [], currentIndex: 0 };
                            }
                            const updated = messages.filter((m) => m.id !== msg.id);
                            setMessages(updated);
                            setDeletingMessageId(null);
                            safeSaveMessagesToLocalStorage(updated);
                            saveStateToBackend(updated, pinnedVault);
                          }}
                          className="text-white font-bold px-1.5 py-0.2 bg-rose-600 rounded hover:bg-rose-500"
                        >
                          Yes
                        </button>
                        <button
                          onClick={() => setDeletingMessageId(null)}
                          className="text-zinc-300 px-1.5 py-0.2 bg-zinc-800 rounded hover:bg-zinc-700"
                        >
                          No
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeletingMessageId(msg.id)}
                        className="opacity-40 hover:opacity-100 transition-opacity p-0.5 rounded hover:bg-zinc-800 text-xs"
                        title="Delete message"
                        style={{ fontSize: '11px' }}
                      >
                        🗑️
                      </button>
                    )}
                  </div>
                </div>

                {/* Message Bubble */}
                <div
                  className={`relative p-5 rounded-2xl max-w-[94%] sm:max-w-[85%] transition-all ${
                    isUser
                      ? 'bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-tr-sm'
                      : 'bg-[#09090b] border border-zinc-800/90 text-zinc-200 rounded-tl-sm'
                  }`}
                >
                  {/* User Attachments Preview */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="mb-3.5 flex flex-wrap gap-2.5">
                      {msg.attachments.map((att) => {
                        const isImg = att.mimeType.startsWith('image/');
                        return (
                          <div
                            key={att.id}
                            className="relative group/att rounded-xl overflow-hidden border border-zinc-800 bg-black max-w-[200px]"
                          >
                            {isImg ? (
                              <div
                                onClick={() => setPreviewImage(att.dataUrl)}
                                className="cursor-pointer relative overflow-hidden"
                              >
                                <img
                                  src={att.dataUrl}
                                  alt={att.name}
                                  className="h-28 w-full object-cover rounded-lg group-hover/att:scale-105 transition-transform"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/att:opacity-100 flex items-center justify-center transition-opacity">
                                  <Maximize2 className="w-5 h-5 text-white" />
                                </div>
                              </div>
                            ) : (
                              <div className="p-3 flex items-center gap-2">
                                <FileText className="w-5 h-5 text-cyan-400 shrink-0" />
                                <div className="text-[11px] truncate">
                                  <p className="font-semibold text-zinc-200 truncate">{att.name}</p>
                                  <p className="text-zinc-500 uppercase">{att.mimeType.split('/')[1] || 'DOC'}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {isUser ? (
                    editingMessageId === msg.id ? (
                      <div className="space-y-2.5 pt-1">
                        <textarea
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                              e.preventDefault();
                              handleSaveAndResend(msg.id);
                            } else if (e.key === 'Escape') {
                              setEditingMessageId(null);
                            }
                          }}
                          rows={Math.max(2, Math.min(8, editText.split('\n').length + 1))}
                          className="w-full p-2.5 bg-black border border-cyan-500/70 rounded-xl text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none leading-relaxed resize-y font-normal"
                          autoFocus
                          placeholder="Edit your prompt..."
                        />
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-[10px] text-zinc-500 font-mono">
                            Ctrl+Enter to save & resend • Esc to cancel
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setEditingMessageId(null)}
                              className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium cursor-pointer transition-colors"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveAndResend(msg.id)}
                              disabled={!editText.trim()}
                              className="px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-black font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors shadow-sm"
                            >
                              <Send className="w-3 h-3" />
                              <span>Save & Resend</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-[16.5px] leading-relaxed font-normal">
                        <MarkdownRenderer content={msg.text} textSizeLevel={textSizeLevel} />
                      </div>
                    )
                  ) : (
                    <div>
                      {msg.thought && <ThoughtSection thought={msg.thought} />}
                      <MarkdownRenderer content={msg.text} textSizeLevel={textSizeLevel} />
                    </div>
                  )}

                  {/* Actions Bar for Message: Copy as Markdown & Edit Prompt & Pin */}
                  <div className="mt-3.5 pt-2.5 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCopyMarkdown(msg.text, msg.id)}
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs cursor-pointer"
                        title="Copy raw markdown to clipboard"
                      >
                        {copiedMessageId === msg.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400 font-medium">Copied Markdown!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Markdown</span>
                          </>
                        )}
                      </button>

                      {isUser && editingMessageId !== msg.id && (
                        <button
                          onClick={() => handleStartEditMessage(msg)}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-cyan-300 transition-colors text-xs cursor-pointer group/edit"
                          title="Edit this prompt and re-generate answer"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-zinc-400 group-hover/edit:text-cyan-300" />
                          <span>Edit Prompt</span>
                        </button>
                      )}

                      {!isUser && (
                        <button
                          onClick={() => handlePinToVault(msg)}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-violet-300 transition-colors text-xs"
                          title="Pin formulas & tricks from this answer to your vault"
                        >
                          <Bookmark className="w-3.5 h-3.5 text-violet-400" />
                          <span>Pin to Vault</span>
                        </button>
                      )}

                      {!isUser && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleReadAloud(msg.text, msg.id)}
                            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs"
                            title="Read aloud using browser speech synthesis (Zero API quota)"
                          >
                            {speakingMessageId === msg.id ? (
                              <>
                                <VolumeX className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                                <span className="text-rose-400 font-medium">Stop Audio</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                                <span>Read Aloud</span>
                              </>
                            )}
                          </button>
                          {speakingMessageId === msg.id && (
                            <button
                              onClick={handlePauseResume}
                              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors text-xs"
                              title={isPaused ? "Resume reading" : "Pause reading"}
                            >
                              {isPaused ? <Play className="w-3.5 h-3.5 text-emerald-400" /> : <Pause className="w-3.5 h-3.5 text-amber-400" />}
                              <span className={isPaused ? "text-emerald-400 font-medium" : "text-amber-400 font-medium"}>
                                {isPaused ? 'Resume' : 'Pause'}
                              </span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    {!isUser && (
                      <span className="text-[11px] text-zinc-500 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500/70" />
                        Directive Enforced
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {chatSearchQuery.trim() && displayedMessages.filter((m) => {
            const q = chatSearchQuery.toLowerCase();
            return (
              (m.text || '').toLowerCase().includes(q) ||
              (m.thought || '').toLowerCase().includes(q) ||
              (m.milestoneTitle || '').toLowerCase().includes(q)
            );
          }).length === 0 && (
            <div className="flex flex-col items-center justify-center p-8 text-center text-zinc-500 rounded-xl bg-zinc-950/60 border border-zinc-800 my-6 animate-in fade-in">
              <span className="text-2xl mb-2">🔎</span>
              <p className="text-sm font-medium text-zinc-300">
                No chat messages match &ldquo;{chatSearchQuery}&rdquo;
              </p>
              <p className="text-xs text-zinc-500 mt-1">
                Try searching for a different keyword, formula, or concept.
              </p>
              <button
                type="button"
                onClick={() => setChatSearchQuery('')}
                className="mt-3 px-3 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-300 transition-colors cursor-pointer"
              >
                Clear Search Filter
              </button>
            </div>
          )}

          {/* Active Streaming Response Bubble */}
          {isLoading && (activeStreamingText || activeStreamingThought || isThinkingActive) && (
            <div className="flex flex-col items-start group">
              <div className="flex items-center gap-2 mb-1 px-1 text-[11px] text-zinc-500">
                <span className="font-semibold text-cyan-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  Synthesizing Breakdown...
                </span>
                <span className="px-1.5 py-0.2 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                  {activeModelUsed || 'Gemini Flash'}
                </span>
              </div>
              <div className="relative p-5 rounded-2xl max-w-[94%] sm:max-w-[85%] bg-[#09090b] border border-cyan-500/30 text-zinc-200 rounded-tl-sm shadow-xl">
                {activeStreamingThought && (
                  <ThoughtSection thought={activeStreamingThought} isLive={true} />
                )}

                {isThinkingActive && !activeStreamingThought && !activeStreamingText && (
                  <div className="flex items-center gap-2 text-xs text-purple-400 animate-pulse mb-3 p-2 rounded-lg bg-purple-950/20 border border-purple-500/30">
                    <span className="text-sm">🧠</span>
                    <span className="font-semibold">Deep Reasoning in progress...</span>
                  </div>
                )}

                {activeStreamingText ? (
                  <MarkdownRenderer content={activeStreamingText} textSizeLevel={textSizeLevel} />
                ) : (
                  !activeStreamingThought && (
                    <div className="w-6 h-1 bg-cyan-500/50 rounded animate-pulse" />
                  )
                )}
                <div className="flex items-center gap-2 mt-3 pt-2 text-xs text-cyan-400 animate-pulse">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Connecting concepts & calculating mental shortcuts...</span>
                </div>
              </div>
            </div>
          )}

          {/* Loading indicator before any chunk or thoughts arrive */}
          {isLoading && !activeStreamingText && !activeStreamingThought && !isThinkingActive && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-zinc-900 border border-zinc-800 max-w-md">
              <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin shrink-0" />
              <div className="text-xs text-zinc-300">
                <p className="font-semibold text-zinc-200">
                  {modelPreference === 'groq'
                    ? 'Consulting Groq GPT OSS Engine...'
                    : modelPreference === 'openrouter'
                    ? 'Consulting OpenRouter Engine...'
                    : 'Consulting Active Gemini Engine...'}
                </p>
                <p className="text-zinc-500 text-[11px]">Enforcing permanent JEE & AuDHD study matrix</p>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Sticky Bottom Input Bar (Minimalist, Distraction-Free, Multimodal) */}
      <footer className="shrink-0 p-3 sm:p-4 bg-black border-t border-zinc-800 z-20">
        <div className="max-w-4xl mx-auto">
          {/* Controls above input: Subject Selector & ADHD Redirect helper */}
          <div className="flex items-center justify-between gap-2 mb-2 text-xs">
            <div className="flex items-center gap-1">
              <span className="text-zinc-500 font-medium hidden sm:inline mr-1">Subject:</span>
              {(['Chemistry', 'Physics', 'Math', 'IT', 'English'] as const).map((sub) => (
                <button
                  key={sub}
                  type="button"
                  onClick={() => setCurrentSubject(sub)}
                  className={`px-2 py-0.5 rounded-md font-semibold transition-all ${
                    currentSubject === sub
                      ? 'bg-zinc-800 text-cyan-300 border border-zinc-700'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                  }`}
                >
                  {sub === 'Chemistry'
                    ? '🧪 Chem (Jam)'
                    : sub === 'Math'
                    ? '📐 Math (NCERT)'
                    : sub}
                </button>
              ))}
            </div>

            {/* Right controls above input: Think Harder & Health Check */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setThinkHarder((prev) => !prev)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  thinkHarder
                    ? 'bg-purple-950/90 border border-purple-500 text-purple-200 shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                    : 'bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
                title="Think Harder: Triggers maximum reasoning effort and extended thinking tokens for difficult derivations and JEE numericals"
              >
                <span className="text-sm leading-none">🧠</span>
                <span className="font-semibold">Think Harder</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                    thinkHarder ? 'bg-purple-500/40 text-purple-200' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {thinkHarder ? 'ON' : 'OFF'}
                </span>
              </button>

              {/* Hidden Discreet Model Health & Cascade Editor Triggers */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={checkModelHealth}
                  disabled={isCheckingHealth}
                  className="group flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] text-zinc-600 hover:text-zinc-400 hover:bg-zinc-900 transition-all cursor-pointer select-none"
                  title="Google AI Model Health & Deprecation Monitor (Click to verify live Google GenAI status)"
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full transition-all ${
                      healthData?.deprecated_or_missing?.length || healthData?.disabledInSession?.length
                        ? 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)] animate-pulse'
                        : 'bg-emerald-500/40 group-hover:bg-emerald-400'
                    }`}
                  />
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] text-zinc-500 font-mono">
                    {isCheckingHealth ? 'checking...' : 'health'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={openCascadeEditorModal}
                  className="group flex items-center gap-1 px-2 py-0.5 rounded text-[10px] text-zinc-600 hover:text-cyan-300 hover:bg-zinc-900 transition-all cursor-pointer select-none font-mono"
                  title="Edit Gemini Cascades & Thinking Levels"
                >
                  <Edit3 className="w-2.5 h-2.5 opacity-60 group-hover:opacity-100 transition-opacity" />
                  <span className="opacity-70 group-hover:opacity-100 transition-opacity">cascades</span>
                </button>
              </div>
            </div>
          </div>

          {/* Pending Attachments Strip */}
          {pendingAttachments.length > 0 && (
            <div className="mb-2 p-2 rounded-xl bg-zinc-900 border border-zinc-800 flex flex-wrap gap-2 items-center">
              {pendingAttachments.map((att) => {
                const isImg = att.mimeType.startsWith('image/');
                return (
                  <div
                    key={att.id}
                    className="flex items-center gap-2 p-1.5 pl-2 pr-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-zinc-200 group"
                  >
                    {isImg ? (
                      <img
                        src={att.dataUrl}
                        alt={att.name}
                        className="w-6 h-6 object-cover rounded"
                      />
                    ) : (
                      <FileText className="w-4 h-4 text-cyan-400" />
                    )}
                    <span className="max-w-[130px] truncate text-[11px] font-medium">
                      {att.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => removePendingAttachment(att.id)}
                      className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-rose-400 transition-colors"
                      title="Remove attachment"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
              <span className="text-[11px] text-zinc-500 ml-1">
                {pendingAttachments.length} file(s) attached
              </span>
            </div>
          )}

          {/* Main Input Form with Paste & Voice & Upload Support */}
          <div className="relative flex items-end gap-2 bg-[#09090b] border border-zinc-800 rounded-2xl p-2 focus-within:border-zinc-600 shadow-inner">
            {/* Hidden File Input */}
            <input
              type="file"
              ref={fileInputRef}
              multiple
              accept="image/*,application/pdf,text/*"
              onChange={(e) => {
                if (e.target.files) processFiles(e.target.files);
                e.target.value = '';
              }}
              className="hidden"
            />

            {/* Upload Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400 hover:text-zinc-100 transition-colors shrink-0 cursor-pointer"
              title="Upload question diagram or document (PDF / Images)"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Teeny tiny (※) button & Auto-adjustable Mini Prompt Drawer */}
            <div className="relative shrink-0">
              <button
                ref={miniPromptTriggerRef}
                type="button"
                onClick={() => setIsMiniPromptOpen((prev) => !prev)}
                className={`p-2 rounded-xl border transition-all shrink-0 cursor-pointer flex items-center justify-center font-mono select-none ${
                  isMiniPromptOpen
                    ? 'bg-cyan-950/70 border-cyan-500/80 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                    : 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-cyan-300'
                }`}
                title="Mini Prompts (※) - Quick append prompt snippets"
              >
                <span className="text-[12px] leading-none font-bold">※</span>
              </button>

              <MiniPromptDrawer
                isOpen={isMiniPromptOpen}
                onClose={() => setIsMiniPromptOpen(false)}
                onInsertPrompt={handleInsertMiniPrompt}
                triggerRef={miniPromptTriggerRef}
              />
            </div>

            {/* Textarea with Clipboard Paste support */}
            <textarea
              ref={textareaRef}
              value={inputPrompt}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              onPaste={handlePaste}
              disabled={!isAuthenticated}
              placeholder={!isAuthenticated ? 'Please enter Master Access Key to study...' : `Ask a JEE / NCERT question in ${currentSubject} (or paste image/diagram)...`}
              rows={1}
              className="flex-1 max-h-44 bg-transparent text-zinc-100 placeholder-zinc-500 text-sm px-2 py-1.5 focus:outline-none resize-none leading-relaxed disabled:opacity-40 disabled:cursor-not-allowed"
            />

            {/* Send or Stop/Pause Button */}
            {isLoading ? (
              <button
                type="button"
                onClick={handleStopStreaming}
                className="p-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/70 text-amber-300 hover:text-amber-200 font-bold transition-all shrink-0 cursor-pointer flex items-center justify-center shadow-[0_0_12px_rgba(245,158,11,0.25)] animate-pulse"
                title="Pause / Stop answer"
              >
                <Pause className="w-4 h-4 fill-amber-300" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => sendMessage()}
                disabled={!isAuthenticated || (!inputPrompt.trim() && pendingAttachments.length === 0)}
                className="p-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 disabled:hover:bg-zinc-800 text-white font-bold transition-all shrink-0 border border-zinc-700 cursor-pointer"
                title="Send to FocusJEE"
              >
                <Send className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </footer>

      {/* Modals */}
      <SystemPromptModal
        isOpen={isSystemPromptOpen}
        onClose={() => setIsSystemPromptOpen(false)}
      />

      <FormulaVaultModal
        isOpen={isVaultOpen}
        onClose={() => setIsVaultOpen(false)}
        pinnedItems={pinnedVault}
        onRemoveItem={handleRemovePinnedItem}
      />

      {/* Image Preview Lightbox Modal */}
      {previewImage && (
        <div
          onClick={() => setPreviewImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={previewImage}
              alt="Enlarged study diagram"
              className="max-w-full max-h-[85vh] object-contain rounded-xl border border-zinc-800 shadow-2xl"
            />
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/70 text-zinc-300 hover:text-white border border-zinc-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Chapter Milestone Modal */}
      {isMilestoneModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl text-zinc-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Milestone className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-zinc-100 text-base">New Topic Milestone</h3>
              </div>
              <button
                onClick={() => setIsMilestoneModalOpen(false)}
                className="text-zinc-400 hover:text-zinc-200"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-zinc-400">
              Anchor a new chapter or topic milestone in your continuous study stream without deleting past work.
            </p>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Chapter / Topic Name
              </label>
              <input
                type="text"
                autoFocus
                placeholder="e.g. Thermodynamics: Second Law & Entropy"
                value={milestoneTitleInput}
                onChange={(e) => setMilestoneTitleInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddMilestone(milestoneTitleInput);
                }}
                className="w-full px-3 py-2 rounded-xl bg-black border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-zinc-600"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsMilestoneModalOpen(false)}
                className="px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-xs font-semibold text-zinc-300 border border-zinc-800"
              >
                Cancel
              </button>
              <button
                onClick={() => handleAddMilestone(milestoneTitleInput)}
                disabled={!milestoneTitleInput.trim()}
                className="px-4 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-xs font-semibold text-white transition-colors border border-zinc-700"
              >
                Anchor Milestone
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear Chat Memory Safety Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl text-zinc-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                  <Eraser className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-bold text-zinc-100 text-sm sm:text-base">Clear Chat History?</h3>
                  <p className="text-[11px] text-zinc-400">Resets active conversation turns to eliminate lag</p>
                </div>
              </div>
              <button
                onClick={() => setShowClearConfirm(false)}
                className="p-1 rounded-lg text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800/80 space-y-2 text-xs">
              <div className="flex items-start gap-2 text-emerald-400">
                <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0" />
                <span>
                  <strong>System Directive Protected:</strong> Your permanent AuDHD JEE study prompt, no-calculator rules, and supportive tone remain 100% active.
                </span>
              </div>
              <div className="flex items-start gap-2 text-cyan-400">
                <Bookmark className="w-4 h-4 mt-0.5 shrink-0" />
                <span>
                  <strong>Formula Vault Safe:</strong> All your pinned formulas, derivations, and tricks stay completely intact in your Vault.
                </span>
              </div>
            </div>

            <p className="text-xs text-zinc-400 leading-relaxed">
              Are you sure you want to clear previous questions? This clears the token payload and chain-of-thought overhead so your next questions respond instantaneously.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-xs font-semibold text-zinc-300 border border-zinc-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleClearChatHistory}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-xs font-semibold text-white transition-colors flex items-center gap-1.5 shadow-lg shadow-amber-950/40"
              >
                <Eraser className="w-3.5 h-3.5" />
                <span>Yes, Clear Chat</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Model Deprecation & Health Checker Modal */}
      {isHealthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-lg p-5 space-y-4 shadow-2xl text-zinc-100">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-zinc-100 text-sm">Model Health & Deprecation Monitor</h3>
                  <p className="text-[11px] text-zinc-500">Live verification against Google GenAI API upstream catalog</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setConfirmClearDisabled(false);
                  setIsHealthModalOpen(false);
                }}
                className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Warning or Success Notice */}
            {healthData && healthData.deprecated_or_missing && healthData.deprecated_or_missing.length > 0 ? (
              <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/50 text-amber-200 text-xs space-y-2.5">
                <div className="flex items-start gap-2">
                  <span className="text-base">⚠️</span>
                  <div>
                    <p className="font-semibold text-amber-300">
                      {healthData.deprecated_or_missing.length} Model{healthData.deprecated_or_missing.length > 1 ? 's' : ''} Deprecated Upstream
                    </p>
                    <p className="text-[11px] text-amber-200/80 mt-0.5">
                      The fallback cascade is automatically bypassing them to guarantee zero downtime.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {healthData.deprecated_or_missing.map((m) => (
                    <span key={m} className="px-2 py-0.5 rounded bg-amber-900/60 border border-amber-600/50 text-amber-200 font-mono text-[10px]">
                      ⚠️ {m}
                    </span>
                  ))}
                </div>

                {/* Copy Update Prompt Button */}
                <div className="pt-1 flex justify-end">
                  <button
                    onClick={() => {
                      const prompt = `Please remove deprecated model(s) '${healthData.deprecated_or_missing.join("', '")}' from the cascade arrays in server.ts and src/App.tsx, and replace them with the latest active Gemini models.`;
                      navigator.clipboard.writeText(prompt);
                      setCopiedHealthPrompt(true);
                      setTimeout(() => setCopiedHealthPrompt(false), 2500);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-all shadow-sm cursor-pointer"
                  >
                    {copiedHealthPrompt ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-black" />
                        <span>Prompt Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-black" />
                        <span>Copy Update Prompt</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <p className="font-semibold text-emerald-300">All Cascade Models Healthy & Active</p>
                  <p className="text-[11px] text-emerald-400/80">
                    Verified {healthData?.totalAvailableUpstream || 61} models currently available in Google GenAI API.
                  </p>
                </div>
              </div>
            )}

            {/* Session-Disabled Models Notice (if any) */}
            {healthData && healthData.disabledInSession && healthData.disabledInSession.length > 0 && (
              <div className="px-3 py-2 rounded-lg bg-zinc-900/80 border border-amber-500/30 text-[11px] text-amber-200/90 flex items-center justify-between gap-2 flex-wrap">
                <span>
                  Session-disabled ({healthData.disabledInSession.length}):{' '}
                  <span className="font-mono text-amber-300">{healthData.disabledInSession.join(', ')}</span>
                </span>
              </div>
            )}

            {disabledResetNotice && (
              <p className="text-[11px] text-emerald-400 px-1">{disabledResetNotice}</p>
            )}

            {/* Detailed Models List */}
            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 scrollbar-thin">
              <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider px-1">Cascade Model Status</p>
              {healthData?.active?.map((model) => (
                <div key={model} className="flex items-center justify-between p-2 rounded-lg bg-zinc-950 border border-zinc-800/80 text-xs">
                  <span className="font-mono text-zinc-300 text-[11px]">{model}</span>
                  <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/50 border border-emerald-800/60 px-2 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> ACTIVE
                  </span>
                </div>
              ))}
              {healthData?.deprecated_or_missing?.map((model) => (
                <div key={model} className="flex items-center justify-between p-2 rounded-lg bg-zinc-950 border border-amber-900/40 text-xs">
                  <span className="font-mono text-zinc-400 text-[11px]">{model}</span>
                  <span className="flex items-center gap-1 text-[10px] font-semibold text-amber-400 bg-amber-950/50 border border-amber-800/60 px-2 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400" /> BYPASSED
                  </span>
                </div>
              ))}
            </div>

            {/* Modal Footer */}
            <div className="pt-2 border-t border-zinc-800 flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] text-zinc-500 font-mono">
                  {healthData?.timestamp ? `Checked: ${new Date(healthData.timestamp).toLocaleTimeString()}` : ''}
                </span>
                {confirmClearDisabled ? (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-zinc-900 border border-amber-500/40 text-[10px]">
                    <span className="text-amber-200">Clear disabled?</span>
                    <button
                      type="button"
                      disabled={isClearingDisabled}
                      onClick={handleClearDisabledModels}
                      className="px-1.5 py-0.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-semibold cursor-pointer disabled:opacity-40"
                    >
                      {isClearingDisabled ? '...' : 'Yes'}
                    </button>
                    <button
                      type="button"
                      disabled={isClearingDisabled}
                      onClick={() => setConfirmClearDisabled(false)}
                      className="px-1.5 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
                    >
                      No
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmClearDisabled(true)}
                    title="Re-enable all session-disabled models without changing cascades"
                    className="px-2 py-0.5 rounded-md bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 text-[10px] text-zinc-400 hover:text-amber-300 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <RotateCcw className="w-2.5 h-2.5" />
                    <span>Clear Disabled</span>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setConfirmClearDisabled(false);
                    setIsHealthModalOpen(false);
                    openCascadeEditorModal();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/70 border border-cyan-500/40 text-xs font-medium text-cyan-300 transition-colors cursor-pointer"
                >
                  Edit Cascades
                </button>
                <button
                  onClick={checkModelHealth}
                  disabled={isCheckingHealth}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 transition-colors cursor-pointer"
                >
                  {isCheckingHealth ? 'Checking...' : 'Re-check Now'}
                </button>
                <button
                  onClick={() => {
                    setConfirmClearDisabled(false);
                    setIsHealthModalOpen(false);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-300 transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Gemini Cascades & Thinking-Level Editor Modal */}
      {isCascadeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-[#09090b] border border-zinc-800 rounded-2xl w-full max-w-2xl p-5 space-y-4 shadow-2xl text-zinc-100 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3 shrink-0">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-zinc-100 text-sm sm:text-base">Model Cascades & Thinking Levels</h3>
                  <p className="text-[11px] text-zinc-500">Add, remove, or drag model cards up/down to reorder priority</p>
                </div>
              </div>
              <button
                onClick={() => setIsCascadeModalOpen(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Subtle Scope & Gemma Rule Notice */}
            <div className="p-2.5 rounded-xl bg-zinc-900/70 border border-zinc-800 text-[11px] text-zinc-400 leading-relaxed shrink-0">
              {activeEditorTab === 'groq' ? (
                <>
                  Groq runs configured models in order, then falls back to live <code className="text-zinc-300">models.list()</code> discovery. OpenRouter &amp; BazaarLink use dynamic routers and require no model edits.
                </>
              ) : (
                <>
                  Edits Gemini SDK &amp; Groq Primary/Secondary cascades. OpenRouter &amp; BazaarLink use routers. Gemma models automatically receive Study Directive via prompt (no <code className="text-zinc-300">systemInstruction</code>/<code className="text-zinc-300">thinkingConfig</code>).
                </>
              )}
            </div>

            {/* Tab Groups */}
            <div className="space-y-2 shrink-0">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">Gemini Cascades</p>
                <div className="flex flex-wrap gap-1.5">
                  {(
                    [
                      { key: 'auto', label: 'Auto' },
                      { key: 'flash-lite', label: 'Flash Lite' },
                      { key: 'flash', label: 'Flash' },
                      { key: 'gemma', label: 'Gemma' },
                      { key: 'thinkHarder', label: 'Think Harder' },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.key}
                      type="button"
                      onClick={() => {
                        setActiveEditorTab(tab.key);
                        setCascadeNotice(null);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                        activeEditorTab === tab.key
                          ? 'bg-cyan-950/70 border-cyan-500/60 text-cyan-200'
                          : 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {tab.label} ({geminiCascades[tab.key].length})
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">Think Harder Levels</p>
                  <div className="flex flex-wrap gap-1.5">
                    {(
                      [
                        { key: 'think-xhigh', label: `Think: XHIGH (${geminiThinkingLevels.xhigh.length})` },
                        { key: 'think-high', label: `Think: HIGH (${geminiThinkingLevels.high.length})` },
                      ] as const
                    ).map((tab) => (
                      <button
                        key={tab.key}
                        type="button"
                        onClick={() => {
                          setActiveEditorTab(tab.key);
                          setCascadeNotice(null);
                        }}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                          activeEditorTab === tab.key
                            ? 'bg-purple-950/70 border-purple-500/60 text-purple-200'
                            : 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500 mb-1">Groq (Primary &amp; Secondary)</p>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveEditorTab('groq');
                        setCascadeNotice(null);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                        activeEditorTab === 'groq'
                          ? 'bg-orange-950/70 border-orange-500/60 text-orange-200'
                          : 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      Groq Cascade ({groqModels.length})
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Tab-specific note */}
            {activeEditorTab === 'thinkHarder' && (
              <div className="px-3 py-1.5 rounded-lg bg-purple-950/30 border border-purple-500/30 text-[11px] text-purple-300 shrink-0">
                Active whenever Think Harder is ON
              </div>
            )}

            {/* Add Model Bar */}
            {(() => {
              const isThinkingTab = activeEditorTab === 'think-xhigh' || activeEditorTab === 'think-high';
              const isGroqTab = activeEditorTab === 'groq';
              const normalizedPreview = normalizeClientModelId(newModelInput);
              const isGemmaInput = normalizedPreview.toLowerCase().startsWith('gemma');

              return (
                <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2 shrink-0">
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={newModelInput}
                      onChange={(e) => setNewModelInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !cascadeSaving && newModelInput.trim()) {
                          e.preventDefault();
                          handleAddModelToActiveTab();
                        }
                      }}
                      placeholder={
                        isGroqTab
                          ? 'e.g. openai/gpt-oss-120b or llama-3.3-70b-versatile'
                          : 'e.g. gemini-4-argon or models/gemini-3.7-flash'
                      }
                      className="flex-1 px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs font-mono text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-cyan-500/60"
                    />
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <select
                        value={addPosition}
                        onChange={(e) => setAddPosition(e.target.value as 'top' | 'end')}
                        className="px-2 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-300 focus:outline-none"
                        title="Insert position"
                      >
                        <option value="top">Top</option>
                        <option value="end">End</option>
                      </select>

                      {!isThinkingTab && !isGroqTab && (
                        <select
                          value={isGemmaInput ? 'unchanged' : addThinkingChoice}
                          disabled={isGemmaInput}
                          onChange={(e) => setAddThinkingChoice(e.target.value as 'unchanged' | 'high' | 'xhigh')}
                          className="px-2 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-300 focus:outline-none disabled:opacity-40 disabled:cursor-not-allowed"
                          title="Think Level (optional when adding to a cascade)"
                        >
                          <option value="unchanged">Think: Unchanged / None</option>
                          <option value="high">Think: HIGH</option>
                          <option value="xhigh">Think: XHIGH</option>
                        </select>
                      )}

                      <button
                        type="button"
                        disabled={cascadeSaving || !newModelInput.trim()}
                        onClick={handleAddModelToActiveTab}
                        className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-xs font-semibold text-white transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </button>
                    </div>
                  </div>

                  {cascadeNotice && (
                    <p className="text-[11px] text-amber-300">{cascadeNotice}</p>
                  )}
                </div>
              );
            })()}

            {/* Models List (Drag-and-Drop Reorderable) */}
            {(() => {
              const isThinkingTab = activeEditorTab === 'think-xhigh' || activeEditorTab === 'think-high';
              const isGroqTab = activeEditorTab === 'groq';
              const activeList =
                isGroqTab
                  ? groqModels
                  : activeEditorTab === 'think-xhigh'
                  ? geminiThinkingLevels.xhigh
                  : activeEditorTab === 'think-high'
                  ? geminiThinkingLevels.high
                  : geminiCascades[activeEditorTab as GeminiCascadeKey];

              if (activeList.length === 0) {
                return (
                  <div className="flex-1 min-h-0 overflow-y-auto pr-1 scrollbar-thin">
                    <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs text-center">
                      {isGroqTab
                        ? 'No fixed Groq models — requests go straight to dynamic models.list() auto-discovery.'
                        : isThinkingTab
                        ? 'No models configured in this thinking tier.'
                        : 'Empty list — runtime temporarily falls back to defaults until you add a model or reset.'}
                    </div>
                  </div>
                );
              }

              return (
                <Reorder.Group
                  axis="y"
                  values={activeList}
                  onReorder={handleLiveReorder}
                  layoutScroll
                  className="flex-1 min-h-0 overflow-y-auto space-y-1.5 pr-1 scrollbar-thin"
                >
                  {activeList.map((modelId, idx) => {
                    const badge = isGroqTab
                      ? idx === 0
                        ? { label: 'Primary', style: 'bg-orange-950/70 border-orange-500/60 text-orange-300' }
                        : idx === 1
                        ? { label: 'Secondary', style: 'bg-amber-950/60 border-amber-600/50 text-amber-300' }
                        : { label: 'Fallback', style: 'bg-zinc-900 border-zinc-700 text-zinc-400' }
                      : !isThinkingTab
                      ? getModelBehaviorBadge(modelId)
                      : null;
                    return (
                      <Reorder.Item
                        key={modelId}
                        value={modelId}
                        onDragEnd={handleDragReorderCommit}
                        whileDrag={{
                          scale: 1.015,
                          zIndex: 20,
                          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.65)',
                        }}
                        className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition-colors cursor-grab active:cursor-grabbing select-none"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <GripVertical className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                          <span className="text-[10px] font-mono text-zinc-500 w-5 text-right shrink-0">
                            #{idx + 1}
                          </span>
                          <span className="font-mono text-xs text-zinc-200 truncate">{modelId}</span>
                          {badge && (
                            <span className={`px-1.5 py-0.5 rounded border text-[10px] font-semibold shrink-0 ${badge.style}`}>
                              {badge.label}
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          disabled={cascadeSaving}
                          onPointerDown={(e) => e.stopPropagation()}
                          onClick={() => handleDeleteModelFromActiveTab(modelId)}
                          className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer shrink-0 disabled:opacity-40"
                          title={`Delete ${modelId}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </Reorder.Item>
                    );
                  })}
                </Reorder.Group>
              );
            })()}

            {/* Modal Footer */}
            <div className="pt-2 border-t border-zinc-800 flex items-center justify-between gap-2 flex-wrap shrink-0">
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  disabled={cascadeSaving}
                  onClick={handleResetAllCascades}
                  className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-rose-500/40 text-xs font-medium text-rose-300 transition-colors cursor-pointer disabled:opacity-40"
                >
                  Reset All to Defaults
                </button>
                <button
                  type="button"
                  disabled={cascadeSaving}
                  onClick={handleExportCascadeConfig}
                  className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-medium text-zinc-200 transition-colors cursor-pointer disabled:opacity-40 flex items-center gap-1.5"
                  title="Download current cascades and thinking levels as a JSON file"
                >
                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Export Configuration</span>
                </button>
                <input
                  ref={cascadeImportInputRef}
                  type="file"
                  accept=".json,application/json"
                  onChange={handleImportCascadeConfig}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={cascadeSaving}
                  onClick={() => cascadeImportInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-medium text-zinc-200 transition-colors cursor-pointer disabled:opacity-40 flex items-center gap-1.5"
                  title="Upload a JSON configuration file to overwrite current settings"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Import</span>
                </button>
                {confirmClearDisabled ? (
                  <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-zinc-900 border border-amber-500/40 text-[11px]">
                    <span className="text-amber-200">Clear disabled list?</span>
                    <button
                      type="button"
                      disabled={isClearingDisabled}
                      onClick={handleClearDisabledModels}
                      className="px-1.5 py-0.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-semibold cursor-pointer disabled:opacity-40"
                    >
                      {isClearingDisabled ? '...' : 'Yes'}
                    </button>
                    <button
                      type="button"
                      disabled={isClearingDisabled}
                      onClick={() => setConfirmClearDisabled(false)}
                      className="px-1.5 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 cursor-pointer"
                    >
                      No
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={isClearingDisabled}
                    onClick={() => setConfirmClearDisabled(true)}
                    className="px-2 py-1 rounded-lg bg-zinc-900/70 hover:bg-zinc-800 border border-zinc-800 text-[11px] font-medium text-zinc-400 hover:text-amber-300 transition-colors cursor-pointer disabled:opacity-40 flex items-center gap-1"
                    title="Re-enable all session-disabled models without changing cascades"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Clear Disabled</span>
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  setConfirmClearDisabled(false);
                  setIsCascadeModalOpen(false);
                }}
                className="px-4 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-100 transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Server-Enforced Authentication Gate Modal (One-Time local storage session) */}
      {!isAuthenticated && !isAuthChecking && (
        <AuthGateModal
          onSuccess={(token) => {
            setAuthToken(token);
            setIsAuthenticated(true);
            loadStudyState(token);
          }}
        />
      )}

    </div>
  );
}
