export type SubjectType = 'Chemistry' | 'Physics' | 'Math' | 'IT' | 'English' | 'General';

export type ModelPreference = 'auto' | 'flash-lite' | 'flash' | 'gemma' | 'groq' | 'openrouter' | 'bzl';

export interface AttachmentItem {
  id: string;
  name: string;
  mimeType: string;
  data: string; // base64 without header
  dataUrl: string; // full base64 data url for preview
  size?: number;
}

export interface VisualData {
  type: 'line' | 'bar' | 'area' | 'pie' | 'comparison' | 'timeline' | 'process' | 'simulation';
  title: string;
  description?: string;
  data: any[];
  xAxisKey?: string;
  dataKey?: string | string[];
  color?: string | string[];
  simType?: 'photoelectric' | 'bohr' | 'projectile' | 'titration' | 'circuits';
  simConfig?: Record<string, any>;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  subject?: SubjectType;
  milestoneTitle?: string;
  modelUsed?: string;
  isPinned?: boolean;
  attachments?: AttachmentItem[];
  isContextBoundary?: boolean;
  thought?: string;
  visual?: VisualData;
}

export interface PinnedItem {
  id: string;
  messageId: string;
  title: string;
  content: string;
  type: 'formula' | 'trick' | 'tldr' | 'note';
  subject: SubjectType;
  timestamp: number;
}

export interface StudyStats {
  conceptsExplored: number;
  formulasPinned: number;
  focusMinutes: number;
}
