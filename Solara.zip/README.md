# FocusJEE - AuDHD Study Companion & Multi-Model AI Engine

A high-performance, resilient, distraction-free study platform engineered specifically for Indian competitive exams (JEE Mains and Class 11/12 Boards) with ADHD-optimized pedagogical guardrails, multi-model AI fallbacks, continuous server-side state persistence, secure password authentication, and advanced LaTeX mathematical rendering.

---

## 🏗️ System Architecture & Tech Stack

FocusJEE is built as a modern full-stack web application combining a lightning-fast React Single Page Application (SPA) with a robust Node.js/Express backend (`server.ts`) that acts as an intelligent API proxy and resilient orchestration layer.

- **Frontend Framework**: React 19, TypeScript, Vite, Tailwind CSS (via `@tailwindcss/vite`).
- **Icons & Styling**: `lucide-react`, Framer Motion (`motion`), Canvas Confetti (`canvas-confetti`).
- **Mathematical & Markdown Rendering**: `katex` (LaTeX math inline `$`/block `$$`), `marked` (Markdown processing).
- **Backend Server**: Node.js, Express (mounted with Vite middleware in development, compiled to production runtime).
- **AI SDKs**: `@google/genai` (Google Gemini SDK), `groq-sdk` (Groq API), OpenRouter REST API, and BazaarLink (`vm/my-router`) integration.
- **Data Persistence**: JSON-file-backed local storage (`/data/continuous-study-state.json`) with in-memory fallback.
- **Authentication**: Server-verified Master Password Access Gate with token persistence.

---

## 🧠 Core Architectural Components

### 1. Resilient Multi-Model AI Cascade & Gateway
To guarantee 100% uptime during intensive study sessions, the backend implements an advanced multi-provider, multi-tier fallback cascade. If a primary model or provider experiences high demand, rate limits (`429`), or service interruptions (`503`), the system transparently cascades through backup models in real time without interrupting the user.

- **Google GenAI Cascade**: Dynamically resolves and waterfalls across rolling aliases and stable checkpoints:
  - `gemini-flash-lite-latest` / `gemini-3.5-flash-lite`
  - `gemini-flash-latest` / `gemini-3.8-flash` / `gemini-3.6-flash`
  - `gemma-4-31b-it` / `gemma-4-26b-a4b-it`
- **Groq 3-Tier Independent Cascade**: Operates independently of Gemini with high-speed inference:
  1. Primary Model: `openai/gpt-oss-120b` (with high reasoning effort)
  2. Secondary Model: `qwen/qwen3.8-27b`
  3. Tertiary Dynamic Resolution: Queries Groq's active model catalog (`client.models.list()`) at runtime to select the latest available text model.
- **OpenRouter Free Tier Integration**: Fully supported fallback option for zero-cost open-source LLM access.
- **BazaarLink Integration (`vm/my-router`)**: Accessible directly in the UI model selection cycle (`bzl`), communicating with BazaarLink's OpenAI-compatible completions endpoint with enforced JEE and ADHD study guardrails.
- **Model Health Check API (`/api/check-models`)**: Periodically verifies upstream model availability against live API catalogues and flags deprecated or missing endpoints.

### 2. Continuous Study State Persistence
Study continuity is critical for students with ADHD. The application ensures zero data loss across browser refreshes and sessions:
- **Active Chat Retention**: Stores recent chat histories with automatic pruning rules (retaining active study turns).
- **Permanent Formula & Tricks Vault**: User-pinned formulas, derivations, and JEE shortcuts are permanently preserved.
- **Server Endpoints**:
  - `GET /api/study-state`: Loads persistent state from disk or memory fallback.
  - `POST /api/study-state`: Saves updated messages, pinned vault items, and active subjects.

### 3. ADHD & AuDHD Pedagogical Engine
The application enforces strict prompt engineering and guardrails (`PERMANENT_STUDY_SYSTEM_PROMPT`):
- **Tone & Persona**: Supportive, high-energy, motivational coaching tone with contextual emojis (`😭🫠🤨🥀`).
- **Subject Specialization**:
  - *Math*: Tailored strictly to Class 11/12 Boards / NCERT level (non-JEE depth).
  - *Physics & Chemistry*: Full JEE Mains and Boards level depth (with a natural inclination toward chemistry).
  - *Other Subjects*: Information Technology and English support.
- **Pedagogical Rules**:
  - No calculators allowed; includes calculation tips and step-by-step unit conversions.
  - Comprehensive derivation logic: explains *why* formulas work, *where* to use them, and *how* they were derived.
  - Strict chunking & pacing: breaks complex topics into digestible sequential parts.
- **Cognitive Guardrails (Side-Quest Lockout)**:
  - Hard refuses non-study diversions (e.g., app-building or coding questions during study sessions) in 1 sentence and redirects the student back to Physics/Chemistry/Math.

### 4. Interactive Study Tools
- **Focus Timer (`FocusTimer.tsx`)**: Built-in Pomodoro/focus countdown timer with audio alerts and session tracking.
- **Formula Vault Modal (`FormulaVaultModal.tsx`)**: Central repository for pinned formulas, shortcuts, and quick review cards.
- **Mental Math Cheat Sheet (`MentalMathCheatSheet.tsx`)**: Quick reference guide for approximation tricks, standard values, and arithmetic shortcuts.
- **System Prompt Modal (`SystemPromptModal.tsx`)**: Transparency viewer for the underlying AI system instructions and study guardrails.
- **Markdown & LaTeX Renderer (`MarkdownRenderer.tsx`)**: Custom renderer combining `marked` and `KaTeX` for pristine mathematical equations.

---

## 🔒 Security, Password Authentication & Environment Configuration

The application follows strict security and access control best practices:
- **Master Password Authentication Gate (`AuthGateModal.tsx`)**: Restricts access to the study portal using a server-side verified master password. Users enter their key once, which is verified against the backend and cached securely in local storage (`study_auth_token`).
- **Backend Verification API (`/api/auth/verify`)**: Validates submitted passwords against the configured `APP_PASSWORD` environment variable without exposing the plaintext secret to the client.
- **Server-Side API Proxying**: All API calls to Gemini, Groq, OpenRouter, and BazaarLink are routed through secure backend endpoints (`/api/*`), ensuring API keys are never exposed to the client bundle.
- **Credential Fallbacks & Redaction**: The codebase uses robust fallback environment variables and runtime key rotation without exposing actual live credentials in public documentation or repositories.
- **Environment Variables (`.env.example`)**:
  ```env
  PORT=3000
  NODE_ENV=development
  GEMINI_API_KEY=your_gemini_api_key_here
  GROQ_API_KEY=your_groq_api_key_here
  OPENROUTER_API_KEY=your_openrouter_api_key_here
  APP_PASSWORD=solara2026
  ```
