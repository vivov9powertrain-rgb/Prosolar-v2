import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import Groq from 'groq-sdk';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

dotenv.config();

// ============================================================================
// 🔒 MASTER ACCESS PASSWORD (EDIT THIS IN ONE PLACE TO CHANGE YOUR ACCESS KEY)
// ============================================================================
export const MASTER_ACCESS_PASSWORD = 'solara';

// Generates a deterministic server-verified session token based on the master password
export function generateAuthToken(): string {
  return crypto.createHmac('sha256', MASTER_ACCESS_PASSWORD).update('solara_authenticated_session_v1').digest('hex');
}

export function verifyAuthTokenOrPassword(tokenOrPassword: string | undefined): boolean {
  if (!tokenOrPassword) return false;
  const clean = tokenOrPassword.replace(/^Bearer\s+/i, '').trim();
  const validToken = generateAuthToken();
  return clean === validToken || clean === MASTER_ACCESS_PASSWORD;
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '30mb' }));

// Global server-side auth middleware for protected API routes
export const requireServerAuth: express.RequestHandler = (req, res, next) => {
  const authHeader = (req.headers.authorization || req.headers['x-app-token'] || req.headers['x-app-password']) as string | undefined;
  if (verifyAuthTokenOrPassword(authHeader)) {
    return next();
  }
  return res.status(401).json({
    error: 'Unauthorized: Invalid or missing access password',
    requiresAuth: true
  });
};

// Auth Verification Endpoint (Checks master password and issues persistent session token)
app.post('/api/auth/verify', (req, res) => {
  const { password } = req.body || {};
  if (password && password.trim() === MASTER_ACCESS_PASSWORD) {
    const token = generateAuthToken();
    return res.json({ success: true, token });
  }
  return res.status(401).json({ success: false, error: 'Incorrect access password' });
});

// Auth Status Check Endpoint (Checks if client's stored token is currently valid)
app.get('/api/auth/status', (req, res) => {
  const authHeader = (req.headers.authorization || req.headers['x-app-token'] || req.headers['x-app-password']) as string | undefined;
  const isValid = verifyAuthTokenOrPassword(authHeader);
  return res.json({ authenticated: isValid });
});

// Protect all /api routes except auth verification and health endpoints
app.use('/api', (req, res, next) => {
  const p = req.path || '';
  if (p.startsWith('/auth') || p === '/health') {
    return next();
  }
  return requireServerAuth(req, res, next);
});

// Ensure data directory exists for continuous study state preservation
const DATA_DIR = path.join(process.cwd(), 'data');
const STATE_FILE = path.join(DATA_DIR, 'continuous-study-state.json');

try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
} catch (err) {
  console.warn('Notice: Local data dir initialization:', err);
}

// Strict permanent study system prompt provided by the student
export const PERMANENT_STUDY_SYSTEM_PROMPT = <in our new project the systemprompt will be easily editable just like the other app sol `;

// ============================================================================
// 🔑 MASTER API KEYS CONFIGURATION (EDIT HERE TO CHANGE KEYS DIRECTLY)
// ============================================================================
export const MASTER_GEMINI_KEY = '';
export const MASTER_GROQ_KEY = '';
export const MASTER_OPENROUTER_KEY = '';
export const MASTER_BAZAARLINK_KEY = '';

// Initialize SDK instances directly using the master keys
const ai = new GoogleGenAI({
  apiKey: MASTER_GEMINI_KEY,
  httpOptions: {
    apiVersion: 'v1beta', // Forces the v3 SDK pipeline to stay on the beta layer, preserving rolling aliases & thinking budgets
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const groq = new Groq({
  apiKey: MASTER_GROQ_KEY,
});

const openrouterApiKey = MASTER_OPENROUTER_KEY;
const BAZAARLINK_API_KEY = MASTER_BAZAARLINK_KEY;

// 1. Gemini Runtime Helper (Uses MASTER_GEMINI_KEY directly)
async function geminiGenerateContentStream(params: any) {
  return await ai.models.generateContentStream(params);
}

async function geminiGenerateContent(params: any) {
  return await ai.models.generateContent(params);
}

async function geminiListModels() {
  return await ai.models.list();
}

// 2. Groq Runtime Helper (Uses MASTER_GROQ_KEY directly)
async function groqChatCreate(params: any) {
  return await groq.chat.completions.create(params);
}

async function groqModelsList() {
  return await groq.models.list();
}

// 3. OpenRouter Runtime Helper
async function openRouterFetchWithFallback(bodyObj: any, _apiKey?: string): Promise<Response> {
  return fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${MASTER_OPENROUTER_KEY}`,
      'HTTP-Referer': 'https://ais-dev.run.app',
      'X-Title': 'Solara JEE Study',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(bodyObj),
  });
}

// 4. BazaarLink Provider Fetch Helper
async function bazaarLinkFetch(bodyObj: any): Promise<Response> {
  return fetch('https://api.bazaarlink.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${MASTER_BAZAARLINK_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(bodyObj),
  });
}

// Groq Independent Multi-Model Fallback Cascade
// Primary Model: openai/gpt-oss-120b
// Secondary Model: qwen/qwen3.8-27b
// Tertiary Fallback: Dynamic model resolution via client.models.list() at runtime
const GROQ_PRIMARY_MODEL = 'openai/gpt-oss-120b';
const GROQ_SECONDARY_MODEL = 'qwen/qwen3.8-27b';
const GROQ_CASCADE_MODELS = [
  GROQ_PRIMARY_MODEL,
  GROQ_SECONDARY_MODEL,
];

// Dynamically fetch active model catalog from Groq API and select the latest available general text model ID
async function fetchDynamicGroqTextModel(groqClient: Groq, excludedModels: string[] = []): Promise<string> {
  try {
    const response = await groqModelsList();
    const modelList = response.data || [];

    const isExcluded = (id: string) => {
      const lower = id.toLowerCase();
      if (excludedModels.some(m => m.toLowerCase() === lower)) return true;
      if (lower.includes('whisper') || lower.includes('audio') || lower.includes('tts') || lower.includes('stt')) return true;
      if (lower.includes('guard') || lower.includes('safeguard') || lower.includes('moderation')) return true;
      if (lower.includes('embed') || lower.includes('bge') || lower.includes('embedding')) return true;
      if (lower.includes('distil') && lower.includes('whisper')) return true;
      return false;
    };

    // Filter for active general-purpose text/chat models
    const activeTextModels = modelList.filter((m: any) => {
      if (!m.id) return false;
      if (m.active === false) return false;
      return !isExcluded(m.id);
    });

    if (activeTextModels.length === 0) {
      // If none match after strict filtering, fallback to any available non-audio model
      const fallbackModel = modelList.find((m: any) => m.id && !m.id.toLowerCase().includes('whisper') && !m.id.toLowerCase().includes('guard'));
      return fallbackModel?.id || 'openai/gpt-oss-20b';
    }

    // High-performance candidate preference list matching current Groq catalog
    const preferredCandidates = [
      'openai/gpt-oss-20b',
      'qwen/qwen3.8-27b',
      'openai/gpt-oss-120b',
      'allam-2-7b',
      'openai/gpt-oss-20b',
    ];

    for (const cand of preferredCandidates) {
      const found = activeTextModels.find((m: any) => m.id.toLowerCase() === cand.toLowerCase());
      if (found) {
        return found.id;
      }
    }

    // Sort by latest created date or fallback to first available
    const sorted = [...activeTextModels].sort((a: any, b: any) => (b.created || 0) - (a.created || 0));
    return sorted[0].id;
  } catch (err: any) {
    console.warn('[Groq Dynamic Model Discovery Failed]:', err.message || err);
    return 'openai/gpt-oss-20b';
  }
}

// Models configuration: Resilient multi-model cascade ensuring continuous uptime and future-proof operation
// Google rolling aliases automatically resolve to the newest versions (e.g. Gemini 3.x, 4.x, 5.x) without code changes:
// Models configuration: Resilient multi-model cascade ensuring continuous uptime and future-proof operation
const FLASH_LITE_LATEST = 'gemini-flash-lite-latest';
const FLASH_LATEST_ALIAS = 'gemini-flash-latest';

// Stable anchor checkpoints & open model fallbacks
const HYDROGEN_4_MODEL = 'gemini-4-hydrogen';
const FLASH_38_MODEL = 'gemini-3.8-flash';
const FLASH_36_MODEL = 'gemini-3.6-flash';
const FLASH_LITE_35 = 'gemini-3.5-flash-lite';
const FLASH_LITE_31 = 'gemini-3.1-flash-lite';
const GEMMA_MODEL = 'gemma-4-31b-it';
const GEMMA_ALT = 'gemma-4-26b-a4b-it';

const XHIGH_THINKING_MODELS = [
  'gemini-4-hydrogen',
];

type GeminiCascadeKey = 'auto' | 'flash-lite' | 'flash' | 'gemma' | 'thinkHarder';
type ThinkingTierKey = 'xhigh' | 'high';

interface GeminiCascadeConfig {
  cascades: Record<GeminiCascadeKey, string[]>;
  thinkingLevels: Record<ThinkingTierKey, string[]>;
  groqModels: string[];
  updatedAt?: number;
}

const DEFAULT_GEMINI_CASCADES: Record<GeminiCascadeKey, string[]> = {
  'auto': [
    FLASH_LITE_LATEST,
    FLASH_LITE_35,
    FLASH_LITE_31,
    FLASH_LATEST_ALIAS,
    HYDROGEN_4_MODEL,
    FLASH_38_MODEL,
    FLASH_36_MODEL,
    GEMMA_ALT,
    GEMMA_MODEL,
  ],
  'flash-lite': [
    FLASH_LITE_LATEST,
    FLASH_LITE_35,
    FLASH_LITE_31,
    FLASH_LATEST_ALIAS,
    HYDROGEN_4_MODEL,
    FLASH_38_MODEL,
    FLASH_36_MODEL,
    GEMMA_ALT,
    GEMMA_MODEL,
  ],
  'flash': [
    FLASH_LATEST_ALIAS,
    HYDROGEN_4_MODEL,
    FLASH_38_MODEL,
    FLASH_36_MODEL,
    FLASH_LITE_LATEST,
    FLASH_LITE_35,
    FLASH_LITE_31,
    GEMMA_ALT,
    GEMMA_MODEL,
  ],
  'gemma': [
    GEMMA_ALT,
    GEMMA_MODEL,
    FLASH_LITE_LATEST,
    FLASH_LITE_35,
    FLASH_LITE_31,
    FLASH_LATEST_ALIAS,
    HYDROGEN_4_MODEL,
    FLASH_38_MODEL,
    FLASH_36_MODEL,
  ],
  'thinkHarder': [
    HYDROGEN_4_MODEL,
    FLASH_38_MODEL,      // 'gemini-3.8-flash' - Deepest reasoning capacity & high thinking token budget
    FLASH_LATEST_ALIAS,  // 'gemini-flash-latest'
    FLASH_36_MODEL,      // 'gemini-3.6-flash'
    FLASH_LITE_LATEST,   // 'gemini-flash-lite-latest'
    FLASH_LITE_35,
    FLASH_LITE_31,
    GEMMA_ALT,
    GEMMA_MODEL,
  ],
};

const DEFAULT_THINKING_LEVELS: Record<ThinkingTierKey, string[]> = {
  'xhigh': [...XHIGH_THINKING_MODELS],
  'high': [
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-flash-latest',
    'gemini-flash-lite-latest',
  ],
};

const CASCADE_CONFIG_FILE = path.join(DATA_DIR, 'gemini-cascade-config.json');

function cloneDefaultGeminiConfig(): GeminiCascadeConfig {
  return {
    cascades: {
      'auto': [...DEFAULT_GEMINI_CASCADES['auto']],
      'flash-lite': [...DEFAULT_GEMINI_CASCADES['flash-lite']],
      'flash': [...DEFAULT_GEMINI_CASCADES['flash']],
      'gemma': [...DEFAULT_GEMINI_CASCADES['gemma']],
      'thinkHarder': [...DEFAULT_GEMINI_CASCADES['thinkHarder']],
    },
    thinkingLevels: {
      'xhigh': [...DEFAULT_THINKING_LEVELS['xhigh']],
      'high': [...DEFAULT_THINKING_LEVELS['high']],
    },
    groqModels: [...GROQ_CASCADE_MODELS],
    updatedAt: 0,
  };
}

function normalizeModelId(raw: string): string {
  const cleaned = raw.trim().replace(/^models\//i, '');
  if (/^gemini_/i.test(cleaned)) {
    return cleaned.replace(/_/g, '-');
  }
  return cleaned;
}

function sanitizeModelList(list: unknown, fallback: string[], excludeGemma = false): string[] {
  if (!Array.isArray(list)) return [...fallback];
  const seen = new Set<string>();
  const result: string[] = [];
  for (const item of list) {
    if (typeof item !== 'string') continue;
    const id = normalizeModelId(item);
    if (!id) continue;
    if (excludeGemma && id.toLowerCase().startsWith('gemma')) continue;
    if (!seen.has(id)) {
      seen.add(id);
      result.push(id);
    }
  }
  return result;
}

function sanitizeThinkingLevels(rawLevels: any, fallback: Record<ThinkingTierKey, string[]>): Record<ThinkingTierKey, string[]> {
  const xhigh = sanitizeModelList(rawLevels?.xhigh, fallback.xhigh, true);
  const xhighSet = new Set(xhigh);
  const rawHigh = sanitizeModelList(rawLevels?.high, fallback.high, true);
  const high = rawHigh.filter((m) => !xhighSet.has(m));
  return { xhigh, high };
}

function loadCascadeConfigFromDisk(): GeminiCascadeConfig {
  const defaults = cloneDefaultGeminiConfig();
  try {
    if (fs.existsSync(CASCADE_CONFIG_FILE)) {
      const raw = fs.readFileSync(CASCADE_CONFIG_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      const cascades: Record<GeminiCascadeKey, string[]> = {
        'auto': sanitizeModelList(parsed?.cascades?.['auto'], defaults.cascades['auto']),
        'flash-lite': sanitizeModelList(parsed?.cascades?.['flash-lite'], defaults.cascades['flash-lite']),
        'flash': sanitizeModelList(parsed?.cascades?.['flash'], defaults.cascades['flash']),
        'gemma': sanitizeModelList(parsed?.cascades?.['gemma'], defaults.cascades['gemma']),
        'thinkHarder': sanitizeModelList(parsed?.cascades?.['thinkHarder'], defaults.cascades['thinkHarder']),
      };
      const thinkingLevels = sanitizeThinkingLevels(parsed?.thinkingLevels, defaults.thinkingLevels);
      const groqModels = sanitizeModelList(parsed?.groqModels, defaults.groqModels, false);
      const updatedAt = typeof parsed?.updatedAt === 'number' && Number.isFinite(parsed.updatedAt) ? parsed.updatedAt : 0;
      return { cascades, thinkingLevels, groqModels, updatedAt };
    }
  } catch (err) {
    console.warn('Warning reading gemini cascade config from disk, using defaults:', err);
  }
  return defaults;
}

function saveCascadeConfigToDisk(config: GeminiCascadeConfig): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(CASCADE_CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
  } catch (fsErr) {
    console.warn('Warning writing gemini cascade config to disk (in-memory preserved):', fsErr);
  }
}

let geminiConfig: GeminiCascadeConfig = loadCascadeConfigFromDisk();

function buildSanitizedCascadeConfig(incoming: any, base: GeminiCascadeConfig, updatedAtOverride?: number): GeminiCascadeConfig {
  const incomingCascades = incoming?.cascades;
  const incomingLevels = incoming?.thinkingLevels;
  const nextCascades: Record<GeminiCascadeKey, string[]> = {
    'auto': incomingCascades && 'auto' in incomingCascades
      ? sanitizeModelList(incomingCascades['auto'], base.cascades['auto'])
      : [...base.cascades['auto']],
    'flash-lite': incomingCascades && 'flash-lite' in incomingCascades
      ? sanitizeModelList(incomingCascades['flash-lite'], base.cascades['flash-lite'])
      : [...base.cascades['flash-lite']],
    'flash': incomingCascades && 'flash' in incomingCascades
      ? sanitizeModelList(incomingCascades['flash'], base.cascades['flash'])
      : [...base.cascades['flash']],
    'gemma': incomingCascades && 'gemma' in incomingCascades
      ? sanitizeModelList(incomingCascades['gemma'], base.cascades['gemma'])
      : [...base.cascades['gemma']],
    'thinkHarder': incomingCascades && 'thinkHarder' in incomingCascades
      ? sanitizeModelList(incomingCascades['thinkHarder'], base.cascades['thinkHarder'])
      : [...base.cascades['thinkHarder']],
  };

  const nextThinkingLevels = incomingLevels
    ? sanitizeThinkingLevels(
        {
          xhigh: 'xhigh' in incomingLevels ? incomingLevels.xhigh : base.thinkingLevels.xhigh,
          high: 'high' in incomingLevels ? incomingLevels.high : base.thinkingLevels.high,
        },
        base.thinkingLevels
      )
    : {
        xhigh: [...base.thinkingLevels.xhigh],
        high: [...base.thinkingLevels.high],
      };

  const nextGroqModels = incoming && 'groqModels' in incoming
    ? sanitizeModelList(incoming.groqModels, base.groqModels, false)
    : [...base.groqModels];

  const updatedAt =
    typeof updatedAtOverride === 'number' && Number.isFinite(updatedAtOverride)
      ? updatedAtOverride
      : typeof incoming?.updatedAt === 'number' && Number.isFinite(incoming.updatedAt)
      ? incoming.updatedAt
      : base.updatedAt || 0;

  return {
    cascades: nextCascades,
    thinkingLevels: nextThinkingLevels,
    groqModels: nextGroqModels,
    updatedAt,
  };
}

function resolveEffectiveCascadeConfig(incomingConfig?: any): GeminiCascadeConfig {
  if (!incomingConfig || typeof incomingConfig !== 'object' || Array.isArray(incomingConfig)) {
    return geminiConfig;
  }
  const hasFields =
    (incomingConfig.cascades && typeof incomingConfig.cascades === 'object') ||
    (incomingConfig.thinkingLevels && typeof incomingConfig.thinkingLevels === 'object') ||
    Array.isArray(incomingConfig.groqModels);
  if (!hasFields) {
    return geminiConfig;
  }

  const sanitized = buildSanitizedCascadeConfig(incomingConfig, cloneDefaultGeminiConfig());
  const incomingUpdatedAt = sanitized.updatedAt || 0;
  const serverUpdatedAt = geminiConfig.updatedAt || 0;

  if (incomingUpdatedAt > serverUpdatedAt || (serverUpdatedAt === 0 && incomingUpdatedAt >= 0)) {
    geminiConfig = sanitized;
    saveCascadeConfigToDisk(geminiConfig);
  }
  return sanitized;
}

function isXHighThinkingModel(model: string, config: GeminiCascadeConfig = geminiConfig): boolean {
  if (!model || model.toLowerCase().startsWith('gemma')) return false;
  return config.thinkingLevels.xhigh.some(m => model === m);
}

function isHighThinkingModel(model: string, config: GeminiCascadeConfig = geminiConfig): boolean {
  if (!model || model.toLowerCase().startsWith('gemma')) return false;
  return config.thinkingLevels.high.some(m => model === m);
}

function getThinkingLevelForModel(model: string, config: GeminiCascadeConfig = geminiConfig): ThinkingLevel {
  return isXHighThinkingModel(model, config) ? (((ThinkingLevel as any).XHIGH ?? 'XHIGH') as ThinkingLevel) : ThinkingLevel.HIGH;
}

function isThinkingGeminiModel(model: string, config: GeminiCascadeConfig = geminiConfig): boolean {
  return isXHighThinkingModel(model, config) || isHighThinkingModel(model, config);
}

// Helper to determine model priority based on user preference, thinkHarder status, and comprehensive fallback
function getModelsSequence(preference: string, thinkHarder?: boolean, config: GeminiCascadeConfig = geminiConfig): string[] {
  let key: GeminiCascadeKey = 'auto';
  if (thinkHarder) {
    key = 'thinkHarder';
  } else if (preference === 'flash') {
    key = 'flash';
  } else if (preference === 'flash-lite') {
    key = 'flash-lite';
  } else if (preference === 'gemma') {
    key = 'gemma';
  }
  const configured = config.cascades[key];
  return configured && configured.length > 0 ? [...configured] : [...DEFAULT_GEMINI_CASCADES[key]];
}

// All hardcoded models configured in our cascade arrays
const ALL_CASCADE_MODELS = [
  FLASH_LITE_LATEST,
  FLASH_LATEST_ALIAS,
  HYDROGEN_4_MODEL,
  FLASH_38_MODEL,
  FLASH_36_MODEL,
  FLASH_LITE_31,
  FLASH_LITE_35,
  GEMMA_ALT,
  GEMMA_MODEL,
];

// Active session tracking for models disabled specifically for search or globally
const disabledModels = new Set<string>();

interface AttachmentPayload {
  id?: string;
  name?: string;
  mimeType: string;
  data: string; // base64
  dataUrl?: string;
  size?: number;
}

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  attachments?: AttachmentPayload[];
  timestamp?: number;
  subject?: string;
  milestoneTitle?: string;
  thought?: string;
}

// Helper to clean and validate base64 string
function cleanAndValidateBase64(data: string | undefined): { isValid: boolean; cleanBase64: string } {
  if (!data || typeof data !== 'string') {
    return { isValid: false, cleanBase64: '' };
  }
  let clean = data.trim();
  // Strip data URL scheme prefix if present (e.g. data:image/png;base64,...)
  if (clean.includes('base64,')) {
    clean = clean.split('base64,')[1] || '';
  }
  clean = clean.replace(/[\r\n\s]/g, '');
  if (!clean) {
    return { isValid: false, cleanBase64: '' };
  }
  // Base64 format check: must only contain base64 chars and have valid padding
  const isBase64Pattern = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})?$/.test(clean);
  if (!isBase64Pattern) {
    return { isValid: false, cleanBase64: '' };
  }
  try {
    const buf = Buffer.from(clean, 'base64');
    if (buf.length === 0) return { isValid: false, cleanBase64: '' };
    return { isValid: true, cleanBase64: clean };
  } catch (_) {
    return { isValid: false, cleanBase64: '' };
  }
}

// Format history for @google/genai SDK with full Multimodal (image/pdf) support & performance optimization
function formatContentsForGenAI(messages: ChatMessage[], historyLimit?: number) {
  const limit = typeof historyLimit === 'number' && historyLimit >= 1 && historyLimit <= 20 ? historyLimit : 16;
  // Keep the most recent conversation turns so model reasoning & chain-of-thought stay lightning-fast
  const recentMessages = messages.length > limit ? messages.slice(-limit) : messages;

  return recentMessages.map((m, idx) => {
    const parts: any[] = [];
    const isRecentTurn = idx >= recentMessages.length - 2;

    // Multimodal attachments (images, PDFs, documents) - only send heavy base64 on recent turns to avoid multi-megabyte payload lag
    if (isRecentTurn && m.attachments && Array.isArray(m.attachments)) {
      for (const att of m.attachments) {
        if (!att) continue;
        const { isValid, cleanBase64 } = cleanAndValidateBase64(att.data);
        const mime = (att.mimeType || '').toLowerCase();

        // If it's valid base64 and an image, PDF, audio, or video, pass as inlineData
        const isSupportedMultimodal =
          mime.startsWith('image/') ||
          mime === 'application/pdf' ||
          mime.startsWith('audio/') ||
          mime.startsWith('video/');

        if (isValid && isSupportedMultimodal) {
          parts.push({
            inlineData: {
              mimeType: att.mimeType || 'image/png',
              data: cleanBase64,
            },
          });
        } else if (isValid && (mime.startsWith('text/') || mime === 'application/json')) {
          // If it's a text-based file, decode and include as text part
          try {
            const decodedText = Buffer.from(cleanBase64, 'base64').toString('utf-8');
            parts.push({
              text: `[Attached File: ${att.name || 'document'}]\n${decodedText}`,
            });
          } catch (_) {
            parts.push({
              text: `[Attached File: ${att.name || 'file'} (${att.mimeType || 'unknown'})]`,
            });
          }
        } else {
          // Not valid base64 or unsupported binary type - pass safely as a descriptive text annotation
          // without triggering Gemini 400 INVALID_ARGUMENT (Base64 decoding failed)
          parts.push({
            text: `[Attachment: ${att.name || 'file'} (${att.mimeType || 'unknown'})]`,
          });
        }
      }
    }

    const textContent = m.text?.trim() || (parts.length > 0 ? 'Please analyze this problem/diagram from my uploaded document/image in detail according to my JEE study mode.' : '');
    parts.push({ text: textContent });

    return {
      role: m.role === 'model' ? 'model' : 'user',
      parts,
    };
  });
}

// 10-Day Retention & Vault-Only Long-Term Persistence Rules
const PRUNE_RETENTION_MS = 6 * 24 * 60 * 60 * 1000; // 10 days in milliseconds

const MAX_SAVED_MESSAGES = 60;

interface StudyStatePayload {
  messages?: ChatMessage[];
  pinnedVault?: any[];
  activeSubject?: string;
  updatedAt?: number;
}

function pruneOldStudyMessages(state: StudyStatePayload): StudyStatePayload {
  const now = Date.now();
  const rawMessages = state.messages || [];

  // Prune any general chat older than 35 days to keep server storage lean & fast
  const recentByTime = rawMessages.filter((msg) => {
    if (!msg.timestamp) return true;
    return now - msg.timestamp <= PRUNE_RETENTION_MS;
  });

  const capped = recentByTime.slice(-MAX_SAVED_MESSAGES);
  const prunedMessages = capped.map((msg, idx) => {
    const keepMedia = idx >= capped.length - 10;
    if (keepMedia || !msg.attachments?.length) return msg;
    return {
      ...msg,
      attachments: msg.attachments.map((att) => ({
        ...att,
         data: '',
         dataUrl: undefined,
      })),
    };
  });
    

  return {
    messages: prunedMessages,
    pinnedVault: state.pinnedVault || [], // Formula & Tricks Vault is permanently preserved
    activeSubject: state.activeSubject || 'All',
    updatedAt: now,
  };
}

// In-memory fallback in case filesystem is restricted or read-only in deployment
let memoryStudyState: any = null;

// Study State Endpoints (Continuous 35-day active retention + Permanent Vault storage)
app.get('/api/study-state', (req, res) => {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const data = fs.readFileSync(STATE_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      const cleaned = pruneOldStudyMessages(parsed);
      memoryStudyState = cleaned;
      return res.json(cleaned);
    }
    if (memoryStudyState) {
      return res.json(memoryStudyState);
    }
    return res.json({ messages: [], pinnedVault: [], activeSubject: 'All' });
  } catch (err: any) {
    console.warn('Warning reading study state from disk, using memory fallback:', err);
    return res.json(memoryStudyState || { messages: [], pinnedVault: [], activeSubject: 'All' });
  }
});

app.post('/api/study-state', (req, res) => {
  try {
    const { messages, pinnedVault, activeSubject } = req.body;
    const cleaned = pruneOldStudyMessages({ messages, pinnedVault, activeSubject });
    memoryStudyState = cleaned;

    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(STATE_FILE, JSON.stringify(cleaned), 'utf-8');
    } catch (fsErr) {
      console.warn('Warning writing study state to disk (in-memory preserved):', fsErr);
    }

    return res.json({ success: true, count: cleaned.messages?.length || 0 });
  } catch (err: any) {
    console.error('Error processing study state:', err);
    return res.status(500).json({ error: 'Failed to save study state' });
  }
});

// App Info and Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: !!MASTER_GEMINI_KEY,
    hasGroqKey: !!MASTER_GROQ_KEY,
    hasOpenRouterKey: !!MASTER_OPENROUTER_KEY,
    hasBazaarLinkKey: !!MASTER_BAZAARLINK_KEY,
    groqModels: geminiConfig.groqModels.length > 0 ? geminiConfig.groqModels : GROQ_CASCADE_MODELS,
    models: {
      flashLatest: FLASH_LATEST_ALIAS,
      hydrogen: HYDROGEN_4_MODEL,
      flashLiteLatest: FLASH_LITE_LATEST,
      flash: FLASH_38_MODEL,
      flashLite: FLASH_LITE_31,
      gemma: GEMMA_MODEL,
      defaultMode: 'auto',
    },
    futureProof: true,
    systemPromptEnforced: true,
  });
});

// Format conversation history for Groq OpenAI-compatible Chat Completions
function formatMessagesForGroq(messages: ChatMessage[], historyLimit?: number) {
  const limit = typeof historyLimit === 'number' && historyLimit >= 1 && historyLimit <= 20 ? historyLimit : 16;
  const recent = messages.length > limit ? messages.slice(-limit) : messages;
  const groqMessages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
    { role: 'system', content: PERMANENT_STUDY_SYSTEM_PROMPT },
  ];

  for (let i = 0; i < recent.length; i++) {
    const m = recent[i];
    const role: 'user' | 'assistant' = m.role === 'model' ? 'assistant' : 'user';
    const isRecent = i >= recent.length - 2;

    let contentText = m.text || '';
    if (isRecent && m.attachments && m.attachments.length > 0) {
      const attInfo = m.attachments
        .map((a) => `[Attachment: ${a.name || 'file'} (${a.mimeType})]`)
        .join('\n');
      contentText = `${contentText}\n\n${attInfo}`;
    }

    groqMessages.push({
      role,
      content: contentText || ' ',
    });
  }

  return groqMessages;
}

function createAbortChecker(res: express.Response): () => boolean {
  let aborted = false;
  res.on('close', () => {
    if (!res.writableEnded) {
      aborted = true;
    }
  });
  return () => aborted || res.destroyed;
}

function safeWriteSSE(res: express.Response, isAborted: () => boolean, payload: unknown): void {
  if (!isAborted() && !res.writableEnded) {
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
  }
}

// Independent Groq Streaming Handler with Sequential Configured Cascade + Dynamic Fallback
async function handleGroqStream(
  messages: ChatMessage[],
  res: express.Response,
  thinkHarder?: boolean,
  historyLimit?: number,
  abortChecker?: () => boolean,
  groqModelsOverride?: string[]
) {
  const isAborted = abortChecker || createAbortChecker(res);
  const groqMessages = formatMessagesForGroq(messages, historyLimit);
  const configuredGroqModels = Array.isArray(groqModelsOverride) ? groqModelsOverride : geminiConfig.groqModels;

  // Stages 1..N: Execute configured Groq Primary/Secondary models in priority order
  for (let idx = 0; idx < configuredGroqModels.length; idx++) {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    const targetModel = configuredGroqModels[idx];
    const nextModel = configuredGroqModels[idx + 1];
    try {
      safeWriteSSE(res, isAborted, { type: 'model_init', model: `Groq · ${targetModel}` });

      const extraConfig: any = {};
      if (thinkHarder) {
        extraConfig.reasoning_effort = "high";
        extraConfig.include_reasoning = true;
        if (idx === 0) {
          safeWriteSSE(res, isAborted, { type: 'thinking' });
        }
      }

      const stream = await groqChatCreate({
        model: targetModel,
        messages: groqMessages,
        stream: true,
        max_completion_tokens: 12288,
        ...extraConfig,
      } as any);

      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }

      let isTruncated = false;
      for await (const chunk of stream as any) {
        if (isAborted()) {
          if (!res.writableEnded) res.end();
          return;
        }
        const reasoning = chunk.choices[0]?.delta?.reasoning || (chunk.choices[0]?.delta as any)?.reasoning_content || '';
        if (reasoning) {
          safeWriteSSE(res, isAborted, { type: 'thought', text: reasoning });
        }
        const text = chunk.choices[0]?.delta?.content || '';
        if (text) {
          safeWriteSSE(res, isAborted, { type: 'chunk', text });
        }
        if (chunk.choices[0]?.finish_reason === 'length') {
          isTruncated = true;
        }
      }

      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }

      if (isTruncated) {
        safeWriteSSE(res, isAborted, { type: 'chunk', text: "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]" });
      }

      safeWriteSSE(res, isAborted, { type: 'done', modelUsed: `Groq (${targetModel})` });
      if (!res.writableEnded) res.end();
      return;
    } catch (errModel: any) {
      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }
      if (nextModel) {
        console.warn(`[Groq Model Failed] ${targetModel}: ${errModel.message || errModel}. Cascading to ${nextModel}...`);
        safeWriteSSE(res, isAborted, {
          type: 'fallback_notice',
          failedModel: `Groq · ${targetModel}`,
          nextModel: `Groq · ${nextModel}`,
          reason: `${targetModel} unavailable; switching to ${nextModel}`,
        });
      } else {
        console.warn(`[Groq Cascade Exhausted] ${targetModel}: ${errModel.message || errModel}. Initiating dynamic Groq model resolution...`);
        safeWriteSSE(res, isAborted, {
          type: 'fallback_notice',
          failedModel: `Groq · ${targetModel}`,
          nextModel: 'Groq · Dynamic Model Resolution',
          reason: 'Configured Groq models unavailable; querying Groq API for active available text model...',
        });
      }
    }
  }

  if (isAborted()) {
    if (!res.writableEnded) res.end();
    return;
  }

  // Final Stage: Dynamic Fallback via client.models.list()
  try {
    const dynamicModelId = await fetchDynamicGroqTextModel(groq, configuredGroqModels);
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }
    console.log(`[Groq Dynamic Resolution] Selected active fallback model: ${dynamicModelId}`);

    if (configuredGroqModels.length > 0) {
      safeWriteSSE(res, isAborted, {
        type: 'fallback_notice',
        failedModel: `Groq · ${configuredGroqModels[configuredGroqModels.length - 1]}`,
        nextModel: `Groq · ${dynamicModelId}`,
        reason: `Dynamically resolved active Groq model: ${dynamicModelId}`,
      });
    }
    safeWriteSSE(res, isAborted, { type: 'model_init', model: `Groq · ${dynamicModelId}` });

    const extraConfig: any = {};
    if (thinkHarder) {
      extraConfig.reasoning_effort = "high";
      extraConfig.include_reasoning = true;
      if (configuredGroqModels.length === 0) {
        safeWriteSSE(res, isAborted, { type: 'thinking' });
      }
    }

    const stream = await groqChatCreate({
      model: dynamicModelId,
      messages: groqMessages,
      stream: true,
      max_completion_tokens: 12288,
      ...extraConfig,
    } as any);

    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    let isTruncated = false;
    for await (const chunk of stream as any) {
      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }
      const reasoning = chunk.choices[0]?.delta?.reasoning || (chunk.choices[0]?.delta as any)?.reasoning_content || '';
      if (reasoning) {
        safeWriteSSE(res, isAborted, { type: 'thought', text: reasoning });
      }
      const text = chunk.choices[0]?.delta?.content || '';
      if (text) {
        safeWriteSSE(res, isAborted, { type: 'chunk', text });
      }
      if (chunk.choices[0]?.finish_reason === 'length') {
        isTruncated = true;
      }
    }

    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    if (isTruncated) {
      safeWriteSSE(res, isAborted, { type: 'chunk', text: "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]" });
    }

    safeWriteSSE(res, isAborted, { type: 'done', modelUsed: `Groq (${dynamicModelId})` });
    if (!res.writableEnded) res.end();
  } catch (errTertiary: any) {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }
    console.error(`[Groq Dynamic Fallback Failed]:`, errTertiary.message || errTertiary);
    safeWriteSSE(res, isAborted, {
      type: 'error',
      error: 'All Groq models (including dynamic tertiary fallback) are currently busy or unavailable. Please retry in a few moments.',
    });
    if (!res.writableEnded) res.end();
  }
}

// Independent Groq Non-Streaming Handler with Sequential Configured Cascade + Dynamic Fallback
async function handleGroqChat(
  messages: ChatMessage[],
  res: express.Response,
  thinkHarder?: boolean,
  historyLimit?: number,
  groqModelsOverride?: string[]
) {
  const groqMessages = formatMessagesForGroq(messages, historyLimit);
  const configuredGroqModels = Array.isArray(groqModelsOverride) ? groqModelsOverride : geminiConfig.groqModels;

  for (let idx = 0; idx < configuredGroqModels.length; idx++) {
    const targetModel = configuredGroqModels[idx];
    try {
      const extraConfig: any = {};
      if (thinkHarder) {
        extraConfig.reasoning_effort = "high";
        extraConfig.include_reasoning = true;
      }

      const response = await groqChatCreate({
        model: targetModel,
        messages: groqMessages,
        max_completion_tokens: 12288,
        ...extraConfig,
      } as any);

      const choice = response.choices[0];
      let content = choice?.message?.content || '';
      if (choice?.finish_reason === 'length') {
        content += "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]";
      }

      return res.json({
        text: content,
        reasoning: (choice?.message as any)?.reasoning || (choice?.message as any)?.reasoning_content || '',
        modelUsed: `Groq (${targetModel})`,
        fallbackOccurred: idx > 0,
      });
    } catch (errModel: any) {
      const nextTarget = configuredGroqModels[idx + 1] || 'dynamic fallback model';
      console.warn(`[Groq Chat Failed] ${targetModel}: ${errModel.message || errModel}. Cascading to ${nextTarget}...`);
    }
  }

  // Final Stage: Dynamic Fallback via client.models.list()
  try {
    const dynamicModelId = await fetchDynamicGroqTextModel(groq, configuredGroqModels);
    console.log(`[Groq Chat Dynamic Resolution] Executing with active fallback model: ${dynamicModelId}`);

    const extraConfig: any = {};
    if (thinkHarder) {
      extraConfig.reasoning_effort = "high";
      extraConfig.include_reasoning = true;
    }

    const response = await groqChatCreate({
      model: dynamicModelId,
      messages: groqMessages,
      max_completion_tokens: 12288,
      ...extraConfig,
    } as any);

    const choice = response.choices[0];
    let content = choice?.message?.content || '';
    if (choice?.finish_reason === 'length') {
      content += "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]";
    }

    return res.json({
      text: content,
      reasoning: (choice?.message as any)?.reasoning || (choice?.message as any)?.reasoning_content || '',
      modelUsed: `Groq (${dynamicModelId})`,
      fallbackOccurred: true,
    });
  } catch (errTertiary: any) {
    console.error(`[Groq Chat All Fallbacks Failed]:`, errTertiary.message || errTertiary);
    return res.status(500).json({
      error: 'Groq model request failed across all cascade targets including dynamic fallback.',
    });
  }
}

// Dedicated Groq SSE Stream endpoint
app.post('/api/groq/stream', async (req, res) => {
  const { messages, thinkHarder, historyLimit, cascadeConfig } = req.body as {
    messages: ChatMessage[];
    thinkHarder?: boolean;
    historyLimit?: number;
    cascadeConfig?: any;
  };
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const effectiveConfig = resolveEffectiveCascadeConfig(cascadeConfig);
  await handleGroqStream(messages, res, thinkHarder, historyLimit, undefined, effectiveConfig.groqModels);
});

// Dedicated Groq non-streaming fallback endpoint
app.post('/api/groq/chat', async (req, res) => {
  const { messages, thinkHarder, historyLimit, cascadeConfig } = req.body as {
    messages: ChatMessage[];
    thinkHarder?: boolean;
    historyLimit?: number;
    cascadeConfig?: any;
  };
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  const effectiveConfig = resolveEffectiveCascadeConfig(cascadeConfig);
  await handleGroqChat(messages, res, thinkHarder, historyLimit, effectiveConfig.groqModels);
});

// Independent OpenRouter Streaming Handler
async function handleOpenRouterStream(
  messages: ChatMessage[],
  apiKey: string,
  res: express.Response,
  historyLimit?: number,
  thinkHarder?: boolean,
  abortChecker?: () => boolean
) {
  const isAborted = abortChecker || createAbortChecker(res);
  const groqMessages = formatMessagesForGroq(messages, historyLimit);
  try {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    safeWriteSSE(res, isAborted, { type: 'model_init', model: 'OpenRouter · free' });

    const bodyObj: any = {
      model: 'openrouter/free',
      messages: groqMessages,
      stream: true,
      max_tokens: 12288,
    };

    if (thinkHarder) {
      bodyObj.reasoning = { effort: 'high' };
      bodyObj.include_reasoning = true;
      safeWriteSSE(res, isAborted, { type: 'thinking' });
    }

    const response = await openRouterFetchWithFallback(bodyObj, apiKey);

    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenRouter API error (${response.status}): ${errText}`);
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error('No response reader from OpenRouter');

    const decoder = new TextDecoder();
    let buffer = '';
    let isTruncated = false;

    while (true) {
      if (isAborted()) {
        reader.cancel().catch(() => {});
        if (!res.writableEnded) res.end();
        return;
      }
      const { done, value } = await reader.read();
      if (isAborted()) {
        reader.cancel().catch(() => {});
        if (!res.writableEnded) res.end();
        return;
      }
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (isAborted()) {
          reader.cancel().catch(() => {});
          if (!res.writableEnded) res.end();
          return;
        }
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(':')) continue;
        if (trimmed === 'data: [DONE]') continue;
        if (trimmed.startsWith('data: ')) {
          try {
            const json = JSON.parse(trimmed.slice(6));
            const choice = json.choices?.[0];

            const reasoning = choice?.delta?.reasoning || choice?.delta?.reasoning_content || '';
            if (reasoning) {
              safeWriteSSE(res, isAborted, { type: 'thought', text: reasoning });
            }

            const content = choice?.delta?.content || '';
            if (content) {
              safeWriteSSE(res, isAborted, { type: 'chunk', text: content });
            }

            if (choice?.finish_reason === 'length') {
              isTruncated = true;
            }
          } catch (e) {}
        }
      }
    }

    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    if (isTruncated) {
      safeWriteSSE(res, isAborted, { type: 'chunk', text: "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]" });
    }

    safeWriteSSE(res, isAborted, { type: 'done', modelUsed: 'OpenRouter (free)' });
    if (!res.writableEnded) res.end();
  } catch (err: any) {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }
    console.error('[OpenRouter Stream Error]:', err);
    safeWriteSSE(res, isAborted, { type: 'error', error: err.message || 'OpenRouter request failed' });
    if (!res.writableEnded) res.end();
  }
}

// Independent OpenRouter Non-Streaming Handler
async function handleOpenRouterChat(messages: ChatMessage[], apiKey: string, res: express.Response, historyLimit?: number, thinkHarder?: boolean) {
  const groqMessages = formatMessagesForGroq(messages, historyLimit);
  try {
    const bodyObj: any = {
      model: 'openrouter/free',
      messages: groqMessages,
      max_tokens: 12288,
    };

    if (thinkHarder) {
      bodyObj.reasoning = { effort: 'high' };
      bodyObj.include_reasoning = true;
    }

    const response = await openRouterFetchWithFallback(bodyObj, apiKey);

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenRouter API error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    const choice = data.choices?.[0];
    let text = choice?.message?.content || '';
    const reasoning = choice?.message?.reasoning || choice?.message?.reasoning_content || '';

    if (choice?.finish_reason === 'length') {
      text += "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]";
    }

    return res.json({ text, reasoning, modelUsed: 'OpenRouter (free)' });
  } catch (err: any) {
    console.error('[OpenRouter Chat Error]:', err);
    return res.status(500).json({ error: err.message || 'OpenRouter chat failed' });
  }
}

app.post('/api/openrouter/stream', async (req, res) => {
  const { messages, thinkHarder, historyLimit } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  await handleOpenRouterStream(messages, openrouterApiKey, res, historyLimit, thinkHarder);
});

app.post('/api/openrouter/chat', async (req, res) => {
  const { messages, thinkHarder, historyLimit } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  await handleOpenRouterChat(messages, openrouterApiKey, res, historyLimit, thinkHarder);
});

// Independent BazaarLink Streaming Handler
async function handleBazaarLinkStream(
  messages: ChatMessage[],
  res: express.Response,
  historyLimit?: number,
  thinkHarder?: boolean,
  abortChecker?: () => boolean
) {
  const isAborted = abortChecker || createAbortChecker(res);
  const bazaarMessages = formatMessagesForGroq(messages, historyLimit);
  try {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    safeWriteSSE(res, isAborted, { type: 'model_init', model: 'BazaarLink · vm/my-router' });

    const bodyObj: any = {
      model: 'vm/my-router',
      messages: bazaarMessages,
      stream: true,
      max_tokens: 12288,
    };

    if (thinkHarder) {
      bodyObj.reasoning = { effort: 'high' };
      bodyObj.include_reasoning = true;
      safeWriteSSE(res, isAborted, { type: 'thinking' });
    }

    const response = await bazaarLinkFetch(bodyObj);

    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`BazaarLink API error (${response.status}): ${errText}`);
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error('No response reader from BazaarLink');

    const decoder = new TextDecoder();
    let buffer = '';
    let isTruncated = false;

    while (true) {
      if (isAborted()) {
        reader.cancel().catch(() => {});
        if (!res.writableEnded) res.end();
        return;
      }
      const { done, value } = await reader.read();
      if (isAborted()) {
        reader.cancel().catch(() => {});
        if (!res.writableEnded) res.end();
        return;
      }
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (isAborted()) {
          reader.cancel().catch(() => {});
          if (!res.writableEnded) res.end();
          return;
        }
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(':')) continue;
        if (trimmed === 'data: [DONE]') continue;
        if (trimmed.startsWith('data: ')) {
          try {
            const json = JSON.parse(trimmed.slice(6));
            const choice = json.choices?.[0];

            const reasoning = choice?.delta?.reasoning || (choice?.delta as any)?.reasoning_content || '';
            if (reasoning) {
              safeWriteSSE(res, isAborted, { type: 'thought', text: reasoning });
            }

            const content = choice?.delta?.content || '';
            if (content) {
              safeWriteSSE(res, isAborted, { type: 'chunk', text: content });
            }

            if (choice?.finish_reason === 'length') {
              isTruncated = true;
            }
          } catch (e) {}
        }
      }
    }

    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    if (isTruncated) {
      safeWriteSSE(res, isAborted, { type: 'chunk', text: "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]" });
    }

    safeWriteSSE(res, isAborted, { type: 'done', modelUsed: 'BazaarLink (vm/my-router)' });
    if (!res.writableEnded) res.end();
  } catch (err: any) {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }
    console.error('[BazaarLink Stream Error]:', err);
    safeWriteSSE(res, isAborted, { type: 'error', error: err.message || 'BazaarLink request failed' });
    if (!res.writableEnded) res.end();
  }
}

// Independent BazaarLink Non-Streaming Handler
async function handleBazaarLinkChat(messages: ChatMessage[], res: express.Response, historyLimit?: number, thinkHarder?: boolean) {
  const bazaarMessages = formatMessagesForGroq(messages, historyLimit);
  try {
    const bodyObj: any = {
      model: 'vm/my-router',
      messages: bazaarMessages,
      max_tokens: 12288,
    };

    if (thinkHarder) {
      bodyObj.reasoning = { effort: 'high' };
      bodyObj.include_reasoning = true;
    }

    const response = await bazaarLinkFetch(bodyObj);

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`BazaarLink API error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    const choice = data.choices?.[0];
    let text = choice?.message?.content || '';
    const reasoning = choice?.message?.reasoning || (choice?.message as any)?.reasoning_content || '';

    if (choice?.finish_reason === 'length') {
      text += "\n\n⚠️ [Answer reached maximum length. Reply 'continue' to finish the derivation.]";
    }

    return res.json({ text, reasoning, modelUsed: 'BazaarLink (vm/my-router)' });
  } catch (err: any) {
    console.error('[BazaarLink Chat Error]:', err);
    return res.status(500).json({ error: err.message || 'BazaarLink chat failed' });
  }
}

app.post('/api/bazaarlink/stream', async (req, res) => {
  const { messages, thinkHarder, historyLimit } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  await handleBazaarLinkStream(messages, res, historyLimit, thinkHarder);
});

app.post('/api/bazaarlink/chat', async (req, res) => {
  const { messages, thinkHarder, historyLimit } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  await handleBazaarLinkChat(messages, res, historyLimit, thinkHarder);
});

// Live Google GenAI Model Health & Deprecation Checker
async function handleCheckModels(req: express.Request, res: express.Response) {
  try {
    const incoming = req.method === 'POST' ? (req.body?.cascadeConfig || req.body) : undefined;
    const effectiveConfig = resolveEffectiveCascadeConfig(incoming);

    const list = await geminiListModels();
    const availableSet = new Set<string>();

    for await (const m of list) {
      if (m.name) {
        availableSet.add(m.name.replace(/^models\//, ''));
      }
    }

    const active: string[] = [];
    const deprecated_or_missing: string[] = [];

    const configuredGeminiModels = [
      ...new Set([
        ...Object.values(effectiveConfig.cascades).flat(),
        ...effectiveConfig.thinkingLevels.xhigh,
        ...effectiveConfig.thinkingLevels.high,
      ]),
    ];

    const modelsToCheck = configuredGeminiModels.length > 0 ? configuredGeminiModels : [...ALL_CASCADE_MODELS];

    // Evaluate each model configured in our cascade arrays
    for (const model of modelsToCheck) {
      const isAvailableUpstream = availableSet.has(model);
      const isSessionDisabled = disabledModels.has(model);

      if (isAvailableUpstream && !isSessionDisabled) {
        active.push(model);
      } else {
        deprecated_or_missing.push(model);
      }
    }

    return res.json({
      timestamp: Date.now(),
      status: deprecated_or_missing.length === 0 ? 'healthy' : 'warning',
      totalAvailableUpstream: availableSet.size,
      active,
      deprecated_or_missing,
      disabledInSession: Array.from(disabledModels),
    });
  } catch (err: any) {
    console.error('[Model Health Check Error]:', err);
    return res.status(500).json({
      error: 'Failed to verify models with Google GenAI API',
      details: err.message,
    });
  }
}

app.get('/api/check-models', handleCheckModels);
app.post('/api/check-models', handleCheckModels);

// Persistent Gemini & Groq Cascade Config Endpoints
app.get('/api/cascade-config', (req, res) => {
  return res.json({
    cascades: geminiConfig.cascades,
    thinkingLevels: geminiConfig.thinkingLevels,
    groqModels: geminiConfig.groqModels,
    updatedAt: geminiConfig.updatedAt || 0,
    defaults: {
      cascades: DEFAULT_GEMINI_CASCADES,
      thinkingLevels: DEFAULT_THINKING_LEVELS,
      groqModels: GROQ_CASCADE_MODELS,
    },
  });
});

app.put('/api/cascade-config', (req, res) => {
  try {
    const incomingUpdatedAt =
      typeof req.body?.updatedAt === 'number' && Number.isFinite(req.body.updatedAt) && req.body.updatedAt > 0
        ? req.body.updatedAt
        : Date.now();

    geminiConfig = buildSanitizedCascadeConfig(req.body || {}, geminiConfig, incomingUpdatedAt);

    saveCascadeConfigToDisk(geminiConfig);
    disabledModels.clear();

    return res.json({
      success: true,
      cascades: geminiConfig.cascades,
      thinkingLevels: geminiConfig.thinkingLevels,
      groqModels: geminiConfig.groqModels,
      updatedAt: geminiConfig.updatedAt || incomingUpdatedAt,
      defaults: {
        cascades: DEFAULT_GEMINI_CASCADES,
        thinkingLevels: DEFAULT_THINKING_LEVELS,
        groqModels: GROQ_CASCADE_MODELS,
      },
    });
  } catch (err: any) {
    console.error('[Cascade Config Save Error]:', err);
    return res.status(500).json({ error: 'Failed to update cascade configuration' });
  }
});

app.post('/api/cascade-config/reset', (req, res) => {
  const resetUpdatedAt = Date.now();
  geminiConfig = {
    ...cloneDefaultGeminiConfig(),
    updatedAt: resetUpdatedAt,
  };
  saveCascadeConfigToDisk(geminiConfig);
  disabledModels.clear();
  return res.json({
    success: true,
    cascades: geminiConfig.cascades,
    thinkingLevels: geminiConfig.thinkingLevels,
    groqModels: geminiConfig.groqModels,
    updatedAt: resetUpdatedAt,
    defaults: {
      cascades: DEFAULT_GEMINI_CASCADES,
      thinkingLevels: DEFAULT_THINKING_LEVELS,
      groqModels: GROQ_CASCADE_MODELS,
    },
  });
});

// Reset session-disabled models
app.post('/api/reset-disabled-models', (req, res) => {
  disabledModels.clear();
  return res.json({ success: true, message: 'Session disabled models cache reset.' });
});

function prepareGenAIRequest(targetModel: string, rawContents: any[]) {
  const isGemma = targetModel.toLowerCase().startsWith('gemma');
  const config: any = {};

  let contents = rawContents;

  if (isGemma) {
    config.temperature = 0.7;
    // Gemma models do not accept systemInstruction in config object
    contents = contents.map((c, idx) => {
      if (idx === 0 && c.role === 'user') {
        return {
          ...c,
          parts: [
            { text: `[Study Mode Instructions: ${PERMANENT_STUDY_SYSTEM_PROMPT}]\n\n` },
            ...c.parts,
          ],
        };
      }
      return c;
    });
  } else {
    config.systemInstruction = PERMANENT_STUDY_SYSTEM_PROMPT;
  }
  return { contents, config };
}

// Chat Stream endpoint (SSE) with Best-Available Auto Fallback
app.post('/api/chat/stream', async (req, res) => {
  const { messages, modelPreference, thinkHarder, historyLimit, cascadeConfig } = req.body as {
    messages: ChatMessage[];
    modelPreference?: string;
    thinkHarder?: boolean;
    historyLimit?: number;
    cascadeConfig?: any;
  };

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  // Set SSE Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const isAborted = createAbortChecker(res);
  const preference = modelPreference || 'auto';
  const effectiveConfig = resolveEffectiveCascadeConfig(cascadeConfig);

  // If client routed groq preference through /api/chat/stream, delegate cleanly
  if (preference === 'groq') {
    await handleGroqStream(messages, res, thinkHarder, historyLimit, isAborted, effectiveConfig.groqModels);
    return;
  }
  if (preference === 'openrouter') {
    await handleOpenRouterStream(messages, openrouterApiKey, res, historyLimit, thinkHarder, isAborted);
    return;
  }
  if (preference === 'bzl' || preference === 'bazaarlink') {
    await handleBazaarLinkStream(messages, res, historyLimit, thinkHarder, isAborted);
    return;
  }

  const rawContents = formatContentsForGenAI(messages, historyLimit);
  const rawModels = getModelsSequence(preference, thinkHarder, effectiveConfig);
  const activeModels = rawModels.filter((m) => !disabledModels.has(m));
  const modelsToTry = activeModels.length > 0 ? activeModels : rawModels;

  let success = false;
  let chosenModelName = '';

  for (let i = 0; i < modelsToTry.length; i++) {
    if (isAborted()) {
      if (!res.writableEnded) res.end();
      return;
    }

    const targetModel = modelsToTry[i];
    try {
      // Inform client which model is actively generating
      safeWriteSSE(res, isAborted, { type: 'model_init', model: targetModel });

      const isThinkingGemini = thinkHarder && isThinkingGeminiModel(targetModel, effectiveConfig);
      
      let attempts: any[] = [];
      if (isThinkingGemini) {
        const primaryLevel = getThinkingLevelForModel(targetModel, effectiveConfig);
        const supportsXHigh = isXHighThinkingModel(targetModel, effectiveConfig);
        attempts = supportsXHigh
          ? [
              { thinkingConfig: { thinkingLevel: primaryLevel, includeThoughts: true } },
              { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH, includeThoughts: true } },
              {},
            ]
          : [
              { thinkingConfig: { thinkingLevel: primaryLevel, includeThoughts: true } },
              {},
            ];
      } else {
        attempts = [{}];
      }

      let attemptIndex = 0;
      let streamResponse: any = null;
      let lastAttemptError: any = null;

      while (attemptIndex < attempts.length) {
        if (isAborted()) {
          if (!res.writableEnded) res.end();
          return;
        }
        const currentAttempt = attempts[attemptIndex];
        try {
          const { contents, config } = prepareGenAIRequest(targetModel, rawContents);
          
          if (isThinkingGemini) {
            if (currentAttempt.thinkingConfig) {
              config.thinkingConfig = currentAttempt.thinkingConfig;
            }
          }

          if (isThinkingGemini && attemptIndex === 0) {
            // Stream subtle thinking indicator before first token
            safeWriteSSE(res, isAborted, { type: 'thinking' });
          }

          streamResponse = await geminiGenerateContentStream({
            model: targetModel,
            contents,
            config,
          });

          if (isAborted()) {
            if (!res.writableEnded) res.end();
            return;
          }

          lastAttemptError = null;
          break; // Successfully opened the stream
        } catch (err: any) {
          if (isAborted()) {
            if (!res.writableEnded) res.end();
            return;
          }
          lastAttemptError = err;
          if (isThinkingGemini) {
            console.warn(`[Thinking Attempt ${attemptIndex} Failed] ${targetModel}:`, err.message || err);
          } else {
            console.warn(`[Model Request Failed] ${targetModel}:`, err.message || err);
          }

          const statusStr = String(err.status || '');
          const msgLower = (err.message || '').toLowerCase();

          const isUnavailable =
            err.status === 503 ||
            statusStr === '503' ||
            msgLower.includes('503') ||
            msgLower.includes('unavailable') ||
            msgLower.includes('high demand');

          const isQuota =
            err.status === 429 ||
            statusStr === '429' ||
            msgLower.includes('429') ||
            msgLower.includes('quota') ||
            msgLower.includes('resource_exhausted');

          const isNotFound =
            err.status === 404 ||
            statusStr === '404' ||
            msgLower.includes('404') ||
            msgLower.includes('not found') ||
            msgLower.includes('no longer available');

          const isServerErr =
            err.status === 500 ||
            statusStr === '500' ||
            msgLower.includes('500') ||
            msgLower.includes('internal');

          // If the model is 503 unavailable, 429 quota-exhausted, 404 deprecated, or 500 server-error:
          // Immediately cascade to the NEXT model in the cascade to preserve deep reasoning!
          if (isUnavailable || isQuota || isNotFound || isServerErr) {
            break;
          }

          // If it's a specific 400 parameter mismatch on thinking level, step down gracefully
          if (attemptIndex < attempts.length - 1 && isThinkingGemini) {
            const is400 = err.status === 400 || statusStr === '400' || msgLower.includes('400') || msgLower.includes('invalid');
            if (is400) {
              attemptIndex++;
              continue;
            }
          }

          // Otherwise break to cascade to next thinking model in the cascade
          break;
        }
      }

      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }

      if (lastAttemptError) {
        throw lastAttemptError;
      }

      chosenModelName = targetModel;

      for await (const chunk of streamResponse) {
        if (isAborted()) {
          if (!res.writableEnded) res.end();
          return;
        }
        const parts = chunk.candidates?.[0]?.content?.parts || [];
        if (parts.length > 0) {
          for (const part of parts) {
            const rawThought = (part as any).thought;
            const isThought = rawThought === true || typeof rawThought === 'string';
            const thoughtText = typeof rawThought === 'string' ? rawThought : (rawThought ? (part.text || '') : '');

            if (isThought && thoughtText) {
              safeWriteSSE(res, isAborted, { type: 'thought', text: thoughtText });
            } else if (!isThought && part.text) {
              safeWriteSSE(res, isAborted, { type: 'chunk', text: part.text });
            }
          }
        } else {
          const chunkText = chunk.text;
          if (chunkText) {
            safeWriteSSE(res, isAborted, { type: 'chunk', text: chunkText });
          }
        }
      }

      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }

      success = true;
      safeWriteSSE(res, isAborted, { type: 'done', modelUsed: chosenModelName });
      if (!res.writableEnded) res.end();
      break;
    } catch (err: any) {
      if (isAborted()) {
        if (!res.writableEnded) res.end();
        return;
      }

      console.log(`[Model Cascade] ${targetModel} busy or unavailable. Auto-cascading to next model...`);

      // Graceful Runtime Catch: If model returns 404 / deprecated, disable for session so future queries skip immediately
      const is404 =
        err.status === 404 ||
        err.message?.includes('404') ||
        err.message?.includes('NOT_FOUND') ||
        err.message?.includes('not found') ||
        err.message?.includes('no longer available');

      const is503 =
        err.status === 503 ||
        String(err.status) === '503' ||
        err.message?.includes('503') ||
        err.message?.includes('UNAVAILABLE') ||
        err.message?.includes('high demand');

      if (is404) {
        disabledModels.add(targetModel);
        console.log(`[Model Health] Auto-bypassing deprecated/404 model for session: ${targetModel}`);
      }

      let shortReason = 'Cascading to next available AI model';
      if (is503) {
        shortReason = '503 high demand: cascading to next thinking engine';
      } else if (err.status === 429 || err.message?.includes('429') || err.message?.includes('quota') || err.message?.includes('RESOURCE_EXHAUSTED')) {
        shortReason = '429 rate limit';
      } else if (err.message?.includes('thinking')) {
        shortReason = '400 thinking config';
      } else if (err.status === 400 || err.message?.includes('400')) {
        shortReason = '400 bad request';
      } else if (err.status === 500 || err.message?.includes('500') || err.message?.includes('internal')) {
        shortReason = '500 server error';
      } else if (err.message) {
        shortReason = `Error: ${err.message.substring(0, 40)}`;
      }

      // If we have another model in the list, inform client about fallback seamlessly
      if (i < modelsToTry.length - 1) {
        safeWriteSSE(res, isAborted, {
          type: 'fallback_notice',
          failedModel: targetModel,
          nextModel: modelsToTry[i + 1],
          reason: shortReason,
        });
      } else {
        // Ultimate Cross-Provider Fallback: All Gemini models exhausted -> Cascade to Groq
        console.warn('[Gemini Quota/Limit Exhausted] Seamlessly cascading to Groq fallback engine...');
        safeWriteSSE(res, isAborted, {
          type: 'fallback_notice',
          failedModel: targetModel,
          nextModel: `Groq · ${effectiveConfig.groqModels[0] || GROQ_PRIMARY_MODEL}`,
          reason: 'All Gemini endpoints busy; cascading to Groq engine',
        });
        await handleGroqStream(messages, res, thinkHarder, historyLimit, isAborted, effectiveConfig.groqModels);
        return;
      }
    }
  }
});

// Non-streaming fallback endpoint
app.post('/api/chat', async (req, res) => {
  const { messages, modelPreference, thinkHarder, historyLimit, cascadeConfig } = req.body as {
    messages: ChatMessage[];
    modelPreference?: string;
    thinkHarder?: boolean;
    historyLimit?: number;
    cascadeConfig?: any;
  };

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'Messages array is required.' });
  }

  const preference = modelPreference || 'auto';
  const effectiveConfig = resolveEffectiveCascadeConfig(cascadeConfig);

  if (preference === 'groq') {
    await handleGroqChat(messages, res, thinkHarder, historyLimit, effectiveConfig.groqModels);
    return;
  }
  if (preference === 'openrouter') {
    await handleOpenRouterChat(messages, openrouterApiKey, res, historyLimit, thinkHarder);
    return;
  }
  if (preference === 'bzl' || preference === 'bazaarlink') {
    await handleBazaarLinkChat(messages, res, historyLimit, thinkHarder);
    return;
  }

  const rawContents = formatContentsForGenAI(messages, historyLimit);
  const rawModels = getModelsSequence(preference, thinkHarder, effectiveConfig);
  const activeModels = rawModels.filter((m: string) => !disabledModels.has(m));
  const modelsToTry = activeModels.length > 0 ? activeModels : rawModels;

  for (let i = 0; i < modelsToTry.length; i++) {
    const targetModel = modelsToTry[i];
    try {
      const { contents, config } = prepareGenAIRequest(targetModel, rawContents);
      if (thinkHarder && isThinkingGeminiModel(targetModel, effectiveConfig)) {
        config.thinkingConfig = { thinkingLevel: getThinkingLevelForModel(targetModel, effectiveConfig), includeThoughts: true };
      }

      const response = await geminiGenerateContent({
        model: targetModel,
        contents,
        config,
      });

      let responseText = '';
      let responseReasoning = '';
      const parts = response.candidates?.[0]?.content?.parts || [];
      for (const part of parts) {
        const rawThought = (part as any).thought;
        const isThought = rawThought === true || typeof rawThought === 'string';
        if (isThought) {
          responseReasoning += typeof rawThought === 'string' ? rawThought : (part.text || '');
        } else if (part.text) {
          responseText += part.text;
        }
      }
      if (!responseText && response.text) {
        responseText = response.text;
      }

      return res.json({
        text: responseText,
        reasoning: responseReasoning || undefined,
        modelUsed: targetModel,
        fallbackOccurred: i > 0,
      });
    } catch (err: any) {
      console.log(`[Model Cascade] ${targetModel} fallback triggered.`);

      // Graceful Runtime Catch: If model returns 404 / deprecated, disable for session so future queries skip immediately
      const is404 =
        err.status === 404 ||
        err.message?.includes('404') ||
        err.message?.includes('NOT_FOUND') ||
        err.message?.includes('not found') ||
        err.message?.includes('no longer available');

      if (is404) {
        disabledModels.add(targetModel);
        console.log(`[Model Health] Auto-bypassing deprecated/404 model for session: ${targetModel}`);
      }

      if (i === modelsToTry.length - 1) {
        console.warn('[Gemini Quota/Limit Exhausted] Seamlessly cascading to Groq fallback engine (chat)...');
        await handleGroqChat(messages, res, thinkHarder, historyLimit, effectiveConfig.groqModels);
        return;
      }
    }
  }
});

// Bootstrapping Vite / Static serving
async function startServer() {
  const distPath = path.resolve(process.cwd(), 'dist');

  if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));
  }

  if (!isProd && !fs.existsSync(distPath)) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
  }

  app.get('*', (req, res) => {
    const indexPath = path.join(distPath, 'index.html');
    if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      res.status(404).send('App building, please refresh in 5 seconds.');
    }
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FocusJEE study server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
