import { topicWords, subjects, quotedPhrases } from "./search-ranking.ts";
import { queryText } from "./tavily.ts";
export const needsSubject =
  "What should I look up? Include the name, place or version in your question so I don’t search for the wrong thing. No search call was used.";
// Only intercept unmistakably context-dependent English fragments. Other languages still pass through.
export function missingSubject(text: string): boolean {
  const s = text
    .toLowerCase()
    .trim()
    .replace(/[?!.]+$/, "")
    .trim();
  return (
    !topicWords(s).size ||
    /^(?:(?:and )?(?:what|how) about (?:it|that|them|this|the other one)|(?:tell me|say) more(?: about (?:it|that|them))?|go on|(?:and )?(?:its |the )?(?:opening hours|price|release date|requirements)|(?:is|was) (?:it|that) (?:open|available|free|true)(?: now| today)?|(?:when|where) (?:is|was|did|does) (?:it|that)(?: (?:open|close|start|end))?)$/i.test(
      s,
    )
  );
}
/** Guard against an unrelated planner rewrite. Prefer the user's phrasing to a confident change of subject. */
export function focusedQuery(question: string, planned: string, prior: string = ""): string {
  const need = missingSubject(question);
  const anchor = need ? prior : question;
  if (!anchor || missingSubject(planned)) throw Error(needsSubject);
  const q = topicWords(anchor),
    p = topicWords(planned);
  const subject = subjects(q),
    required = quotedPhrases(question),
    folded = planned.normalize("NFKC").toLowerCase();
  const kept =
    required.every((t) => folded.includes(t)) &&
    [...topicWords(question)]
      .filter((t) => /^(?:\d{4}|v?\d+(?:\.\d+)+)$/.test(t))
      .every((t) => p.has(t));
  if (kept && (subject.length ? subject.some((t) => p.has(t)) : [...q].some((t) => p.has(t))))
    return queryText(planned);
  if (need) throw Error(needsSubject);
  return queryText(question);
}
