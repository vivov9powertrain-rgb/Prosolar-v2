// One ledger per conversation, separate from chat snapshots so an older tab cannot roll it back.
export type Budget = { limit: number; used: number };
export const DEFAULT_BUDGET: Budget = { limit: 10, used: 0 };
export const budgetKey = (id: string) => "sol:search-budget:" + id;
export function budgetFrom(raw: string | null): Budget {
  if (!raw) return { ...DEFAULT_BUDGET };
  const b = JSON.parse(raw);
  if (
    !Number.isInteger(b?.limit) ||
    b.limit < 10 ||
    b.limit > 50 ||
    !Number.isInteger(b.used) ||
    b.used < 0
  )
    throw Error(
      "This conversation’s search counter is unreadable. Start a new chat or turn web search off.",
    );
  return { limit: b.limit, used: b.used };
}
export function available(b: Budget) {
  if (b.used >= b.limit)
    throw Error(
      `Search limit reached (${b.used}/${b.limit}). Raise this chat’s limit or turn off web search.`,
    );
}
export const getBudget = (id: string) => budgetFrom(localStorage.getItem(budgetKey(id)));
async function transact(id: string, fn: (old: Budget) => Budget, signal?: AbortSignal) {
  if (!id) throw Error("Select a conversation first.");
  const name = budgetKey(id);
  const write = () => {
    signal?.throwIfAborted();
    const next = fn(getBudget(id));
    try {
      localStorage.setItem(name, JSON.stringify(next));
    } catch {
      throw Error(
        "Cannot save this chat’s search budget. Enable browser storage or turn off web search.",
      );
    }
    window.dispatchEvent(new Event("sol-budget"));
    return next;
  };
  return navigator.locks
    ? navigator.locks.request(name, { mode: "exclusive", signal }, write)
    : write();
}
export const reserveSearch = (id: string, signal: AbortSignal) =>
  transact(
    id,
    (b) => {
      available(b);
      return { ...b, used: b.used + 1 };
    },
    signal,
  );
export const changeLimit = (id: string, limit: number) =>
  transact(id, (b) => ({
    ...b,
    limit: Number.isFinite(limit) ? Math.max(10, Math.min(50, Math.round(limit))) : b.limit,
  }));
