import { siteRules } from "./source-policy.ts";
import { TAVILY_URL, readSmallJson, searchBody, hitsFrom, searchError } from "./tavily.ts";
const reply = (body: unknown, status = 200) =>
  Response.json(body, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "X-Sol-Search": "1",
      "X-Sol-Search-Policy": "2",
      "X-Content-Type-Options": "nosniff",
    },
  });
const fail = (msg: string, status: number) => reply({ error: { message: msg } }, status);
export async function searchRelay(req: Request, upstream: typeof fetch = fetch) {
  const site = req.headers.get("sec-fetch-site"),
    origin = req.headers.get("origin");
  if (
    site === "cross-site" ||
    (origin && site !== "same-origin" && origin !== new URL(req.url).origin)
  )
    return fail("Use this deployment’s search route.", 403);
  if (req.method !== "POST") return fail("POST required.", 405);
  if (!req.headers.get("content-type")?.startsWith("application/json"))
    return fail("JSON required.", 415);
  const auth = req.headers.get("authorization");
  if (!auth || !/^Bearer [\x21-\x7e]{1,8192}$/.test(auth))
    return fail("A Tavily key is required.", 401);
  let raw: unknown;
  try {
    raw = await readSmallJson(req, 8192);
  } catch (e) {
    return fail("Invalid search request.", e instanceof RangeError ? 413 : 400);
  }
  const b = raw as Record<string, unknown> | null;
  if (
    !b ||
    typeof b.query !== "string" ||
    !b.query.trim() ||
    Array.from(b.query).length > 400 ||
    !["basic", "advanced"].includes(String(b.search_depth)) ||
    typeof b.max_results !== "number" ||
    !Number.isInteger(b.max_results) ||
    b.max_results < 1 ||
    b.max_results > 5
  )
    return fail("Invalid search query, depth or result limit.", 400);
  let rules;
  try {
    rules = siteRules(b.include_domains, b.exclude_domains);
  } catch (e) {
    return fail(e instanceof Error ? e.message : "Invalid domain list.", 400);
  }
  const body = searchBody(
      b.query,
      b.search_depth === "advanced" ? "advanced" : "basic",
      b.max_results,
      rules,
    ),
    deadline = AbortSignal.timeout(20000);
  try {
    const r = await upstream(TAVILY_URL, {
      method: "POST",
      headers: {
        Authorization: auth,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      redirect: "error",
      credentials: "omit",
      cache: "no-store",
      signal: AbortSignal.any([req.signal, deadline]),
    });
    if (!r.ok) {
      await r.body?.cancel();
      const code = r.status >= 400 && r.status <= 599 ? r.status : 502;
      return fail(searchError(code), code);
    }
    return reply({
      results: hitsFrom(await readSmallJson(r, 512 * 1024), b.max_results, body.query, rules),
    });
  } catch {
    return fail("Tavily could not complete the search.", deadline.aborted ? 504 : 502);
  }
}
