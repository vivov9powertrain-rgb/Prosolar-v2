import { apiBase, canonicalOrEmpty, hasControlChars, providerAt } from "./endpoints.ts";
import { PROVIDERS } from "./types.ts";
export type SavedProviders = Record<string, string>;
export function namedProvider(entries: SavedProviders, raw: string, value: string): SavedProviders {
  const base = apiBase(raw),
    name = value.trim();
  if (providerAt(base)) throw Error("That URL already has a built-in provider.");
  if (!name || name.length > 64 || hasControlChars(name))
    throw Error("Use a provider name between 1 and 64 characters.");
  const equal = (label: string) => label.toLowerCase() === name.toLowerCase();
  if (
    PROVIDERS.some((p) => equal(p.label)) ||
    Object.entries(entries).some(([url, label]) => url !== base && equal(label))
  )
    throw Error("Choose a distinct name for this provider.");
  return { ...entries, [base]: name };
}
export function restoreProviders(raw: unknown): SavedProviders {
  let saved: SavedProviders = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw))
    for (const [url, name] of Object.entries(raw)) {
      if (typeof name === "string" && canonicalOrEmpty(url))
        try {
          saved = namedProvider(saved, url, name);
        } catch {
          /* ignore invalid legacy entries */
        }
    }
  return saved;
}
