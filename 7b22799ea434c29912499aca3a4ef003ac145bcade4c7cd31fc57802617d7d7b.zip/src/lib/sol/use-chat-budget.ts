import { useSyncExternalStore } from "react";
import { budgetFrom, budgetKey } from "./search-budget";
function subscribe(f: () => void) {
  window.addEventListener("storage", f);
  window.addEventListener("sol-budget", f);
  return () => {
    window.removeEventListener("storage", f);
    window.removeEventListener("sol-budget", f);
  };
}
export function useChatBudget(id: string) {
  const raw = useSyncExternalStore(
    subscribe,
    () => {
      try {
        return localStorage.getItem(budgetKey(id));
      } catch {
        return "!";
      }
    },
    () => null,
  );
  try {
    return budgetFrom(raw);
  } catch {
    return { limit: 10, used: 10 };
  }
}
