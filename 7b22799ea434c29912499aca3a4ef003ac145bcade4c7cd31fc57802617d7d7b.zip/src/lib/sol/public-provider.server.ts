// Server-only transport for BYOK provider traffic. TLS authenticates the original
// hostname; the socket connects to a checked numeric address (no second lookup).
import { lookup } from "node:dns/promises";
import { BlockList, isIP } from "node:net";
import { request as httpsRequest } from "node:https";
import { Readable } from "node:stream";
import { relayEligible } from "./endpoints.ts";

export class RelayFault extends Error {
  readonly httpStatus: number;
  constructor(message: string, httpStatus = 502) {
    super(message);
    this.httpStatus = httpStatus;
  }
}
const denied = new BlockList();
for (const [ip, n] of [
  ["0.0.0.0", 8],
  ["10.0.0.0", 8],
  ["100.64.0.0", 10],
  ["127.0.0.0", 8],
  ["169.254.0.0", 16],
  ["172.16.0.0", 12],
  ["192.0.0.0", 24],
  ["192.0.2.0", 24],
  ["192.31.196.0", 24],
  ["192.52.193.0", 24],
  ["192.88.99.0", 24],
  ["192.168.0.0", 16],
  ["192.175.48.0", 24],
  ["198.18.0.0", 15],
  ["198.51.100.0", 24],
  ["203.0.113.0", 24],
  ["224.0.0.0", 4],
  ["240.0.0.0", 4],
] as const)
  denied.addSubnet(ip, n, "ipv4");
const globalV6 = new BlockList();
globalV6.addSubnet("2000::", 3, "ipv6");
for (const [ip, n] of [
  ["2001::", 23],
  ["2001:db8::", 32],
  ["2002::", 16],
  ["3fff::", 20],
  ["2620:4f:8000::", 48],
] as const)
  denied.addSubnet(ip, n, "ipv6");
export function publicAddress(ip: string) {
  if (ip.includes("%")) return false;
  const family = isIP(ip);
  return family === 4
    ? !denied.check(ip, "ipv4")
    : family === 6 && globalV6.check(ip, "ipv6") && !denied.check(ip, "ipv6");
}
export function pickAddress(rows: { address: string; family: number }[]) {
  if (!rows.length || rows.some((r) => isIP(r.address) !== r.family || !publicAddress(r.address)))
    throw new RelayFault(
      "The relay only connects to public provider addresses. Use Browser only for a local API.",
      403,
    );
  return rows.find((r) => r.family === 4) || rows[0];
}
export async function providerFetch(input: string, init: RequestInit): Promise<Response> {
  const u = new URL(input);
  if (
    !relayEligible(u.href) ||
    !["GET", "POST"].includes(init.method || "") ||
    !u.pathname.endsWith(init.method === "GET" ? "/models" : "/chat/completions")
  )
    throw new RelayFault("Unsupported relay destination or operation.", 400);
  const deadline = AbortSignal.timeout(230_000);
  const signal = init.signal ? AbortSignal.any([init.signal, deadline]) : deadline;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const rows = await Promise.race([
    lookup(u.hostname, { all: true }),
    new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new RelayFault("Provider DNS timed out.", 504)), 8000);
    }),
  ]).finally(() => clearTimeout(timer));
  const pin = pickAddress(rows);
  signal.throwIfAborted();
  const h = new Headers(init.headers);
  return new Promise<Response>((resolve, reject) => {
    const req = httpsRequest(
      {
        hostname: pin.address,
        family: pin.family,
        port: 443,
        servername: u.hostname,
        rejectUnauthorized: true,
        agent: false,
        signal,
        path: u.pathname,
        method: init.method,
        maxHeaderSize: 32768,
        headers: {
          Host: u.hostname,
          ...(h.has("authorization") ? { Authorization: h.get("authorization")! } : {}),
          Accept: h.get("accept") || "application/json",
          "Accept-Encoding": "identity",
          ...(init.method === "POST" ? { "Content-Type": "application/json" } : {}),
        },
      },
      (res) => {
        const status = res.statusCode ?? 502;
        if (status >= 300 && status < 400) {
          res.destroy();
          reject(
            new RelayFault(
              "The provider redirected this request. Use its final HTTPS API URL; your key was not forwarded to the redirect.",
            ),
          );
          return;
        }
        if (status === 204 || status === 205) {
          res.resume();
          resolve(new Response(null, { status }));
          return;
        }
        let bytes = 0;
        const bounded = (Readable.toWeb(res) as ReadableStream<Uint8Array>).pipeThrough(
          new TransformStream<Uint8Array, Uint8Array>({
            transform(chunk, controller) {
              bytes += chunk.byteLength;
              if (bytes > 8 * 1024 * 1024) {
                controller.error(Error("Provider response exceeded 8 MiB."));
                res.destroy();
                return;
              }
              controller.enqueue(chunk);
            },
          }),
        );
        resolve(
          new Response(bounded, {
            status,
            headers: { "Content-Type": String(res.headers["content-type"] || "") },
          }),
        );
      },
    );
    req.setTimeout(175_000, () =>
      req.destroy(new RelayFault("The provider did not respond in time.", 504)),
    );
    req.on("error", (err) =>
      reject(deadline.aborted ? new RelayFault("The provider timed out.", 504) : err),
    );
    req.end(typeof init.body === "string" ? init.body : undefined);
  });
}
