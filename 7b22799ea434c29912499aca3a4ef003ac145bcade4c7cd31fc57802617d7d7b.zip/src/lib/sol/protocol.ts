import { siteRules } from "./source-policy.ts";
import { reasonFields, modeFor, type Mode } from "./reasoning.ts";
import { providerAt } from "./endpoints.ts";
import type { Role } from "./types.ts";

export type Part =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } }
  | { type: "file"; file: { filename: string; file_data: string } };
export type WireMessage = { role: Role; content: string | Part[] };
export type Source = {
  url: string;
  title: string;
  id?: number;
  startIndex?: number;
  endIndex?: number;
};
// Stored Tavily replies may retain just S3. Old records used the original array position.
export function sourceNumber(source: Source, index: number) {
  return Number.isInteger(source.id) && source.id! >= 1 && source.id! <= 5 ? source.id! : index + 1;
}
export const MAX_BODY = 4_000_000;
export function presetBase(raw: string) {
  return providerAt(raw)?.baseUrl;
}
export const isRouter = (raw: string) => presetBase(raw) === "https://openrouter.ai/api/v1";
export function safeLink(raw: unknown): string | undefined {
  if (typeof raw !== "string" || raw.length > 8192) return;
  try {
    const u = new URL(raw);
    if (["https:", "http:"].includes(u.protocol) && !u.username && !u.password) return u.href;
  } catch {
    /* not a link */
  }
}
export function buildPayload(
  o: {
    baseUrl: string;
    model: string;
    temperature: number;
    maxTokens: number;
    streaming: boolean;
    highReasoning: boolean;
    reasoningModes?: Record<string, Mode>;
    reasoningMode?: Mode;
    webSearch: boolean;
    routerAllowSites?: string;
    routerBlockSites?: string;
  },
  messages: WireMessage[],
) {
  const router = isRouter(o.baseUrl),
    high = router && o.highReasoning;
  const pdf = messages.some(
    (m) => Array.isArray(m.content) && m.content.some((p) => p.type === "file"),
  );
  if (pdf && !router)
    throw Error("This chat contains a PDF. Switch to OpenRouter or start a new chat.");
  const plugins = [];
  let model = o.model.trim();
  const online = model.split(":").includes("online");
  if (router && (o.webSearch || online)) {
    const sites = siteRules(o.routerAllowSites, o.routerBlockSites);
    if (sites.allow.length || sites.block.length) {
      // :online is shorthand for the default web plugin. Replace it with exactly one
      // explicit, filtered OpenRouter plugin; preserve other variant suffixes (:free).
      model = model
        .split(":")
        .filter((part) => part !== "online")
        .join(":");
      plugins.push({
        id: "web",
        max_results: 3,
        engine: "exa",
        ...(sites.allow.length ? { include_domains: sites.allow } : {}),
        ...(sites.block.length ? { exclude_domains: sites.block } : {}),
      });
    } else if (!online) plugins.push({ id: "web", max_results: 3 });
  }
  if (pdf) plugins.push({ id: "file-parser", pdf: { engine: "cloudflare-ai" } });
  return {
    model,
    messages,
    stream: o.streaming,
    ...(providerAt(o.baseUrl)?.id === "groq"
      ? { max_completion_tokens: o.maxTokens }
      : { max_tokens: o.maxTokens }),
    ...reasonFields(
      o.baseUrl,
      o.model,
      o.reasoningMode ?? modeFor(o.baseUrl, o.model, o.reasoningModes),
    ),
    ...(!high
      ? { temperature: o.temperature }
      : { reasoning: { effort: "high", exclude: true }, provider: { require_parameters: true } }),
    ...(plugins.length ? { plugins } : {}),
  };
}
