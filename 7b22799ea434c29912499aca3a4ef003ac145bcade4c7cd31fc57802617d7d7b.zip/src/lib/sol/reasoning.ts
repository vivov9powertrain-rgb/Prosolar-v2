import { providerAt } from "./endpoints.ts";
export type Mode =
  "default" | "none" | "on" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";
type Style = "effort" | "groq-oss" | "groq-qwen" | "nim-switch";
type Rule = { style: Style; modes: readonly Mode[] };
const levels: Mode[] = ["low", "medium", "high"];
const effort = (modes: readonly Mode[] = levels, style: Style = "effort"): Rule => ({
  style,
  modes,
});
// Exact catalog IDs: a similar name (or a custom API on another host) is not a capability signal.
const google: Record<string, Rule> = {};
for (const id of [
  "gemini-2.5-pro",
  "gemini-3.1-pro-preview",
  "gemini-3.8-flash",
  "gemini-4-carbon",
  "gemini-4-argon",
])
  google[id] = effort();
for (const id of ["gemini-2.5-flash", "gemini-2.5-flash-lite"])
  google[id] = effort(["none", ...levels]);
for (const id of [
  "gemini-3-flash-preview",
  "gemini-3.1-flash-lite",
  "gemini-3.5-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.6-flash",
])
  google[id] = effort(["minimal", ...levels]);
google["gemini-3-pro-preview"] = effort(["low", "high"]);
google["gemini-4-hydrogen"] = effort([...levels, "xhigh"]);
const groq: Record<string, Rule> = {
  "openai/gpt-oss-20b": effort(levels, "groq-oss"),
  "openai/gpt-oss-120b": effort(levels, "groq-oss"),
  "qwen/qwen3.8-27b": effort(["none", ...levels], "groq-qwen"),
  "qwen/qwen3-32b": effort(["none", "on"], "groq-qwen"),
  "meta-models/muse-spark-open": effort([...levels, "xhigh"]),
};
const nvidia: Record<string, Rule> = {
  "openai/gpt-oss-20b": effort(),
  "openai/gpt-oss-120b": effort(),
  "mistralai/mistral-large-4-1t-a52b": effort(),
  "z-ai/glm-5.3-flash": effort(["low", "high", "max"]),
};
for (const id of [
  "google/gemma-4-31b-it",
  "google/gemma-4-26b-a4b-it",
  "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",
  "nvidia/nemotron-3-super-120b-a12b",
  "nvidia/nemotron-3-ultra-550b-a55b",
  "nvidia/nemotron-3.5-lightning-30b-a3b",
])
  nvidia[id] = effort(["none", "on"], "nim-switch");
export function reasonRule(base: string, model: string): Rule | undefined {
  const id = providerAt(base)?.id,
    table = id === "google" ? google : id === "nvidia" ? nvidia : id === "groq" ? groq : undefined;
  const name = model.trim().toLowerCase();
  const m = id === "google" ? name.replace(/^models\//, "") : name;
  return table && Object.hasOwn(table, m) ? table[m] : undefined;
}
export const modeKey = (base: string, model: string) =>
  JSON.stringify([providerAt(base)?.id ?? "", model.trim()]);
export function modeFor(base: string, model: string, choices?: Record<string, Mode>): Mode {
  const value = choices?.[modeKey(base, model)];
  return value && reasonRule(base, model)?.modes.includes(value) ? value : "default";
}
type Fields = {
  reasoning_effort?: string;
  include_reasoning?: false;
  reasoning_format?: "hidden";
  chat_template_kwargs?: { enable_thinking: boolean };
};
export function reasonFields(base: string, model: string, mode: Mode): Fields {
  if (mode === "default") return {};
  const r = reasonRule(base, model);
  if (!r || !r.modes.includes(mode))
    throw Error(
      "Unsupported reasoning setting for this provider and model. Select Provider default.",
    );
  if (r.style === "nim-switch") return { chat_template_kwargs: { enable_thinking: mode === "on" } };
  return {
    reasoning_effort: mode === "on" ? "default" : mode,
    ...(r.style === "groq-oss"
      ? { include_reasoning: false as const }
      : r.style === "groq-qwen"
        ? { reasoning_format: "hidden" as const }
        : {}),
  };
}
// The relay reconstructs allowed fields instead of forwarding arbitrary template/options objects.
export function modeFromWire(base: string, model: string, b: Record<string, unknown>): Mode {
  const e = b.reasoning_effort,
    k = b.chat_template_kwargs;
  if (e === undefined && k === undefined) return "default";
  for (const mode of reasonRule(base, model)?.modes ?? []) {
    const f = reasonFields(base, model, mode);
    if (f.reasoning_effort !== e) continue;
    if (k === undefined && f.chat_template_kwargs === undefined) return mode;
    if (
      k &&
      typeof k === "object" &&
      f.chat_template_kwargs &&
      (k as { enable_thinking?: unknown }).enable_thinking ===
        f.chat_template_kwargs.enable_thinking &&
      Object.keys(k).length === 1
    )
      return mode;
  }
  throw Error("Unsupported reasoning fields for this endpoint and model.");
}
export function budgetSuggestion(base: string, model: string, mode: Mode) {
  if (mode === "default" || mode === "none") return 0;
  if (providerAt(base)?.id === "google" && model.startsWith("gemini-2.5-"))
    return mode === "high" ? 32768 : mode === "medium" ? 10240 : 2048;
  return mode === "low" || mode === "minimal" ? 2048 : 4096;
}
