import { NO_SITES, siteRules, type SiteRules } from "./source-policy.ts";
import { rankHits, type Hit } from "./search-ranking.ts";
export type { Hit } from "./search-ranking.ts";
import type { SearchConfig } from "./search-settings.ts";
export const TAVILY_URL = "https://api.tavily.com/search";
export function queryText(raw: string) {
  return Array.from(raw.trim().replace(/\s+/g, " ")).slice(0, 400).join("");
}
// The local route takes an evidence cap (1–5). Tavily sees a larger candidate pool in the *same* POST.
export function relaySearchBody(
  query: string,
  depth: SearchConfig["depth"],
  count: number,
  rules: SiteRules = NO_SITES,
) {
  return {
    query: queryText(query),
    search_depth: depth === "advanced" ? "advanced" : "basic",
    max_results: Math.min(5, Math.max(1, Number.isInteger(count) ? count : 3)),
    ...(rules.allow.length ? { include_domains: rules.allow } : {}),
    ...(rules.block.length ? { exclude_domains: rules.block } : {}),
  };
}
export function searchBody(
  query: string,
  depth: SearchConfig["depth"],
  count: number,
  rules: SiteRules = NO_SITES,
) {
  const body = relaySearchBody(query, depth, count, rules);
  return {
    ...body,
    max_results: Math.min(10, Math.max(5, body.max_results * 2)),
    safe_search: true,
    include_answer: false,
    include_images: false,
    include_raw_content: false,
    auto_parameters: false,
    ...(rules.allow.length ? { include_domains_mode: "restrict" } : {}),
  };
}
export const hitsFrom = rankHits;
export async function readSmallJson(source: Request | Response, limit: number): Promise<unknown> {
  if (Number(source.headers.get("content-length")) > limit) {
    await source.body?.cancel();
    throw RangeError("Exceeded size limit.");
  }
  const r = source.body?.getReader();
  if (!r) throw Error("Empty response.");
  const dec = new TextDecoder();
  let n = 0,
    s = "";
  try {
    for (;;) {
      const { done, value } = await r.read();
      if (done) break;
      n += value.byteLength;
      if (n > limit) {
        await r.cancel();
        throw RangeError("Exceeded size limit.");
      }
      s += dec.decode(value, { stream: true });
    }
    return JSON.parse(s + dec.decode());
  } finally {
    r.releaseLock();
  }
}
export const searchError = (status: number) =>
  status === 401 || status === 403
    ? "Check the Tavily key in Web search settings."
    : status === 429
      ? "Tavily rate limit reached. Wait before trying again."
      : [402, 432, 433, 434].includes(status)
        ? "Check the usage and credits on your Tavily account."
        : status === 504
          ? "Tavily timed out."
          : "Search failed. Check your query and Tavily connection.";
export async function fetchSearch(
  query: string,
  cfg: SearchConfig,
  direct: boolean,
  signal: AbortSignal,
): Promise<Hit[]> {
  const key = cfg.apiKey.trim();
  if (!key) throw Error("Add your Tavily API key in Web search settings.");
  const rules = siteRules(cfg.allowSites, cfg.blockSites);
  const body = (direct ? searchBody : relaySearchBody)(query, cfg.depth, cfg.results, rules),
    deadline = AbortSignal.timeout(25000);
  if (!body.query) throw Error("Enter a search question.");
  try {
    const res = await fetch(direct ? TAVILY_URL : "/api/search", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + key,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      signal: AbortSignal.any([signal, deadline]),
      credentials: direct ? "omit" : "same-origin",
      cache: "no-store",
      redirect: "error",
      referrerPolicy: "no-referrer",
    });
    if (!direct && res.headers.get("x-sol-search") !== "1") {
      await res.body?.cancel();
      throw Error("The sol search relay did not respond. Deploy the full update with /api/search.");
    }
    if (!res.ok) {
      await res.body?.cancel();
      throw Error(`Tavily HTTP ${res.status} · ${searchError(res.status)}`);
    }
    // Refuse a stale relay that did not enforce upstream Safe Search. Revalidating
    // its bounded, scored rows uses the exact same window and ordering as direct mode.
    if (!direct && res.headers.get("x-sol-search-policy") !== "2") {
      await res.body?.cancel();
      throw Error(
        "Update the sol search relay before searching: this version requires Safe Search.",
      );
    }
    return hitsFrom(await readSmallJson(res, 512 * 1024), cfg.results, body.query, rules);
  } catch (e) {
    signal.throwIfAborted();
    if (deadline.aborted) throw Error("Tavily search timed out.");
    if (e instanceof TypeError)
      throw Error(
        direct
          ? "Cannot reach Tavily from the browser. Try Automatic route."
          : "Cannot reach the sol search relay.",
      );
    throw e;
  }
}
