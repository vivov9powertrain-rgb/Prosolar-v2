import { NO_SITES, badLanding, sourceUrl, type SiteRules } from "./source-policy.ts";
export type Hit = { title: string; url: string; content: string; score?: number };
// Remove conversational scaffolding, not versions, place names or words such as "not".
const stop = new Set(
  "a an the is are was were am be being been to of for from by on in at it its and or nor but which when how what why who does do did will can could would should may might has have had with as so i me my we our us your you this that those these about give tell get please find search look up web links link sites site official source sources information regarding need want answer latest current recent new best more any using use says show results based online according related really than there their them also some specific topic details just today now check out there where after before s t re".split(
    " ",
  ),
);
const seg =
  typeof Intl.Segmenter === "function"
    ? new Intl.Segmenter(undefined, { granularity: "word" })
    : null;
export function topicWords(text: string): Set<string> {
  let s = text.normalize("NFKC").toLowerCase();
  if (seg && /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Thai}]/u.test(s))
    s = Array.from(seg.segment(s), (x) => x.segment).join(" ");
  const out = new Set<string>();
  for (let t of s.match(/[\p{L}\p{N}][\p{L}\p{N}\p{M}]*(?:\.[0-9]+)*[+#]*/gu) ?? []) {
    if (stop.has(t)) continue;
    if (/^[a-z]{4,}s$/.test(t) && !/(ss|us|is)$/.test(t)) t = t.slice(0, -1);
    out.add(t);
  }
  return out;
}
// Intent words can help order results but cannot identify the subject on their own.
const intent = new Set(
  "hour opening close closing open time price cost ticket date day release version requirement document guide documentation update policy fee rate help example admission download change new latest reference".split(
    " ",
  ),
);
export const subjects = (words: Iterable<string>) =>
  [...words].filter((t) => /\p{L}/u.test(t) && !intent.has(t));
export const quotedPhrases = (s: string) =>
  [...s.matchAll(/["“`]([^"”`\n]{2,100})["”`]/g)].map((m) => m[1].normalize("NFKC").toLowerCase());
/** High-precision local triage, not a fact checker. Zero acceptable results is a normal outcome. */
export function rankHits(
  data: unknown,
  count: number,
  query: string,
  rules: SiteRules = NO_SITES,
): Hit[] {
  const rows = (data as { results?: unknown } | null)?.results;
  if (!Array.isArray(rows)) throw Error("Tavily did not return a readable results list.");
  const q = [...topicWords(query)],
    ranked: { hit: Hit; rank: number; host: string }[] = [];
  if (!q.length) return [];
  const subject = subjects(q),
    phrases = quotedPhrases(query);
  for (const r of rows.slice(0, 30)) {
    const url = sourceUrl(r?.url, rules);
    if (!url || typeof r.content !== "string") continue;
    const host = new URL(url).hostname.replace(/^www\./, ""),
      title = (typeof r.title === "string" ? r.title.trim() : "").slice(0, 180) || host;
    // Match only the bounded text that the answer model will actually see (same on direct and relay).
    const content = r.content.trim().slice(0, 1200).trimEnd();
    if (content.length < 16 || badLanding.test(title) || badLanding.test(content)) continue;
    const score = r.score;
    if (
      score != null &&
      (typeof score !== "number" || !Number.isFinite(score) || score < 0.48 || score > 1)
    )
      continue;
    const head = topicWords(title),
      body = topicWords(content);
    const matches = q.filter((t) => head.has(t) || body.has(t));
    // A date or version alone does not establish the subject of a question.
    if (
      !matches.length ||
      (q.some((t) => /\p{L}/u.test(t)) && !matches.some((t) => /\p{L}/u.test(t)))
    )
      continue;
    if (subject.length && !subject.some((t) => matches.includes(t))) continue;
    if (
      phrases.length &&
      phrases.some((p) => !(title + " " + content).normalize("NFKC").toLowerCase().includes(p))
    )
      continue;
    const fraction = matches.length / q.length,
      heading = q.filter((t) => head.has(t)).length / q.length;
    if (q.length >= 3 && matches.length < 2) continue;
    if (score == null ? fraction < 0.55 : fraction < (score >= 0.77 ? 0.25 : 0.45)) continue;
    const rank = 0.52 * (score ?? 0.5) + 0.32 * fraction + 0.16 * heading;
    ranked.push({ hit: { title, url, content, ...(score == null ? {} : { score }) }, rank, host });
  }
  ranked.sort((a, b) => b.rank - a.rank);
  const urls = new Set<string>(),
    texts = new Set<string>();
  const unique = ranked.filter(({ hit }) => {
    const id = hit.url.split("#")[0],
      excerpt = hit.content.replace(/\s+/g, " ").toLowerCase();
    if (urls.has(id) || (excerpt.length >= 90 && texts.has(excerpt))) return false;
    urls.add(id);
    texts.add(excerpt);
    return true;
  });
  const hosts = new Set<string>(),
    out: Hit[] = [];
  while (unique.length && out.length < Math.max(1, Math.min(5, count))) {
    const fresh = unique.findIndex((x) => !hosts.has(x.host) && x.rank >= unique[0].rank - 0.06);
    const [item] = unique.splice(fresh < 0 ? 0 : fresh, 1);
    out.push(item.hit);
    hosts.add(item.host);
  }
  return out;
}
