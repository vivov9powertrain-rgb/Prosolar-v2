import { siteRules } from "./source-policy.ts";
import { modeFromWire } from "./reasoning.ts";
import { apiBase, providerAt, relayEligible } from "./endpoints.ts";
import { providerFetch, RelayFault } from "./public-provider.server.ts";
import { errorText } from "./replies.ts";
import { buildPayload, MAX_BODY, presetBase, type WireMessage } from "./protocol.ts";
const bad = (message: string, status = 400) =>
  Response.json(
    { error: { message } },
    {
      status,
      headers: {
        "Cache-Control": "no-store",
        "X-Sol-Relay": "1",
        "X-Content-Type-Options": "nosniff",
      },
    },
  );
const record = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);
function validMessage(m: unknown): m is WireMessage {
  if (!record(m) || !["user", "system", "assistant"].includes(String(m.role))) return false;
  if (typeof m.content === "string") return true;
  return (
    m.role === "user" &&
    Array.isArray(m.content) &&
    m.content.length > 0 &&
    m.content.length <= 4 &&
    m.content.every((p) => {
      if (!record(p)) return false;
      if (p.type === "text") return typeof p.text === "string";
      if (p.type === "image_url" && record(p.image_url))
        return (
          typeof p.image_url.url === "string" &&
          /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(p.image_url.url)
        );
      if (p.type === "file" && record(p.file))
        return (
          typeof p.file.filename === "string" &&
          p.file.filename.length <= 240 &&
          typeof p.file.file_data === "string" &&
          /^data:application\/pdf;base64,[A-Za-z0-9+/]+=*$/.test(p.file.file_data)
        );
      return false;
    })
  );
}
async function limitedBody(request: Request): Promise<unknown> {
  if (Number(request.headers.get("content-length")) > MAX_BODY) throw RangeError();
  const reader = request.body?.getReader();
  if (!reader) throw Error();
  const decoder = new TextDecoder();
  let size = 0,
    text = "";
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BODY) {
        await reader.cancel();
        throw RangeError();
      }
      text += decoder.decode(value, { stream: true });
    }
  } finally {
    reader.releaseLock();
  }
  return JSON.parse(text + decoder.decode());
}
export async function relayChat(
  request: Request,
  upstream: (url: string, init: RequestInit) => Promise<Response> = providerFetch,
) {
  const origin = request.headers.get("origin"),
    site = request.headers.get("sec-fetch-site");
  if (
    site === "cross-site" ||
    (origin && site !== "same-origin" && origin !== new URL(request.url).origin)
  )
    return bad("Use the relay from this sol deployment.", 403);
  if (!request.headers.get("content-type")?.includes("application/json"))
    return bad("Expected JSON.", 415);
  let b: unknown;
  try {
    b = await limitedBody(request);
  } catch (e) {
    return e instanceof RangeError ? bad("Chat exceeds 4 MB.", 413) : bad("Expected JSON.");
  }
  if (!record(b) || typeof b.baseUrl !== "string") return bad("Base URL is required.");
  // The JSON-key fallback is for already-open clients on the previous release.
  const auth = request.headers.get("authorization");
  const key = auth?.startsWith("Bearer ")
    ? auth.slice(7).trim()
    : typeof b.apiKey === "string"
      ? b.apiKey.trim()
      : "";
  let base: string;
  try {
    base = apiBase(b.baseUrl);
  } catch {
    return bad("Invalid API URL.");
  }
  const probe = b.probe === "models";
  if (
    (!key && !(probe && providerAt(base)?.publicModels)) ||
    key.length > 8192 ||
    /[\r\n]/.test(key)
  )
    return bad("Enter a valid provider API key.");
  if (!relayEligible(base))
    return bad(
      "The sol relay needs a public HTTPS domain on port 443. Choose Browser only for a local or private endpoint.",
    );
  // An optional deployment allowlist limits non-preset providers. It is never client-controlled.
  const allow = process.env.SOL_RELAY_BASE_URLS?.trim();
  if (
    allow &&
    !presetBase(base) &&
    !allow.split(/[\s,]+/).some((raw) => {
      try {
        return apiBase(raw) === base;
      } catch {
        return false;
      }
    })
  )
    return bad(
      "This custom API is not on this deployment’s SOL_RELAY_BASE_URLS list. Ask the deployment owner or choose Browser only.",
      403,
    );
  let body: string | undefined;
  if (!probe) {
    if (typeof b.model !== "string" || !b.model.trim() || typeof b.stream !== "boolean")
      return bad("Model and streaming setting are required.");
    if (!Array.isArray(b.messages) || !b.messages.length || !b.messages.every(validMessage))
      return bad("Invalid messages or attachment format.");
    const budget =
      providerAt(base)?.id === "groq" ? (b.max_completion_tokens ?? b.max_tokens) : b.max_tokens;
    if (typeof budget !== "number" || !Number.isInteger(budget) || budget < 1 || budget > 131072)
      return bad("Invalid max tokens.");
    const web = Array.isArray(b.plugins)
      ? b.plugins.find((p) => record(p) && p.id === "web")
      : undefined;
    try {
      const sites =
        providerAt(base)?.id === "openrouter" && record(web)
          ? siteRules(web.include_domains, web.exclude_domains)
          : undefined;
      body = JSON.stringify(
        buildPayload(
          {
            baseUrl: base,
            model: b.model,
            temperature: typeof b.temperature === "number" ? b.temperature : 0.9,
            maxTokens: budget,
            reasoningMode: modeFromWire(base, b.model, b),
            streaming: b.stream,
            highReasoning: record(b.reasoning) && b.reasoning.effort === "high",
            webSearch: !!web,
            routerAllowSites: sites?.allow.join(","),
            routerBlockSites: sites?.block.join(","),
          },
          b.messages.map(({ role, content }) => ({
            role,
            content:
              typeof content === "string"
                ? content
                : content.map((p) =>
                    p.type === "text"
                      ? { type: "text", text: p.text }
                      : p.type === "file"
                        ? {
                            type: "file",
                            file: { filename: p.file.filename, file_data: p.file.file_data },
                          }
                        : { type: "image_url", image_url: { url: p.image_url.url } },
                  ),
          })),
        ),
      );
    } catch (e) {
      return bad(e instanceof Error ? e.message : "Invalid options.");
    }
  }
  try {
    const res = await upstream(`${base}/${probe ? "models" : "chat/completions"}`, {
      method: probe ? "GET" : "POST",
      body,
      headers: {
        ...(key ? { Authorization: `Bearer ${key}` } : {}),
        "Content-Type": "application/json",
        Accept: !probe && b.stream ? "text/event-stream" : "application/json",
      },
      signal: request.signal,
      redirect: "error",
    });
    const mime = (res.headers.get("content-type") ?? "").split(";")[0].trim().toLowerCase();
    if (!res.ok) {
      if (res.status >= 300 && res.status < 400) {
        await res.body?.cancel();
        return bad("Provider returned a redirect. Use the final API URL.", 502);
      }
      const raw = await res.text();
      const detail = errorText(raw, res.status);
      return bad(key ? detail.replaceAll(key, "[redacted]") : detail, res.status);
    }
    if (
      mime !== "application/json" &&
      !/^application\/[a-z0-9.-]+\+json$/.test(mime) &&
      (probe || mime !== "text/event-stream")
    ) {
      await res.body?.cancel();
      return bad("The provider did not return JSON or a chat stream. Check the API base URL.", 502);
    }
    return new Response(res.body, {
      status: res.status,
      headers: {
        "Content-Type": mime,
        "Cache-Control": "no-store, no-transform",
        "X-Accel-Buffering": "no",
        "X-Sol-Relay": "1",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    return err instanceof RelayFault
      ? bad(err.message, err.httpStatus)
      : bad(
          "The sol server could not reach the provider over HTTPS. Check the API address and the provider’s availability.",
          502,
        );
  }
}
