import { buildPayload, MAX_BODY, type WireMessage } from "./protocol.ts";
import { apiBase, endpoint, providerAt, relayEligible } from "./endpoints.ts";
import { parseCatalog } from "./models.ts";
import { errorText, readReply, type ReplyHandlers } from "./replies.ts";
import type { Settings } from "./types.ts";

export function routeFor(raw: string, mode: Settings["transport"] = "auto"): "browser" | "relay" {
  const base = apiBase(raw);
  if (mode === "browser") return "browser";
  if (mode === "relay") {
    if (!relayEligible(base))
      throw Error(
        "The sol relay requires a public HTTPS domain on port 443. Use Browser only for a local API.",
      );
    return "relay";
  }
  const known = providerAt(base);
  return relayEligible(base) && (!known || known.preferRelay) ? "relay" : "browser";
}
class HttpError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}
async function call(
  raw: string,
  apiKey: string,
  mode: Settings["transport"],
  body?: ReturnType<typeof buildPayload>,
  signal?: AbortSignal,
) {
  const key = apiKey.trim();
  const baseUrl = apiBase(raw),
    resource = body ? "chat/completions" : "models",
    path = routeFor(baseUrl, mode);
  if (!key && (body || !providerAt(baseUrl)?.publicModels))
    throw Error("Add your provider API key in Connection.");
  const payload = body ? JSON.stringify(body) : undefined,
    envelope = JSON.stringify({ baseUrl, ...(body || { probe: "models" }) });
  if (new Blob([envelope]).size > MAX_BODY)
    throw Error(
      "This chat exceeds the 4 MB request limit. Start a new chat with fewer or smaller files.",
    );
  const auth: Record<string, string> = key ? { Authorization: `Bearer ${key}` } : {};
  async function relay() {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { ...auth, "Content-Type": "application/json" },
      body: envelope,
      signal,
      redirect: "error",
      credentials: "same-origin",
      cache: "no-store",
    });
    if (response.headers.get("x-sol-relay") !== "1")
      throw Error(
        "The sol relay did not respond. Deploy the updated full app with /api/chat enabled, and check your deployment access.",
      );
    return response;
  }
  let r: Response;
  try {
    if (path === "relay") r = await relay();
    else
      try {
        r = await fetch(endpoint(baseUrl, resource), {
          method: body ? "POST" : "GET",
          headers: {
            ...auth,
            Accept: body?.stream ? "text/event-stream" : "application/json",
            ...(body ? { "Content-Type": "application/json" } : {}),
          },
          body: payload,
          signal,
          redirect: "error",
          credentials: "omit",
          cache: "no-store",
        });
      } catch (e) {
        if (signal?.aborted) throw e;
        // A catalogue GET is safe to retry. Never silently replay a billed chat POST.
        if (mode === "auto" && !body && relayEligible(baseUrl)) r = await relay();
        else
          throw Error(
            relayEligible(baseUrl)
              ? "Browser access failed. In Connection, set Request route to sol relay, then retry."
              : "Browser access failed. A private or local API must be reachable from your browser and allow CORS.",
          );
      }
  } catch (e) {
    if (signal?.aborted) throw e;
    if (e instanceof Error && !(e instanceof TypeError)) throw e;
    throw Error(
      "Could not reach the sol relay. Deploy the full app, including /api/chat, not just its static assets.",
    );
  }
  if (!r.ok) {
    const text = errorText(await r.text(), r.status);
    const detail = key ? text.replaceAll(key, "[redacted]") : text;
    throw new HttpError(`HTTP ${r.status} · ${detail}`, r.status);
  }
  return r;
}
export async function streamCompletion(
  settings: Settings,
  messages: WireMessage[],
  signal: AbortSignal,
  handlers: ReplyHandlers,
) {
  if (!settings.model.trim()) throw Error("Choose a model in Connection.");
  await readReply(
    await call(
      settings.baseUrl,
      settings.apiKey,
      settings.transport ?? "auto",
      buildPayload(settings, messages),
      signal,
    ),
    handlers,
  );
}
export async function testConnection(
  base: string,
  key: string,
  mode: Settings["transport"] = "auto",
  signal?: AbortSignal,
) {
  let res: Response;
  try {
    res = await call(base, key, mode, undefined, signal);
  } catch (e) {
    if (e instanceof HttpError && [404, 405, 501].includes(e.status))
      return { listed: false, ids: [] as string[] };
    throw e;
  }
  if (!res.headers.get("content-type")?.toLowerCase().includes("json"))
    throw Error(
      "The model-list URL did not return JSON. Check the base URL and that /api/chat is deployed.",
    );
  return parseCatalog(base, await res.json());
}
