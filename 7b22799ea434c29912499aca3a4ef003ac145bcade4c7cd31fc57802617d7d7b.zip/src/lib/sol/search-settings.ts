import { hasControlChars } from "./endpoints.ts";
export type SearchConfig = {
  apiKey: string;
  enabled: boolean;
  strategy: "always" | "model";
  depth: "basic" | "advanced";
  results: number;
  instructions: string;
  allowSites: string;
  blockSites: string;
};
export const DEFAULT_SEARCH: SearchConfig = {
  apiKey: "",
  enabled: false,
  strategy: "always",
  depth: "basic",
  results: 3,
  instructions: "",
  allowSites: "",
  blockSites: "",
};
export function searchConfig(raw?: Partial<SearchConfig>, keys = true): SearchConfig {
  const k = raw?.apiKey;
  const apiKey = keys && typeof k === "string" && k.length <= 8192 && !hasControlChars(k) ? k : "";
  return {
    apiKey,
    enabled: raw?.enabled === true && !!apiKey.trim(),
    strategy: raw?.strategy === "model" ? "model" : "always",
    depth: raw?.depth === "advanced" ? "advanced" : "basic",
    results: Number.isInteger(raw?.results) ? Math.max(1, Math.min(5, raw!.results!)) : 3,
    allowSites: typeof raw?.allowSites === "string" ? raw.allowSites.slice(0, 1200) : "",
    blockSites: typeof raw?.blockSites === "string" ? raw.blockSites.slice(0, 1200) : "",
    instructions: typeof raw?.instructions === "string" ? raw.instructions.slice(0, 600) : "",
  };
}
