import { namedProvider } from "./custom-providers";
import { searchConfig, type SearchConfig } from "./search-settings";
import {
  changeSettings,
  deviceForDisk,
  restoreDevice,
  switchEndpoint,
  type Device,
  type SavedDevice,
  type SettingsPatch,
} from "./connections";
import { forgetFiles } from "./files";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { greeting } from "./prompt";
import { type Character, type ChatMessage, type ChatThread } from "./types";

function id() {
  return crypto.randomUUID();
}

// A neutral, prompt-free context, not a saved persona or character card.
export const PLAIN: Character = {
  id: "sol:plain",
  name: "sol",
  tagline: "",
  description: "",
  personality: "",
  scenario: "",
  firstMessage: "",
  example: "",
  extra: "",
  hue: 0,
};
const retired = (id: string) => id === "seed-mira" || id === "seed-cole";

type State = Device & {
  characters: Character[];
  threads: ChatThread[];
  activeThreadId: string | null;
  updateSearch: (patch: Partial<SearchConfig>) => void;
  saveProvider: (name: string) => void;
  removeProvider: (base: string) => void;
  activateEndpoint: (raw: string) => void;
  setRememberKeys: (on: boolean) => void;
  suggestModel: (base: string, model: string) => void;
  upsertCharacter: (character: Character) => void;
  deleteCharacter: (characterId: string) => void;
  openCharacter: (characterId: string) => void;
  newThread: (characterId: string) => void;
  setActiveThread: (threadId: string) => void;
  deleteThread: (threadId: string) => void;
  appendMessage: (threadId: string, message: ChatMessage) => void;
  updateMessage: (threadId: string, messageId: string, content: string) => void;
  truncateAfter: (threadId: string, messageId: string) => void;
  popLastIfAssistant: (threadId: string) => void;
  patchSettings: (patch: SettingsPatch) => void;
  importCharacter: (raw: unknown) => Character | null;
};

type Snapshot = Pick<State, "characters" | "threads" | "activeThreadId"> & SavedDevice;
export const useSol = create<State>()(
  persist(
    (set, get) => ({
      characters: [],
      threads: [],
      activeThreadId: null,
      ...restoreDevice(),
      updateSearch: (patch) => set((s) => ({ search: searchConfig({ ...s.search, ...patch }) })),
      saveProvider: (name) =>
        set((s) => ({
          customProviders: namedProvider(s.customProviders, s.settings.baseUrl, name),
        })),
      removeProvider: (base) =>
        set((s) => {
          if (!Object.hasOwn(s.customProviders, base)) return s;
          const customProviders = { ...s.customProviders },
            connections = { ...s.connections };
          delete customProviders[base];
          delete connections[base];
          return {
            customProviders,
            connections,
            ...(s.settings.baseUrl === base ? switchEndpoint(s, "") : {}),
            lastCustomBase: s.lastCustomBase === base ? "" : s.lastCustomBase,
          };
        }),
      activateEndpoint: (raw) => set((s) => switchEndpoint(s, raw)),
      setRememberKeys: (on) => set({ rememberKeys: on }),
      suggestModel: (base, model) =>
        set((s) =>
          s.settings.baseUrl !== base || s.connections[base]?.pinned || s.settings.model === model
            ? s
            : changeSettings(s, { model }, true),
        ),

      upsertCharacter: (character) =>
        set((s) => {
          const exists = s.characters.some((c) => c.id === character.id);
          return {
            characters: exists
              ? s.characters.map((c) => (c.id === character.id ? character : c))
              : [character, ...s.characters],
          };
        }),

      deleteCharacter: (characterId) =>
        set((s) => {
          const threads = s.threads.filter((t) => t.characterId !== characterId);
          const active =
            s.activeThreadId && threads.some((t) => t.id === s.activeThreadId)
              ? s.activeThreadId
              : (threads[0]?.id ?? null);
          return {
            characters: s.characters.filter((c) => c.id !== characterId),
            threads,
            activeThreadId: active,
          };
        }),

      openCharacter: (characterId) => {
        const existing = get()
          .threads.filter((t) => t.characterId === characterId)
          .sort((a, b) => b.updatedAt - a.updatedAt)[0];
        if (existing) {
          set({ activeThreadId: existing.id });
          return;
        }
        get().newThread(characterId);
      },

      newThread: (characterId) => {
        const character =
          characterId === PLAIN.id ? PLAIN : get().characters.find((c) => c.id === characterId);
        if (!character) return;
        const opening = greeting(character, get().settings);
        const thread: ChatThread = {
          id: id(),
          characterId,
          title: "New conversation",
          messages: opening ? [{ id: id(), role: "assistant", content: opening }] : [],
          updatedAt: Date.now(),
        };
        set((s) => ({
          threads: [thread, ...s.threads],
          activeThreadId: thread.id,
        }));
      },

      setActiveThread: (threadId) => set({ activeThreadId: threadId }),

      deleteThread: (threadId) =>
        set((s) => {
          const threads = s.threads.filter((t) => t.id !== threadId);
          return {
            threads,
            activeThreadId:
              s.activeThreadId === threadId ? (threads[0]?.id ?? null) : s.activeThreadId,
          };
        }),

      appendMessage: (threadId, message) =>
        set((s) => ({
          threads: s.threads.map((t) => {
            if (t.id !== threadId) return t;
            const title =
              t.title === "New conversation" && message.role === "user"
                ? (message.content || message.attachments?.[0]?.name || "New conversation")
                    .replace(/\s+/g, " ")
                    .slice(0, 42)
                : t.title;
            return {
              ...t,
              title: title || t.title,
              messages: [...t.messages, message],
              updatedAt: Date.now(),
            };
          }),
        })),

      updateMessage: (threadId, messageId, content) =>
        set((s) => ({
          threads: s.threads.map((t) =>
            t.id === threadId
              ? {
                  ...t,
                  messages: t.messages.map((m) => (m.id === messageId ? { ...m, content } : m)),
                  updatedAt: Date.now(),
                }
              : t,
          ),
        })),

      truncateAfter: (threadId, messageId) =>
        set((s) => ({
          threads: s.threads.map((t) => {
            if (t.id !== threadId) return t;
            const index = t.messages.findIndex((m) => m.id === messageId);
            if (index < 0) return t;
            return { ...t, messages: t.messages.slice(0, index + 1), updatedAt: Date.now() };
          }),
        })),

      popLastIfAssistant: (threadId) =>
        set((s) => ({
          threads: s.threads.map((t) => {
            if (t.id !== threadId) return t;
            const last = t.messages[t.messages.length - 1];
            if (!last || last.role !== "assistant") return t;
            return { ...t, messages: t.messages.slice(0, -1), updatedAt: Date.now() };
          }),
        })),

      patchSettings: (patch) => set((s) => changeSettings(s, patch)),

      importCharacter: (raw) => {
        const parsed = normalizeCard(raw);
        if (!parsed) return null;
        get().upsertCharacter(parsed);
        return parsed;
      },
    }),
    {
      name: "hearth-v1",
      version: 1,
      partialize: (s): Snapshot => ({
        characters: s.characters,
        threads: s.threads,
        activeThreadId: s.activeThreadId,
        ...deviceForDisk(s),
      }),
      migrate: (prior): Snapshot => {
        const s = (prior ?? {}) as Partial<Snapshot>;
        return {
          characters: s.characters ?? [],
          threads: s.threads ?? [],
          activeThreadId: s.activeThreadId ?? null,
          ...deviceForDisk(restoreDevice(s)),
        };
      },
      merge: (persisted, current) => {
        const saved = persisted as Partial<Snapshot> | undefined;
        const characters = (saved?.characters ?? []).filter((c) => !retired(c.id));
        const threads = (saved?.threads ?? [])
          .filter((t) => !retired(t.characterId) || t.messages.some((m) => m.role === "user"))
          .map((t) => (retired(t.characterId) ? { ...t, characterId: PLAIN.id } : t));
        return {
          ...current,
          ...restoreDevice(saved),
          characters,
          threads,
          activeThreadId:
            threads.find((t) => t.id === saved?.activeThreadId)?.id ?? threads[0]?.id ?? null,
        };
      },
      skipHydration: true,
    },
  ),
);

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

function str(value: unknown) {
  return typeof value === "string" ? value : "";
}

export function normalizeCard(raw: unknown): Character | null {
  const root = asRecord(raw);
  if (!root) return null;
  const data = asRecord(root.data) ?? root;
  const name = str(data.name).trim();
  if (!name) return null;
  return {
    id: id(),
    name,
    tagline: str(data.tagline || data.creator_notes).slice(0, 140),
    description: str(data.description),
    personality: str(data.personality),
    scenario: str(data.scenario),
    firstMessage: str(data.first_mes || data.firstMessage),
    example: str(data.mes_example || data.example),
    extra: str(data.system_prompt || data.extra),
    hue: Math.floor(Math.random() * 360),
  };
}

export function blankCharacter(): Character {
  return {
    id: id(),
    name: "",
    tagline: "",
    description: "",
    personality: "",
    scenario: "",
    firstMessage: "",
    example: "",
    extra: "",
    hue: Math.floor(Math.random() * 360),
  };
}

export function exportCard(character: Character) {
  return {
    spec: "chara_card_v2",
    spec_version: "2.0",
    data: {
      name: character.name,
      description: character.description,
      personality: character.personality,
      scenario: character.scenario,
      first_mes: character.firstMessage,
      mes_example: character.example,
      system_prompt: character.extra,
      creator_notes: character.tagline,
      tags: [],
    },
  };
}

// A deleted/truncated turn should not leave its attachment bodies on disk.
useSol.subscribe((now, before) => {
  if (now.threads === before.threads || typeof indexedDB === "undefined") return;
  const ids = (threads: ChatThread[]) =>
    threads.flatMap((t) => t.messages.flatMap((m) => (m.attachments ?? []).map((f) => f.id)));
  const old = ids(before.threads);
  if (!old.length) return;
  const keep = new Set(ids(now.threads));
  void forgetFiles(old.filter((id) => !keep.has(id))).catch(() => {});
});
