import { filePart } from "./files.ts";
import { sourceUrl } from "./source-policy.ts";
import { sourceNumber, isRouter, type WireMessage, MAX_BODY } from "./protocol.ts";
import type { Character, ChatMessage, Settings } from "./types.ts";

function fill(text: string, charName: string, userName: string) {
  return text
    .replaceAll("{{char}}", charName)
    .replaceAll("{{user}}", userName)
    .replaceAll("{{Char}}", charName)
    .replaceAll("{{User}}", userName);
}

/** Only text the user actually wrote. Empty card ⇒ no system message. */
export function systemPrompt(character: Character, settings: Settings) {
  const user = settings.userName.trim() || "You";
  const blocks = [
    character.description.trim() && character.description,
    character.personality.trim() && `Personality:\n${character.personality}`,
    character.scenario.trim() && `Scenario:\n${character.scenario}`,
    settings.userPersona.trim() &&
      `The person you are speaking with is ${user}.\n${settings.userPersona.trim()}`,
    character.example.trim() && `Example dialogue:\n${character.example}`,
    character.extra.trim() && character.extra,
  ].filter(Boolean) as string[];
  if (blocks.length === 0) return "";
  return fill(blocks.join("\n\n"), character.name, user);
}

export async function toApiMessages(
  character: Character,
  settings: Settings,
  messages: ChatMessage[],
) {
  const user = settings.userName.trim() || "You";
  const system = systemPrompt(character, settings);
  const api: WireMessage[] = [];
  const files = messages.flatMap((m) => m.attachments ?? []);
  if (files.some((f) => f.kind === "pdf") && !isRouter(settings.baseUrl))
    throw Error("This chat contains a PDF. Switch to OpenRouter or start a new chat.");
  if (files.reduce((sum, f) => sum + f.size * (f.kind === "text" ? 1 : 4 / 3), 0) >= MAX_BODY)
    throw Error(
      "Attachments in this chat exceed the request limit. Start a new chat with fewer files.",
    );
  if (system) api.push({ role: "system", content: system });
  for (const message of messages) {
    const text = fill(message.content, character.name, user);
    if (message.role !== "user" || !message.attachments?.length) {
      const prior =
        message.role === "assistant" && message.webLookup === "tavily"
          ? message.sources
              ?.slice(0, 5)
              .map((s, i) => {
                const u = sourceUrl(s.url);
                return u ? `S${sourceNumber(s, i)}: ${u}` : "";
              })
              .filter(Boolean)
          : undefined;
      api.push({
        role: message.role,
        content: prior?.length
          ? text + "\n\nSource IDs for that earlier reply:\n" + prior.join("\n")
          : text,
      });
      continue;
    }
    const parts = await Promise.all(message.attachments.map(filePart));
    const prompt = text || "Please review the attached files.";
    // Text-only messages work with ordinary OpenAI-compatible providers too.
    api.push({
      role: "user",
      content: parts.every((p) => p.type === "text")
        ? [prompt, ...parts.map((p) => (p.type === "text" ? p.text : ""))].join("\n\n")
        : [{ type: "text", text: prompt }, ...parts],
    });
  }
  return api;
}

export function greeting(character: Character, settings: Settings) {
  const user = settings.userName.trim() || "You";
  const raw = character.firstMessage.trim();
  if (!raw) return "";
  return fill(raw, character.name, user);
}
