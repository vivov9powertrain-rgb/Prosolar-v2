import type { Mode } from "./reasoning.ts";
import type { Attachment } from "./files.ts";
import type { Source } from "./protocol.ts";
export type Role = "system" | "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: Exclude<Role, "system">;
  content: string;
  attachments?: Attachment[];
  sources?: Source[];
  webLookup?: "tavily" | "skipped" | "no-sources" | "openrouter";
  webQuery?: string;
};

export type Character = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  personality: string;
  scenario: string;
  firstMessage: string;
  example: string;
  extra: string;
  hue: number;
};

export type ChatThread = {
  id: string;
  characterId: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: number;
};

export type ProviderId =
  | "openai"
  | "openrouter"
  | "google"
  | "groq"
  | "together"
  | "xai"
  | "deepseek"
  | "nvidia"
  | "zai"
  | "custom";

export type Settings = {
  provider: ProviderId;
  transport: "auto" | "browser" | "relay";
  baseUrl: string;
  apiKey: string;
  model: string;
  temperature: number;
  maxTokens: number;
  streaming: boolean;
  highReasoning: boolean;
  reasoningModes: Record<string, Mode>;
  webSearch: boolean;
  routerAllowSites: string;
  routerBlockSites: string;
  userName: string;
  userPersona: string;
};

export const PROVIDERS: {
  id: ProviderId;
  label: string;
  baseUrl: string;
  modelHint: string;
  publicModels?: boolean;
  preferRelay?: boolean;
}[] = [
  {
    id: "openai",
    label: "OpenAI",
    baseUrl: "https://api.openai.com/v1",
    modelHint: "gpt-4o-mini",
  },
  {
    id: "openrouter",
    label: "OpenRouter",
    baseUrl: "https://openrouter.ai/api/v1",
    modelHint: "openai/gpt-5.4-mini",
    publicModels: true,
  },
  {
    id: "google",
    label: "Google Gemini (AI Studio)",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    modelHint: "",
    preferRelay: true,
  },
  {
    id: "groq",
    label: "Groq",
    baseUrl: "https://api.groq.com/openai/v1",
    modelHint: "llama-3.3-70b-versatile",
  },
  {
    id: "together",
    label: "Together",
    baseUrl: "https://api.together.xyz/v1",
    modelHint: "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
  },
  {
    id: "xai",
    label: "xAI",
    baseUrl: "https://api.x.ai/v1",
    modelHint: "grok-3",
  },
  {
    id: "deepseek",
    label: "DeepSeek",
    baseUrl: "https://api.deepseek.com/v1",
    modelHint: "deepseek-chat",
  },
  {
    id: "nvidia",
    label: "NVIDIA",
    baseUrl: "https://integrate.api.nvidia.com/v1",
    modelHint: "google/gemma-3-12b-it",
    publicModels: true,
    preferRelay: true,
  },
  {
    id: "zai",
    label: "Z.ai",
    baseUrl: "https://api.z.ai/api/paas/v4",
    modelHint: "glm-5.3",
    preferRelay: true,
  },
  {
    id: "custom",
    label: "Custom",
    baseUrl: "https://",
    modelHint: "model-id",
  },
];

export const DEFAULT_SETTINGS: Settings = {
  provider: "openrouter",
  transport: "auto",
  baseUrl: "https://openrouter.ai/api/v1",
  apiKey: "",
  model: "openai/gpt-5.4-mini",
  temperature: 0.9,
  maxTokens: 900,
  streaming: true,
  highReasoning: false,
  reasoningModes: {},
  webSearch: false,
  routerAllowSites: "",
  routerBlockSites: "",
  userName: "You",
  userPersona: "",
};
