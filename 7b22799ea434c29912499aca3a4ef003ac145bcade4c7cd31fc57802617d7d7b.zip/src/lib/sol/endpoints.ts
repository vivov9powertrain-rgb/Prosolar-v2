import { PROVIDERS } from "./types.ts";
export function hasControlChars(text: string) {
  for (let i = 0; i < text.length; i++) {
    const n = text.charCodeAt(i);
    if (n < 32 || n === 127) return true;
  }
  return false;
}
/** A base and its full chat URL describe the same API. Never redirect keys. */
export function apiBase(raw: string): string {
  const text = raw.trim();
  if (text.length > 2048 || text.includes("\\") || hasControlChars(text))
    throw Error("Invalid API URL.");
  let url: URL;
  try {
    url = new URL(text);
  } catch {
    throw Error("Enter a complete HTTP(S) base URL or chat/completions URL.");
  }
  if (
    !["https:", "http:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.hash ||
    url.search ||
    /[?#]/.test(text)
  )
    throw Error("Use an HTTP(S) API URL without embedded credentials, a query, or a fragment.");
  const path = url.pathname
    .replace(/\/+$/, "")
    .replace(/\/(?:chat\/completions|models)$/, "")
    .replace(/\/+$/, "");
  return url.origin + path;
}
export function canonicalOrEmpty(raw: string) {
  try {
    return apiBase(raw);
  } catch {
    return "";
  }
}
export function providerAt(raw: string) {
  const base = canonicalOrEmpty(raw);
  return PROVIDERS.find((p) => p.id !== "custom" && p.baseUrl === base);
}
export function sameApi(a: string, b: string) {
  try {
    return apiBase(a) === apiBase(b);
  } catch {
    return false;
  }
}
export function endpoint(raw: string, resource: "chat/completions" | "models") {
  return `${apiBase(raw)}/${resource}`;
}
/** Shape check only; the server independently checks and pins the DNS address. */
export function relayEligible(base: string) {
  try {
    const u = new URL(apiBase(base)),
      h = u.hostname;
    return (
      u.protocol === "https:" &&
      !u.port &&
      h.includes(".") &&
      h.length <= 253 &&
      h.split(".").every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label)) &&
      !/^\d+(?:\.\d+){3}$/.test(h) &&
      !/\.(?:localhost|local|lan|internal|localdomain|home|arpa|test|invalid|onion|example)$/i.test(
        h,
      ) &&
      /^(?:\/[a-z0-9._~-]+)*\/?$/i.test(u.pathname)
    );
  } catch {
    return false;
  }
}
