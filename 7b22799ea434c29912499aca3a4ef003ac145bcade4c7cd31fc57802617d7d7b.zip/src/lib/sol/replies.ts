import { safeLink, type Source } from "./protocol.ts";
type Chunk = {
  content?: unknown;
  annotations?: unknown;
  reasoning?: unknown;
  reasoning_content?: unknown;
};
type Packet = {
  error?: { message?: string } | string;
  choices?: {
    delta?: Chunk;
    message?: Chunk;
    text?: string;
    finish_reason?: string;
    error?: { message?: string };
  }[];
};
export type ReplyHandlers = {
  onDelta: (s: string) => void;
  onSources?: (s: Source[]) => void;
  onThinking?: () => void;
};
export function errorText(body: string, status: number) {
  try {
    const j = JSON.parse(body);
    const msg = typeof j.error === "string" ? j.error : (j.error?.message ?? j.message);
    if (typeof msg === "string") return msg.slice(0, 600);
  } catch {
    /* plain text error */
  }
  return /^\s*[<{]/.test(body)
    ? `The provider returned an unexpected response (${status}).`
    : body.trim().slice(0, 280) || `Request failed (${status}).`;
}
export async function readReply(response: Response, handlers: ReplyHandlers) {
  const sources = new Map<string, Source>();
  let end = "",
    visible = false;
  function consume(packet: Packet) {
    if (packet.error)
      throw Error(
        typeof packet.error === "string"
          ? packet.error
          : packet.error.message || "The provider reported an error.",
      );
    const c = packet.choices?.[0];
    if (!c) return;
    if (c.error || c.finish_reason === "error")
      throw Error(c.error?.message || "The provider stopped with an error.");
    const value = c.delta?.content ?? c.message?.content ?? c.text;
    const text =
      typeof value === "string"
        ? value
        : Array.isArray(value)
          ? value
              .filter((v) => v?.type === "text" && typeof v.text === "string")
              .map((v) => v.text)
              .join("")
          : "";
    if (text) {
      handlers.onDelta(text);
      visible ||= !!text.trim();
    } else if (
      c.delta?.reasoning ||
      c.message?.reasoning ||
      c.delta?.reasoning_content ||
      c.message?.reasoning_content
    )
      handlers.onThinking?.();
    let changed = false;
    for (const group of [c.delta?.annotations, c.message?.annotations])
      if (Array.isArray(group))
        for (const a of group) {
          if (a?.type !== "url_citation") continue;
          const url = safeLink(a.url_citation?.url);
          if (!url) continue;
          const start = a.url_citation.start_index,
            end = a.url_citation.end_index;
          const span =
            Number.isSafeInteger(start) &&
            Number.isSafeInteger(end) &&
            start >= 0 &&
            end > start &&
            end <= 1_000_000
              ? { startIndex: start, endIndex: end }
              : undefined;
          const old = sources.get(url);
          if (old) {
            if (span && old.startIndex === undefined) {
              sources.set(url, { ...old, ...span });
              changed = true;
            }
            continue;
          }
          if (sources.size >= 20) continue;
          sources.set(url, {
            url,
            title:
              typeof a.url_citation.title === "string" && a.url_citation.title.trim()
                ? a.url_citation.title.trim().slice(0, 240)
                : new URL(url).hostname,
            ...span,
          });
          changed = true;
        }
    if (changed) handlers.onSources?.([...sources.values()]);
    if (c.finish_reason) end = c.finish_reason;
  }
  if (response.headers.get("content-type")?.includes("text/event-stream") && response.body) {
    const reader = response.body.getReader(),
      decoder = new TextDecoder();
    let buf = "",
      data: string[] = [],
      done = false;
    function flush() {
      if (!data.length) return;
      const raw = data.join("\n").trim();
      data = [];
      if (raw === "[DONE]") {
        done = true;
        return;
      }
      if (!raw) return;
      let entry: Packet;
      try {
        entry = JSON.parse(raw);
      } catch {
        throw Error("The provider sent an unreadable streaming event. Try turning Streaming off.");
      }
      consume(entry);
    }
    function line(s: string) {
      s = s.replace(/\r$/, "");
      if (!s) flush();
      else if (s.startsWith("data:")) data.push(s.slice(5).replace(/^ /, ""));
    }
    try {
      while (!done) {
        const r = await reader.read();
        buf += r.done ? decoder.decode() : decoder.decode(r.value, { stream: true });
        let i;
        while (!done && (i = buf.indexOf("\n")) >= 0) {
          line(buf.slice(0, i));
          buf = buf.slice(i + 1);
        }
        if (r.done) {
          if (!done && buf) line(buf);
          if (!done) flush();
          break;
        }
      }
    } finally {
      try {
        await reader.cancel();
      } catch {
        /* aborted */
      }
      reader.releaseLock();
    }
    if (!done && !end)
      throw Error("The stream ended before the model finished. Any partial reply was kept.");
  } else {
    const raw = await response.text();
    let json: Packet;
    try {
      json = JSON.parse(raw);
    } catch {
      throw Error(errorText(raw, response.status));
    }
    consume(json);
  }
  if (end === "length")
    throw Error(
      "The output-token limit was reached. Increase Max tokens in Connection or turn off High reasoning, then retry.",
    );
  if (!visible)
    throw Error(
      end === "content_filter"
        ? "The provider filtered this reply."
        : "No answer text was returned. Check the model and token budget.",
    );
}

// Filter model-prefixed reasoning, including unfinished streaming blocks. Do not
// rewrite literal <think> in fenced code or destroy indentation used by Markdown.
export function stripHidden(text: string) {
  return text
    .replace(/^(?:\s*<think>[\s\S]*?(?:<\/think>|$)\s*)+/i, "")
    .replace(/^\s*<t(?:h(?:i(?:n(?:k)?)?)?)?$/i, "");
}

/** Offsets from an annotated provider refer to its original text, before a leading hidden block is stripped. */
export function visibleOffsets(sources: Source[], prefixLength: number): Source[] {
  if (!prefixLength) return sources;
  return sources.map((s) => {
    const { startIndex, endIndex, ...base } = s;
    return startIndex !== undefined && endIndex !== undefined && startIndex >= prefixLength
      ? { ...base, startIndex: startIndex - prefixLength, endIndex: endIndex - prefixLength }
      : base;
  });
}
