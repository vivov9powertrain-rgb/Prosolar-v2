import type { Part } from "./protocol.ts";
export type Attachment = {
  id: string;
  name: string;
  size: number;
  kind: "text" | "image" | "pdf";
  mime: string;
};
export type DraftFile = { ref: Attachment; blob: Blob };
export const ACCEPT = ".txt,.md,.csv,.tsv,.json,.log,.pdf,.png,.jpg,.jpeg,.webp";
const LIMIT = 2 * 1024 * 1024;
const formats: Record<string, string> = {
  pdf: "application/pdf",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
};
export async function prepareFiles(
  files: File[],
  prior: DraftFile[],
  router: boolean,
): Promise<DraftFile[]> {
  if (files.length + prior.length > 3) throw Error("Attach up to 3 files per message.");
  if ([...files, ...prior.map((f) => f.blob)].reduce((s, f) => s + f.size, 0) > LIMIT)
    throw Error("Attachments must total 2 MiB or less per message.");
  return Promise.all(
    files.map(async (file) => {
      const name = file.name.slice(0, 240),
        ext = name.toLowerCase().split(".").pop() || "";
      if (!ACCEPT.split(",").includes("." + ext))
        throw Error(
          `Unsupported file: ${name}. Choose text, Markdown, CSV, TSV, JSON, log, PDF, PNG, JPEG or WebP.`,
        );
      if (!file.size) throw Error(`${name} is empty.`);
      const mime = formats[ext] || "text/plain",
        kind = mime === "application/pdf" ? "pdf" : mime.startsWith("image/") ? "image" : "text";
      if (kind === "pdf" && !router) throw Error("Select OpenRouter in Connection to attach PDFs.");
      if (kind === "text") {
        if (file.size > 128 * 1024) throw Error("Text files must be 128 KiB or smaller.");
        try {
          if (
            new TextDecoder("utf-8", { fatal: true })
              .decode(await file.arrayBuffer())
              .includes("\0")
          )
            throw Error();
        } catch {
          throw Error(`${name} is not a UTF-8 text file.`);
        }
      } else {
        const a = new Uint8Array(await file.slice(0, 16).arrayBuffer()),
          sig = String.fromCharCode(...a);
        const ok =
          kind === "pdf"
            ? sig.startsWith("%PDF-")
            : mime === "image/png"
              ? sig.startsWith("\x89PNG\r\n\x1a\n")
              : mime === "image/jpeg"
                ? a[0] === 255 && a[1] === 216 && a[2] === 255
                : sig.startsWith("RIFF") && sig.slice(8, 12) === "WEBP";
        if (!ok) throw Error(`${name} does not match its file type.`);
      }
      return {
        ref: { id: crypto.randomUUID(), name, size: file.size, kind, mime },
        blob: file.slice(0, file.size, mime),
      };
    }),
  );
}
// Keep large file bodies out of the original localStorage-backed chat store.
function database(): Promise<IDBDatabase> {
  return new Promise((ok, fail) => {
    const r = indexedDB.open("hearth-attachments", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("blobs");
    r.onsuccess = () => ok(r.result);
    r.onerror = () => fail(r.error);
  });
}
async function tx(mode: IDBTransactionMode, work: (s: IDBObjectStore) => void) {
  const db = await database();
  try {
    await new Promise<void>((ok, fail) => {
      const t = db.transaction("blobs", mode);
      t.oncomplete = () => ok();
      t.onabort = t.onerror = () => fail(t.error || Error("Attachment storage unavailable."));
      work(t.objectStore("blobs"));
    });
  } finally {
    db.close();
  }
}
export async function saveFiles(files: DraftFile[]) {
  if (files.length)
    try {
      await tx("readwrite", (s) => files.forEach((f) => s.put(f.blob, f.ref.id)));
    } catch {
      throw Error(
        "Could not save these files in this browser. Free some device storage or send without attachments.",
      );
    }
}
export async function forgetFiles(ids: string[]) {
  if (ids.length) await tx("readwrite", (s) => ids.forEach((id) => s.delete(id)));
}
async function readBlob(ref: Attachment) {
  let blob: Blob | undefined;
  await tx("readonly", (s) => {
    const r = s.get(ref.id);
    r.onsuccess = () => {
      blob = r.result as Blob | undefined;
    };
  });
  if (!blob)
    throw Error(
      `“${ref.name}” is no longer stored on this device. Start a new chat and reattach the file.`,
    );
  return blob;
}
export async function filePart(ref: Attachment): Promise<Part> {
  const blob = await readBlob(ref);
  if (ref.kind === "text")
    return { type: "text", text: `Attachment: ${ref.name}\n\n${await blob.text()}` };
  const data = await new Promise<string>((ok, fail) => {
    const r = new FileReader();
    r.onload = () => ok(String(r.result));
    r.onerror = () => fail(Error(`Could not read ${ref.name}.`));
    r.readAsDataURL(blob);
  });
  return ref.kind === "image"
    ? { type: "image_url", image_url: { url: data } }
    : { type: "file", file: { filename: ref.name, file_data: data } };
}
