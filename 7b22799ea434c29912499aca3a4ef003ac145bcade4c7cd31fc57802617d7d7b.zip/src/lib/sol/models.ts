import { hasControlChars, providerAt } from "./endpoints.ts";

/** OpenAI-compatible model lists, as returned by OpenRouter, Google AI Studio and NVIDIA. */
export function parseCatalog(base: string, json: unknown): { listed: boolean; ids: string[] } {
  const data = (json as { data?: unknown } | null)?.data;
  if (!Array.isArray(data)) return { listed: false, ids: [] };
  const google = providerAt(base)?.id === "google";
  const ids = new Set<string>();
  for (const row of data) {
    if (typeof row?.id !== "string") continue;
    // Some Gemini lists return Google resource names; chat accepts their short model ID.
    const raw = row.id.trim(),
      id = google ? raw.replace(/^models\//, "") : raw;
    if (!id || id.length > 1024 || hasControlChars(id)) continue;
    if (
      Array.isArray(row.architecture?.output_modalities) &&
      !row.architecture.output_modalities.includes("text")
    )
      continue;
    ids.add(id);
  }
  return { listed: true, ids: [...ids] };
}
export function defaultFromCatalog(base: string, current: string, ids: string[]): string {
  if (!ids.length) return current;
  if (ids.includes(current)) return current;
  const preset = providerAt(base);
  if (preset?.modelHint && ids.includes(preset.modelHint)) return preset.modelHint;
  if (preset?.id === "google") {
    const flashes = ids.filter((id) => /^gemini-\d+(?:\.\d+)*-flash(?:-lite)?$/.test(id));
    const flash =
      flashes
        .sort((a, b) => b.localeCompare(a, "en", { numeric: true }))
        .find((id) => id.endsWith("-flash")) || flashes[0];
    if (flash) return flash;
    const chat = ids.find(
      (id) => id.startsWith("gemini-") && !/embed|\b(?:tts|image|audio|live|robotics)\b/i.test(id),
    );
    if (chat) return chat;
  }
  if (preset?.id === "openrouter" && ids.includes("openrouter/free")) return "openrouter/free";
  return ids[0];
}
