/** Domain lists belong to the user, never the planner. A block wins over an allow. */
export type SiteRules = { allow: string[]; block: string[] };
export const NO_SITES: SiteRules = { allow: [], block: [] };
const matchesDomain = (host: string, domain: string) =>
  host === domain || host.endsWith("." + domain);
export function domainList(raw: unknown): string[] {
  if (raw == null || raw === "") return [];
  if (typeof raw !== "string" && !(Array.isArray(raw) && raw.every((v) => typeof v === "string")))
    throw Error("Use domain names separated by commas.");
  const text = Array.isArray(raw) ? raw.join(",") : (raw as string);
  if (text.length > 1200) throw Error("Use at most 12 domains per list.");
  const domains = new Set<string>();
  for (const token of text
    .toLowerCase()
    .split(/[\s,;]+/)
    .filter(Boolean)) {
    const d = token.replace(/^\*\./, "").replace(/\.$/, "");
    if (
      !/^(?=.{3,253}$)(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z](?:[a-z0-9-]*[a-z0-9])?$/.test(
        d,
      ) ||
      d.split(".").some((l) => l.length > 63)
    )
      throw Error("Enter a domain such as docs.python.org, without a URL, path or port.");
    domains.add(d);
  }
  if (domains.size > 12) throw Error("Use at most 12 domains per list.");
  return [...domains];
}
export function siteRules(allow?: unknown, block?: unknown): SiteRules {
  const a = domainList(allow),
    b = domainList(block);
  if (a.length && a.every((d) => b.some((x) => matchesDomain(d, x))))
    throw Error("All trusted sites are blocked. Change the site lists before searching.");
  return { allow: a, block: b };
}
const opaqueDomains = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "rebrand.ly"];
const adultHost = /(?:^|\.)(?:pornhub|xvideos|xnxx|xhamster)\.|\.xxx$/i;
/** Validate a returned web destination and remove incidental tracking, not meaningful parameters or anchors. Never fetch it. */
export function sourceUrl(raw: unknown, rules: SiteRules = NO_SITES): string | undefined {
  if (typeof raw !== "string" || raw.length > 2048) return;
  try {
    const u = new URL(raw),
      h = u.hostname.toLowerCase().replace(/\.$/, "");
    if (
      !["https:", "http:"].includes(u.protocol) ||
      u.username ||
      u.password ||
      !h.includes(".") ||
      /(?:\.local(?:host)?|\.internal|\.test|\.invalid)$/.test(h) ||
      /^\d+[.\d]*$/.test(h) ||
      adultHost.test(h) ||
      opaqueDomains.some((d) => matchesDomain(h, d))
    )
      return;
    if (
      rules.block.some((d) => matchesDomain(h, d)) ||
      (rules.allow.length && !rules.allow.some((d) => matchesDomain(h, d)))
    )
      return;
    for (const k of [...u.searchParams.keys()])
      if (/^utm_|^(?:fbclid|gclid|msclkid|mc_eid|mc_cid)$/i.test(k)) u.searchParams.delete(k);
    return u.href;
  } catch {
    return;
  }
}
export function sourceIdentity(raw: unknown): string | undefined {
  const url = sourceUrl(raw);
  return url?.split("#")[0];
}

export const badLanding =
  /^(?:sign in|log in|access denied|just a moment|page not found|buy this domain)(?:\s*[|–—:-]|$)|\b(?:domain (?:is )?for sale|claim your casino bonus|free spins no deposit|watch free (?:porn|xxx)|free porn videos)\b/i;
