import { searchConfig, type SearchConfig } from "./search-settings.ts";
import { restoreProviders, type SavedProviders } from "./custom-providers.ts";
import { canonicalOrEmpty, hasControlChars, providerAt } from "./endpoints.ts";
import { DEFAULT_SETTINGS, type Settings } from "./types.ts";

// Device state, never an API payload. Endpoint identity includes scheme, host, port and API path.
export type Connection = { apiKey?: string; model?: string; pinned?: boolean };
export type ConnectionBook = Record<string, Connection>;
export type Device = {
  search: SearchConfig;
  customProviders: SavedProviders;
  settings: Settings;
  connections: ConnectionBook;
  rememberKeys: boolean;
  lastCustomBase: string;
};
export type SavedDevice = {
  search?: Partial<SearchConfig>;
  customProviders?: SavedProviders;
  settings?: Partial<Settings>;
  connections?: ConnectionBook;
  rememberKeys?: boolean;
  lastCustomBase?: string;
};
export type SettingsPatch = Partial<Omit<Settings, "provider" | "baseUrl">>;
const cleanKey = (v: unknown) =>
  typeof v === "string" && v.length <= 8192 && !hasControlChars(v) ? v : "";
const cleanModel = (v: unknown) =>
  typeof v === "string" && v.length <= 1024 && !hasControlChars(v) ? v : "";

/** Hydrate new records or import the one active key a pre-upgrade release stored. */
export function restoreDevice(saved: SavedDevice = {}): Device {
  const settings = { ...DEFAULT_SETTINGS, ...saved.settings };
  for (const k of ["routerAllowSites", "routerBlockSites"] as const)
    settings[k] = typeof settings[k] === "string" ? settings[k].slice(0, 1200) : "";
  const baseUrl = canonicalOrEmpty(typeof settings.baseUrl === "string" ? settings.baseUrl : "");
  const provider = providerAt(baseUrl);
  const rememberKeys = saved.rememberKeys !== false;
  const connections: ConnectionBook = {};
  for (const [raw, item] of Object.entries(saved.connections ?? {})) {
    const base = canonicalOrEmpty(raw);
    if (!base || !item || typeof item !== "object") continue;
    const model = cleanModel(item.model),
      apiKey = rememberKeys && cleanKey(item.apiKey);
    if (model || apiKey)
      connections[base] = {
        ...(model ? { model, pinned: item.pinned === true } : {}),
        ...(apiKey ? { apiKey } : {}),
      };
  }
  // Never guess an endpoint for an old key, or resurrect keys erased from the new book.
  if (!saved.connections && baseUrl && typeof saved.settings?.baseUrl === "string") {
    const model = cleanModel(saved.settings.model),
      apiKey = rememberKeys && cleanKey(saved.settings.apiKey);
    if (apiKey || model)
      connections[baseUrl] = {
        ...(apiKey ? { apiKey } : {}),
        ...(model ? { model, pinned: model !== provider?.modelHint } : {}),
      };
  }
  const row = connections[baseUrl];
  const last = canonicalOrEmpty(
    typeof saved.lastCustomBase === "string" ? saved.lastCustomBase : "",
  );
  return {
    connections,
    search: searchConfig(saved.search, rememberKeys),
    customProviders: restoreProviders(saved.customProviders),
    rememberKeys,
    lastCustomBase: !provider && baseUrl ? baseUrl : providerAt(last) ? "" : last,
    settings: {
      ...settings,
      baseUrl,
      provider: provider?.id ?? "custom",
      apiKey: row?.apiKey ?? "",
      model: baseUrl
        ? (row?.model ??
          (typeof saved.settings?.model === "string"
            ? cleanModel(saved.settings.model)
            : (provider?.modelHint ?? "")))
        : "",
    },
  };
}

/** One copy per endpoint on disk; turning off persistence removes ALL keys from the disk snapshot. */
export function deviceForDisk(s: Device): SavedDevice {
  const { apiKey: _activeKey, ...settings } = s.settings;
  const connections: ConnectionBook = {};
  for (const [base, row] of Object.entries(s.connections)) {
    if (!row.model && !(s.rememberKeys && row.apiKey)) continue;
    connections[base] = {
      ...(row.model ? { model: row.model, pinned: !!row.pinned } : {}),
      ...(s.rememberKeys && row.apiKey ? { apiKey: row.apiKey } : {}),
    };
  }
  const { apiKey: searchKey, ...prefs } = s.search;
  return {
    search: { ...prefs, ...(s.rememberKeys && searchKey ? { apiKey: searchKey } : {}) },
    customProviders: s.customProviders,
    settings,
    connections,
    rememberKeys: s.rememberKeys,
    lastCustomBase: s.lastCustomBase,
  };
}

export function switchEndpoint(s: Device, raw: string) {
  const baseUrl = canonicalOrEmpty(raw),
    preset = providerAt(baseUrl),
    row = s.connections[baseUrl];
  if (baseUrl === s.settings.baseUrl)
    return { settings: s.settings, lastCustomBase: s.lastCustomBase };
  return {
    settings: {
      ...s.settings,
      baseUrl,
      provider: preset?.id ?? ("custom" as const),
      apiKey: row?.apiKey ?? "",
      model: row?.model ?? preset?.modelHint ?? "",
    },
    lastCustomBase: baseUrl && !preset ? baseUrl : s.lastCustomBase,
  };
}
export function changeSettings(s: Device, patch: SettingsPatch, suggested = false) {
  const settings = { ...s.settings, ...patch };
  const base = s.settings.baseUrl;
  if (patch.apiKey === undefined && patch.model === undefined)
    return { settings, connections: s.connections };
  if (!base)
    return { settings: { ...settings, apiKey: "", model: "" }, connections: s.connections };
  const row = { ...s.connections[base] };
  if (patch.apiKey !== undefined) {
    settings.apiKey = cleanKey(patch.apiKey);
    if (settings.apiKey) row.apiKey = settings.apiKey;
    else delete row.apiKey;
  }
  if (patch.model !== undefined) {
    settings.model = cleanModel(patch.model);
    if (settings.model) {
      row.model = settings.model;
      row.pinned = !suggested;
    } else {
      delete row.model;
      delete row.pinned;
    }
  }
  const connections = { ...s.connections };
  if (row.model || row.apiKey) connections[base] = row;
  else delete connections[base];
  return { settings, connections };
}
