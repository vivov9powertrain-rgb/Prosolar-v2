import { createFileRoute } from "@tanstack/react-router";
import { SolApp } from "@/components/sol-app";

export const Route = createFileRoute("/")({
  component: SolApp,
});
