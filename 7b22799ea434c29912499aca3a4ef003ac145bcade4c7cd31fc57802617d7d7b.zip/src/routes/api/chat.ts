import { createFileRoute } from "@tanstack/react-router";
import { relayChat } from "@/lib/sol/relay";
export const Route = createFileRoute("/api/chat")({
  server: { handlers: { POST: ({ request }) => relayChat(request) } },
});
