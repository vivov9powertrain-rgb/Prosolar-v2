import { createFileRoute } from "@tanstack/react-router";
import { searchRelay } from "@/lib/sol/search-relay.server";
export const Route = createFileRoute("/api/search")({
  server: { handlers: { POST: ({ request }) => searchRelay(request) } },
});
