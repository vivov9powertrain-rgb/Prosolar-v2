import { siteRules, sourceUrl, badLanding } from "@/lib/sol/source-policy";
import { useEffect, useRef, useState } from "react";
import { Pencil, RefreshCw, Send, Square } from "lucide-react";
import { Sources } from "./source-links";
import { ChatTools, Files } from "./chat-tools";
import { stripHidden, visibleOffsets } from "@/lib/sol/replies";
import { RichText } from "./rich-text";
import { prepareLookup } from "@/lib/sol/grounding";
import { available, getBudget } from "@/lib/sol/search-budget";
import { streamCompletion } from "@/lib/sol/complete";
import { toApiMessages } from "@/lib/sol/prompt";
import { saveFiles, type DraftFile } from "@/lib/sol/files";
import { isRouter, type Source } from "@/lib/sol/protocol";
import { useSol } from "@/lib/sol/store";
import type { Character, ChatMessage } from "@/lib/sol/types";

type Props = {
  character: Character;
  messages: ChatMessage[];
  threadId: string;
  hasKey: boolean;
  onNeedKey: () => void;
  onSearchSettings: () => void;
};
export function ChatPane({
  character,
  messages,
  threadId,
  hasKey,
  onNeedKey,
  onSearchSettings,
}: Props) {
  const settings = useSol((s) => s.settings);
  const [text, setText] = useState(""),
    [live, setLive] = useState(""),
    [error, setError] = useState(""),
    [status, setStatus] = useState("");
  const [files, setFiles] = useState<DraftFile[]>([]),
    [sources, setSources] = useState<Source[]>([]),
    [reading, setReading] = useState(false);
  const [lookupKind, setLookupKind] = useState<ChatMessage["webLookup"]>();
  const [edit, setEdit] = useState<{ id: string; text: string } | null>(null);
  const ctrl = useRef<AbortController | null>(null),
    scroll = useRef<HTMLDivElement>(null),
    stick = useRef(true);
  const busy = !!status;
  useEffect(() => () => ctrl.current?.abort(), []);
  useEffect(() => {
    if (stick.current && scroll.current) scroll.current.scrollTop = scroll.current.scrollHeight;
  }, [messages, live, status, error]);
  async function run(history: ChatMessage[], opts: { draft?: ChatMessage; replace?: string } = {}) {
    if (ctrl.current || reading) return;
    if (!hasKey) {
      onNeedKey();
      return;
    }
    const c = new AbortController();
    ctrl.current = c;
    setLookupKind(undefined);
    setEdit(null);
    setError("");
    setLive("");
    setSources([]);
    stick.current = true;
    setStatus("Preparing message…");
    let acc = "",
      refs: Source[] = [];
    const store = useSol.getState();
    let kind: ChatMessage["webLookup"], query: string | undefined;
    const question = history.filter((m) => m.role === "user").at(-1)?.content ?? "";
    const routerWeb =
      isRouter(settings.baseUrl) &&
      (settings.webSearch || settings.model.split(":").includes("online"));
    try {
      const nativeSites = routerWeb
        ? siteRules(settings.routerAllowSites, settings.routerBlockSites)
        : undefined;
      if (!isRouter(settings.baseUrl) && store.search.enabled) {
        if (!store.search.apiKey.trim())
          throw Error("Add a Tavily key in Web search settings or turn search off.");
        if (!question.trim())
          throw Error(
            "Add a written search question or turn off web search for this attachment-only message.",
          );
        available(getBudget(threadId));
      }
      if (opts.draft) {
        await saveFiles(files);
        store.appendMessage(threadId, opts.draft);
        setText("");
        setFiles([]);
      }
      // Old Tavily records held every hit, including uncited rows. Rebuild their citation map for model context without rewriting the saved chat.
      let context = history;
      if (
        history.some((m) => m.webLookup === "tavily" && m.sources?.some((s) => s.id === undefined))
      ) {
        const { messageHtml } = await import("./markdown-engine");
        context = history.map((m) =>
          m.webLookup === "tavily" && m.sources?.some((s) => s.id === undefined)
            ? { ...m, sources: messageHtml(stripHidden(m.content), m.sources).cited }
            : m,
        );
      }
      const messages = await toApiMessages(character, settings, context);
      const lookup = await prepareLookup(
        settings,
        store.search,
        threadId,
        question,
        messages,
        c.signal,
        setStatus,
        undefined,
        history.at(-2)?.role === "assistant" ? history.at(-2)?.webQuery : undefined,
      );
      kind = routerWeb ? "openrouter" : lookup.kind;
      query = lookup.query;
      setLookupKind(kind);
      if (kind === "no-sources") {
        acc =
          "I couldn’t find a source that matched this search closely enough to cite. Try adding a name, location or version, or check your trusted and blocked sites.";
        return; // Local, persistent abstention. No ungrounded model reply and no automatic second lookup.
      }
      refs = lookup.hits.map(({ url, title }, i) => ({ url, title, id: i + 1 }));
      setSources(refs);
      let wire = lookup.wire;
      if (routerWeb) {
        const policy =
          "Cite web findings using only exact URLs returned by OpenRouter that directly support the claim. Do not list tangential results. If none answers the question, say what you could not verify. Do not invent or guess links.";
        wire =
          wire[0]?.role === "system"
            ? [
                { role: "system", content: String(wire[0].content) + "\n\n" + policy },
                ...wire.slice(1),
              ]
            : [{ role: "system", content: policy }, ...wire];
      }
      c.signal.throwIfAborted();
      setStatus(
        kind === "tavily"
          ? `Checking ${refs.length} search excerpt${refs.length === 1 ? "" : "s"}…`
          : kind === "skipped"
            ? "No lookup needed · waiting for the model…"
            : isRouter(settings.baseUrl) && settings.highReasoning
              ? "Waiting for the reasoning model…"
              : settings.streaming
                ? "Waiting for the first token…"
                : "Waiting for the full reply…",
      );
      await streamCompletion(settings, wire, c.signal, {
        onDelta: (s) => {
          acc += s;
          setLive(acc);
        },
        onSources: (list) => {
          if (kind !== "tavily") {
            refs = nativeSites
              ? list.flatMap((s) => {
                  const url = sourceUrl(s.url, nativeSites);
                  return url && !badLanding.test(s.title) ? [{ ...s, url }] : [];
                })
              : list;
            setSources(refs);
          }
        },
        onThinking: () => setStatus("Model is reasoning…"),
      });
      if (!stripHidden(acc).trim())
        throw Error(
          "The model returned no visible answer. Raise Max tokens or choose a lower reasoning level.",
        );
    } catch (e) {
      if (!c.signal.aborted)
        setError(e instanceof Error ? e.message : "Could not send this message.");
    } finally {
      if (stripHidden(acc).trim()) {
        if (kind === "tavily" || kind === "openrouter") {
          // Only actual rendered citations travel forward in chat history. No snippets or unused URLs on disk.
          try {
            const { messageHtml } = await import("./markdown-engine");
            const visible = stripHidden(acc),
              native = kind === "openrouter";
            refs = messageHtml(
              visible,
              native ? visibleOffsets(refs, acc.length - visible.length) : refs,
              native,
            ).cited;
          } catch {
            refs = [];
          }
        }
        if (
          opts.replace &&
          useSol
            .getState()
            .threads.find((t) => t.id === threadId)
            ?.messages.at(-1)?.id === opts.replace
        )
          store.popLastIfAssistant(threadId);
        store.appendMessage(threadId, {
          id: crypto.randomUUID(),
          role: "assistant",
          content: stripHidden(acc),
          ...(refs.length ? { sources: refs } : {}),
          ...(kind ? { webLookup: kind } : {}),
          ...(query ? { webQuery: query } : {}),
        });
      }
      ctrl.current = null;
      setStatus("");
      setLive("");
      setSources([]);
    }
  }
  function send() {
    const content = text.trim();
    if ((!content && !files.length) || busy || reading) return;
    const m: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content,
      ...(files.length ? { attachments: files.map((f) => f.ref) } : {}),
    };
    void run([...messages, m], { draft: m });
  }
  function retry() {
    const last = messages.at(-1);
    if (!last) return;
    const replace = last.role === "assistant";
    void run(replace ? messages.slice(0, -1) : messages, {
      replace: replace ? last.id : undefined,
    });
  }
  return (
    <>
      <div
        ref={scroll}
        onScroll={(e) => {
          const v = e.currentTarget;
          stick.current = v.scrollHeight - v.scrollTop - v.clientHeight < 100;
        }}
        className="min-h-0 flex-1 overflow-y-auto px-3 py-4 md:px-8"
      >
        <div className="mx-auto flex max-w-2xl flex-col gap-4">
          {!messages.length && !busy && (
            <div className="sol-welcome">
              <span aria-hidden="true" className="sol-orbit" />
              <h1>Start a conversation.</h1>
              {!hasKey ? (
                <button onClick={onNeedKey} type="button">
                  Connect your model →
                </button>
              ) : (
                <p>Write a message or attach a file.</p>
              )}
            </div>
          )}
          {!hasKey && messages.length > 0 && (
            <button type="button" className="tool-chip self-start" onClick={onNeedKey}>
              Connect your model →
            </button>
          )}
          {messages.map((m) => (
            <article key={m.id} className={"min-w-0 " + (m.role === "user" ? "pl-8" : "pr-6")}>
              <div className="mb-1 flex items-center gap-2 text-xs tracking-wide text-muted uppercase">
                <span>{m.role === "user" ? settings.userName || "You" : character.name}</span>
                <button
                  type="button"
                  aria-label="Edit message"
                  className="grid size-8 place-items-center"
                  disabled={busy}
                  onClick={() => setEdit(edit?.id === m.id ? null : { id: m.id, text: m.content })}
                >
                  <Pencil size={14} />
                </button>
              </div>
              {edit?.id === m.id ? (
                <div className="rounded-lg border border-border bg-surface p-3">
                  <textarea
                    aria-label="Edit message text"
                    className="w-full bg-transparent"
                    rows={5}
                    value={edit.text}
                    onChange={(e) => setEdit({ ...edit, text: e.target.value })}
                  />
                  <div className="tool-row">
                    {["Save", "Save and continue", "Cancel"].map((label) => (
                      <button
                        className="tool-chip"
                        key={label}
                        type="button"
                        onClick={() => {
                          if (label !== "Cancel") {
                            const s = useSol.getState();
                            s.updateMessage(threadId, m.id, edit.text);
                            if (label === "Save and continue") {
                              s.truncateAfter(threadId, m.id);
                              if (m.role === "user" && hasKey)
                                void run([
                                  ...messages.slice(0, messages.indexOf(m)),
                                  { ...m, content: edit.text },
                                ]);
                            }
                          }
                          setEdit(null);
                        }}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div
                  className={
                    "rounded-lg px-4 py-3 leading-relaxed " +
                    (m.role === "user" ? "bg-surface-2" : "bg-surface")
                  }
                >
                  <Files files={m.attachments || []} />
                  <RichText
                    text={m.content}
                    assistant={m.role === "assistant"}
                    webSources={
                      m.webLookup === "tavily" || m.webLookup === "openrouter"
                        ? (m.sources ?? [])
                        : undefined
                    }
                    nativeWeb={m.webLookup === "openrouter"}
                  />
                  {m.webLookup !== "tavily" && m.webLookup !== "openrouter" && (
                    <Sources sources={m.sources || []} />
                  )}
                  {m.webQuery && (
                    <details className="sol-query">
                      <summary>Tavily search query</summary>
                      <p>{m.webQuery}</p>
                    </details>
                  )}
                  {m.webLookup === "skipped" && (
                    <p className="tool-hint">The model skipped web search for this reply.</p>
                  )}
                </div>
              )}
            </article>
          ))}
          {busy && (
            <article className="pr-6">
              <p className="mb-1 text-xs tracking-wide text-muted uppercase">{character.name}</p>
              <div className="rounded-lg bg-surface px-4 py-3">
                {stripHidden(live).trim() ? (
                  <RichText
                    assistant
                    text={live}
                    pending
                    webSources={
                      lookupKind === "tavily" || lookupKind === "openrouter" ? sources : undefined
                    }
                    nativeWeb={lookupKind === "openrouter"}
                  />
                ) : (
                  <p role="status" className="text-sm text-muted">
                    {status}
                  </p>
                )}
                {lookupKind !== "tavily" && lookupKind !== "openrouter" && (
                  <Sources sources={sources} />
                )}
              </div>
            </article>
          )}
        </div>
      </div>
      <form
        className="border-t border-border px-3 py-3 md:px-8"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <div className="mx-auto max-w-2xl">
          {error && (
            <p className="chat-error" role="alert">
              {error}
            </p>
          )}
          <ChatTools
            settings={settings}
            threadId={threadId}
            openSearch={onSearchSettings}
            files={files}
            setFiles={setFiles}
            locked={busy}
            reading={reading}
            setReading={setReading}
            onError={setError}
          />
          <div className="flex items-end gap-2">
            <button
              type="button"
              className="grid size-11 shrink-0 place-items-center rounded-md border border-border text-muted"
              aria-label="Regenerate"
              title="Retry the last reply"
              disabled={busy || reading || !messages.some((m) => m.role === "user")}
              onClick={retry}
            >
              <RefreshCw size={16} />
            </button>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                  e.preventDefault();
                  send();
                }
              }}
              rows={2}
              aria-label="Message"
              placeholder={`Message ${character.name}`}
              className="min-w-0 min-h-11 flex-1 resize-none rounded-md border border-border bg-surface px-3 py-2 text-fg placeholder:text-muted"
            />
            {busy ? (
              <button
                type="button"
                className="grid size-11 shrink-0 place-items-center rounded-md bg-clay text-primary-fg"
                aria-label="Stop"
                onClick={() => ctrl.current?.abort()}
              >
                <Square size={16} />
              </button>
            ) : (
              <button
                type="submit"
                className="grid size-11 shrink-0 place-items-center rounded-md bg-primary text-primary-fg disabled:opacity-50"
                aria-label="Send"
                disabled={reading || (!text.trim() && !files.length)}
              >
                <Send size={16} />
              </button>
            )}
          </div>
        </div>
      </form>
    </>
  );
}
