import { ExternalLink } from "lucide-react";
import { safeLink, sourceNumber, type Source } from "@/lib/sol/protocol";
/** Native providers give their own annotations. For Tavily this receives only rendered, matched citations. */
export function Sources({ sources, grounded = false }: { sources: Source[]; grounded?: boolean }) {
  if (!sources.length) return null;
  return (
    <div className="sol-sources">
      <p>{grounded ? "Cited sources" : "Sources"}</p>
      <ol
        aria-label={grounded ? "Cited sources" : "Sources"}
        className={grounded ? "sol-cited" : undefined}
      >
        {sources.map((s, i) => {
          const url = safeLink(s.url);
          if (!url) return null;
          return (
            <li key={url}>
              <a href={url} target="_blank" rel="noopener noreferrer nofollow">
                {grounded ? `S${sourceNumber(s, i)} · ` : ""}
                {s.title || new URL(url).hostname}
                <ExternalLink size={12} />
              </a>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
