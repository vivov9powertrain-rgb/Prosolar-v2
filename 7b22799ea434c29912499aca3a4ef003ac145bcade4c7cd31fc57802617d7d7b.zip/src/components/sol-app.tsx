import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Download,
  History,
  MessageSquarePlus,
  Pencil,
  Plus,
  Settings,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { routeFor, testConnection } from "@/lib/sol/complete";
import { apiBase, canonicalOrEmpty, providerAt } from "@/lib/sol/endpoints";
import { SearchSettings, RouterSearchSettings, ProviderBookmark } from "./search-settings";
import { ModelPicker } from "./model-picker";
import { ChatPane } from "./chat-pane";
import { blankCharacter, exportCard, PLAIN, useSol } from "@/lib/sol/store";
import { PROVIDERS, type Character } from "@/lib/sol/types";

type Panel = "history" | "settings" | "editor" | "search" | null;
export function SolApp() {
  const [ready, setReady] = useState(false),
    [panel, setPanel] = useState<Panel>(null),
    [draft, setDraft] = useState<Character | null>(null);
  const s = useSol();
  const thread = s.threads.find((t) => t.id === s.activeThreadId),
    profile = s.characters.find((c) => c.id === thread?.characterId) ?? PLAIN;
  useEffect(() => {
    let alive = true;
    Promise.resolve(useSol.persist?.rehydrate()).finally(() => {
      if (alive) setReady(true);
    });
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (ready && !thread) {
      const state = useSol.getState();
      if (!state.threads.some((t) => t.id === state.activeThreadId)) state.newThread(PLAIN.id);
    }
  }, [ready, thread]);
  useEffect(() => {
    if (!panel) return;
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPanel(null);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [panel]);
  const edit = (c: Character) => {
    setDraft(c);
    setPanel("editor");
  };
  return (
    <main className="sol-frame">
      <header className="sol-header">
        <div className="sol-head-inner">
          <div className="sol-wordmark">
            <i aria-hidden="true" />
            sol
          </div>
          {profile.id !== PLAIN.id && <span className="sol-profile">{profile.name}</span>}
          <nav aria-label="Chat actions">
            <button
              aria-label="New chat"
              title="New chat"
              onClick={() => {
                s.newThread(profile.id);
                setPanel(null);
              }}
            >
              <MessageSquarePlus size={18} />
            </button>
            <button
              aria-label="Chat library"
              title="Chats and custom profiles"
              onClick={() => setPanel("history")}
            >
              <History size={18} />
            </button>
            <button
              aria-label="Connection settings"
              title="Connection settings"
              onClick={() => setPanel("settings")}
            >
              <Settings size={18} />
            </button>
          </nav>
        </div>
      </header>
      {ready && thread ? (
        <ChatPane
          key={thread.id}
          character={profile}
          messages={thread.messages}
          threadId={thread.id}
          hasKey={Boolean(s.settings.apiKey.trim() && s.settings.model.trim())}
          onNeedKey={() => setPanel("settings")}
          onSearchSettings={() => setPanel("search")}
        />
      ) : (
        <div className="grow" />
      )}
      {panel === "search" && (
        <Overlay title="Web search" onClose={() => setPanel(null)}>
          {s.settings.provider === "openrouter" ? (
            <RouterSearchSettings />
          ) : (
            <SearchSettings threadId={thread?.id ?? ""} />
          )}
        </Overlay>
      )}
      {panel === "history" && (
        <Overlay title="Library" onClose={() => setPanel(null)}>
          <div className="sol-library">
            <h3>Conversations</h3>
            <button
              className="sol-add"
              onClick={() => {
                s.newThread(PLAIN.id);
                setPanel(null);
              }}
            >
              <Plus size={15} /> New plain chat
            </button>
            <ul>
              {[...s.threads]
                .sort((a, b) => b.updatedAt - a.updatedAt)
                .map((t) => (
                  <li key={t.id}>
                    <button
                      aria-current={t.id === s.activeThreadId ? "page" : undefined}
                      onClick={() => {
                        s.setActiveThread(t.id);
                        setPanel(null);
                      }}
                    >
                      {t.title}
                    </button>
                    <button
                      aria-label={"Delete chat: " + t.title}
                      onClick={() => s.deleteThread(t.id)}
                    >
                      <Trash2 size={14} />
                    </button>
                  </li>
                ))}
            </ul>
            <h3>Custom profiles</h3>
            <button className="sol-add" onClick={() => edit(blankCharacter())}>
              <Plus size={15} /> Create or import a profile
            </button>
            <ul>
              {s.characters.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => {
                      s.openCharacter(c.id);
                      setPanel(null);
                    }}
                  >
                    {c.name}
                  </button>
                  <button aria-label={"Edit " + c.name} onClick={() => edit(c)}>
                    <Pencil size={14} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </Overlay>
      )}
      {panel === "settings" && (
        <Overlay title="Connection" onClose={() => setPanel(null)}>
          <SettingsForm />
        </Overlay>
      )}
      {panel === "editor" && draft && (
        <Overlay title={draft.name ? "Edit profile" : "New profile"} onClose={() => setPanel(null)}>
          <CharacterForm initial={draft} onDone={() => setPanel(null)} />
        </Overlay>
      )}
    </main>
  );
}

function Overlay({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div
      className="fixed inset-0 z-20 flex justify-end bg-bg/70"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="flex h-full w-full max-w-md flex-col border-l border-border bg-surface"
      >
        <div className="flex items-center justify-between px-4 py-3">
          <h2 className="font-display text-xl">{title}</h2>
          <button
            type="button"
            className="grid size-11 place-items-center"
            onClick={onClose}
            aria-label="Close"
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-6">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="mb-3 block text-sm text-muted">
      {label}
      <div className="mt-1">{children}</div>
    </label>
  );
}

const inputClass = "w-full rounded-md border border-border bg-bg px-3 py-2 text-fg outline-none";

function SettingsForm() {
  const settings = useSol((s) => s.settings);
  const patchSettings = useSol((s) => s.patchSettings);
  const activate = useSol((s) => s.activateEndpoint),
    remember = useSol((s) => s.rememberKeys),
    setRemember = useSol((s) => s.setRememberKeys);
  const book = useSol((s) => s.connections),
    savedProviders = useSol((s) => s.customProviders),
    threadId = useSol((s) => s.activeThreadId);
  const [baseDraft, setBaseDraft] = useState(settings.baseUrl),
    [baseError, setBaseError] = useState("");
  const [note, setNote] = useState(""),
    [busy, setBusy] = useState(false);
  const test = useRef<AbortController | null>(null);
  const base = canonicalOrEmpty(baseDraft),
    committed = !!base && base === settings.baseUrl;
  const customBases = Object.keys(book).filter((raw) => !providerAt(raw));
  useEffect(() => {
    setNote("");
    setBusy(false);
    return () => {
      test.current?.abort();
      test.current = null;
    };
  }, [settings.baseUrl, settings.apiKey, settings.transport]);
  function selectBase(raw: string) {
    setBaseDraft(raw);
    setBaseError("");
    activate(raw);
  }
  function commitBase() {
    try {
      const next = baseDraft.trim() ? apiBase(baseDraft) : "";
      selectBase(next);
    } catch (e) {
      activate("");
      setBaseError(e instanceof Error ? e.message : "Enter a valid API URL.");
    }
  }
  async function checkConnection() {
    const snapshot = useSol.getState().settings;
    if (!committed || test.current) return;
    const ctrl = new AbortController();
    test.current = ctrl;
    setBusy(true);
    setNote("");
    const timer = window.setTimeout(() => ctrl.abort(), 18000);
    try {
      const { listed, ids } = await testConnection(
        snapshot.baseUrl,
        snapshot.apiKey,
        snapshot.transport,
        ctrl.signal,
      );
      if (test.current !== ctrl) return;
      setNote(
        listed
          ? `Model list reachable (${ids.length}). Send a message to verify chat access.`
          : "This endpoint does not expose a model list. Enter the exact model ID; chat can still work.",
      );
    } catch (e) {
      if (test.current === ctrl)
        setNote(
          ctrl.signal.aborted
            ? "Connection test timed out."
            : e instanceof Error
              ? e.message
              : "Could not connect.",
        );
    } finally {
      window.clearTimeout(timer);
      if (test.current === ctrl) {
        test.current = null;
        setBusy(false);
      }
    }
  }
  let routeHint = "Enter the API base URL or the full chat/completions URL.";
  try {
    routeHint =
      routeFor(baseDraft, settings.transport) === "relay"
        ? "Via sol: your deployment forwards the active key and request to this endpoint."
        : "Direct: your browser sends requests to this endpoint. If CORS blocks access, choose sol relay.";
  } catch {
    /* incomplete input */
  }
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
      }}
    >
      <p className="mb-4 text-sm text-muted">
        Choose a provider. Its key and model are restored when you switch back.
      </p>
      <Field label="Provider">
        <select
          className={inputClass}
          aria-label="Provider"
          value={savedProviders[settings.baseUrl] ? "saved:" + settings.baseUrl : settings.provider}
          onChange={(e) => {
            if (e.target.value.startsWith("saved:")) {
              selectBase(e.target.value.slice(6));
              return;
            }
            const p = PROVIDERS.find((p) => p.id === e.target.value);
            if (p) {
              const last = useSol.getState().lastCustomBase;
              selectBase(p.id === "custom" ? (savedProviders[last] ? "" : last) : p.baseUrl);
            }
          }}
        >
          {PROVIDERS.map((p) => (
            <option key={p.id} value={p.id}>
              {p.label}
            </option>
          ))}
          {Object.keys(savedProviders).length > 0 && (
            <optgroup label="Saved providers">
              {Object.entries(savedProviders)
                .sort((a, b) => a[1].localeCompare(b[1]))
                .map(([base, label]) => (
                  <option key={base} value={"saved:" + base}>
                    {label}
                  </option>
                ))}
            </optgroup>
          )}
        </select>
      </Field>
      <Field label="Base URL">
        <input
          className={inputClass}
          value={baseDraft}
          onBlur={commitBase}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              e.currentTarget.blur();
            }
          }}
          onChange={(e) => {
            setBaseDraft(e.target.value);
            setBaseError("");
            setNote("");
          }}
          list={customBases.length ? "sol-saved-bases" : undefined}
          placeholder="https://api.example.com/v1"
          maxLength={2048}
          autoCapitalize="none"
          autoComplete="off"
          spellCheck={false}
        />
      </Field>
      {customBases.length > 0 && (
        <datalist id="sol-saved-bases">
          {customBases.map((b) => (
            <option key={b} value={b} />
          ))}
        </datalist>
      )}
      {baseError && (
        <p role="alert" className="mb-2 text-xs text-danger">
          {baseError}
        </p>
      )}
      {committed && settings.provider === "custom" && (
        <ProviderBookmark key={base} base={base} reset={() => selectBase("")} />
      )}
      <Field label="API key">
        <input
          className={inputClass}
          type="password"
          maxLength={8192}
          value={committed ? settings.apiKey : ""}
          disabled={!base}
          onFocus={() => {
            if (base && !committed) commitBase();
          }}
          onChange={(e) => {
            if (useSol.getState().settings.baseUrl === base)
              patchSettings({ apiKey: e.target.value });
          }}
          placeholder={
            settings.provider === "google" ? "Gemini key from Google AI Studio" : "Provider API key"
          }
          spellCheck={false}
          autoCorrect="off"
          autoCapitalize="none"
          autoComplete="off"
        />
      </Field>
      <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            className="accent-primary"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
          />{" "}
          Remember keys on this device
        </label>
        <button
          className="sol-inline-action"
          type="button"
          disabled={!committed || !settings.apiKey}
          onClick={() => patchSettings({ apiKey: "" })}
        >
          Forget key
        </button>
      </div>
      <p className="mb-4 text-xs text-muted">
        {remember
          ? "Keys are saved in unencrypted local storage for this site. Turn this off on a shared device."
          : "Keys stay in this tab only. Saved keys have been removed from local storage."}
      </p>
      <ModelPicker key={settings.baseUrl} enabled={committed} />
      <details className="sol-search-details">
        <summary>
          {settings.provider === "openrouter" ? "Web search · OpenRouter" : "Web search · Tavily"}
        </summary>
        {settings.provider === "openrouter" ? (
          <RouterSearchSettings />
        ) : (
          <SearchSettings threadId={threadId ?? ""} />
        )}
      </details>
      <Field label="Request route">
        <select
          className={inputClass}
          value={settings.transport ?? "auto"}
          onChange={(e) => {
            patchSettings({ transport: e.target.value as "auto" | "browser" | "relay" });
          }}
        >
          <option value="auto">Automatic</option>
          <option value="relay">sol relay (server)</option>
          <option value="browser">Browser only</option>
        </select>
      </Field>
      <p className="mb-4 text-sm text-muted">{routeHint}</p>
      <Field label={`Temperature ${settings.temperature.toFixed(2)}`}>
        <input
          type="range"
          min={0}
          max={2}
          step={0.05}
          value={settings.temperature}
          onChange={(e) => patchSettings({ temperature: Number(e.target.value) })}
          className="w-full accent-primary"
        />
      </Field>
      <Field label="Max tokens">
        <input
          className={inputClass}
          type="number"
          min={64}
          max={131072}
          value={settings.maxTokens}
          onChange={(e) => patchSettings({ maxTokens: Number(e.target.value) || 900 })}
        />
      </Field>
      <p className="mb-4 text-sm text-muted">
        Streaming and web search are available in every chat. Reasoning options depend on the
        provider and model. PDFs require OpenRouter; images need a vision-capable model.
      </p>
      <Field label="Your name">
        <input
          className={inputClass}
          value={settings.userName}
          onChange={(e) => patchSettings({ userName: e.target.value })}
        />
      </Field>
      <Field label="Your persona">
        <textarea
          className={inputClass}
          rows={3}
          value={settings.userPersona}
          onChange={(e) => patchSettings({ userPersona: e.target.value })}
          placeholder="How the character should see you"
        />
      </Field>
      <button
        type="button"
        disabled={busy || !committed || !settings.apiKey.trim()}
        className="h-11 rounded-md bg-primary px-4 text-sm text-primary-fg disabled:opacity-50"
        onClick={() => void checkConnection()}
      >
        {busy ? "Checking…" : "Test connection"}
      </button>
      {note && <p className="mt-3 text-sm text-muted">{note}</p>}
    </form>
  );
}

function CharacterForm({ initial, onDone }: { initial: Character; onDone: () => void }) {
  const [form, setForm] = useState(initial);
  const upsert = useSol((s) => s.upsertCharacter);
  const remove = useSol((s) => s.deleteCharacter);
  const openCharacter = useSol((s) => s.openCharacter);
  const importCharacter = useSol((s) => s.importCharacter);
  const fileRef = useRef<HTMLInputElement>(null);

  function set<K extends keyof Character>(key: K, value: Character[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!form.name.trim()) return;
        upsert(form);
        openCharacter(form.id);
        onDone();
      }}
    >
      <div className="mb-4 flex gap-2">
        <button
          type="button"
          className="flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm"
          onClick={() => fileRef.current?.click()}
        >
          <Upload className="size-4" />
          Import JSON
        </button>
        <button
          type="button"
          className="flex h-10 items-center gap-2 rounded-md border border-border px-3 text-sm"
          onClick={() => {
            const blob = new Blob([JSON.stringify(exportCard(form), null, 2)], {
              type: "application/json",
            });
            const a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = `${form.name || "character"}.json`;
            a.click();
            URL.revokeObjectURL(a.href);
          }}
        >
          <Download className="size-4" />
          Export
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            void file.text().then((text) => {
              try {
                const imported = importCharacter(JSON.parse(text) as unknown);
                if (imported) {
                  openCharacter(imported.id);
                  onDone();
                }
              } catch {
                /* ignore bad json */
              }
            });
          }}
        />
      </div>
      {(
        [
          ["name", "Name", false],
          ["tagline", "Tagline", false],
          ["description", "Description", true],
          ["personality", "Personality", true],
          ["scenario", "Scenario", true],
          ["firstMessage", "First message", true],
          ["example", "Example dialogue", true],
          ["extra", "Extra system instructions", true],
        ] as const
      ).map(([key, label, area]) => (
        <Field key={key} label={label}>
          {area ? (
            <textarea
              className={inputClass}
              rows={key === "description" || key === "firstMessage" ? 5 : 3}
              value={form[key]}
              onChange={(e) => set(key, e.target.value)}
            />
          ) : (
            <input
              className={inputClass}
              value={form[key]}
              onChange={(e) => set(key, e.target.value)}
            />
          )}
        </Field>
      ))}
      <p className="mb-3 text-sm text-muted">
        Use {"{{char}}"} and {"{{user}}"} in any field.
      </p>
      <div className="flex gap-2">
        <button type="submit" className="h-11 flex-1 rounded-md bg-primary text-sm text-primary-fg">
          Save and open
        </button>
        {useSol.getState().characters.some((c) => c.id === form.id) && (
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md border border-border text-danger"
            aria-label="Delete character"
            onClick={() => {
              remove(form.id);
              onDone();
            }}
          >
            <Trash2 className="size-4" />
          </button>
        )}
      </div>
    </form>
  );
}
