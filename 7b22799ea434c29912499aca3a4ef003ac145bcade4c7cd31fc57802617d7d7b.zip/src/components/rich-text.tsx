import { memo, lazy, Suspense } from "react";
import type { Source } from "@/lib/sol/protocol";
const Renderer = lazy(() =>
  import("./markdown-renderer").then((m) => ({ default: m.MarkdownRenderer })),
);
import { stripHidden, visibleOffsets } from "@/lib/sol/replies";
export const RichText = memo(function RichText({
  text,
  assistant = false,
  webSources,
  pending = false,
  nativeWeb = false,
}: {
  text: string;
  assistant?: boolean;
  webSources?: Source[];
  pending?: boolean;
  nativeWeb?: boolean;
}) {
  const content = assistant ? stripHidden(text) : text;
  return (
    <Suspense fallback={<div className="sol-md whitespace-pre-wrap">{content}</div>}>
      <Renderer
        content={content}
        webSources={
          nativeWeb && webSources
            ? visibleOffsets(webSources, text.length - content.length)
            : webSources
        }
        pending={pending}
        nativeWeb={nativeWeb}
      />
    </Suspense>
  );
});
