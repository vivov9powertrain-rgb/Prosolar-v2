import { useState } from "react";
import { siteRules } from "@/lib/sol/source-policy";
import { changeLimit } from "@/lib/sol/search-budget";
import { useSol } from "@/lib/sol/store";
const cls = "mt-1 w-full rounded-md border border-border bg-bg px-3 py-2 text-fg";
import { useChatBudget } from "@/lib/sol/use-chat-budget";
function SiteInputs({
  allow,
  block,
  changeAllow,
  changeBlock,
}: {
  allow: string;
  block: string;
  changeAllow: (v: string) => void;
  changeBlock: (v: string) => void;
}) {
  let siteError = "";
  try {
    siteRules(allow, block);
  } catch (e) {
    siteError = e instanceof Error ? e.message : "Invalid sites.";
  }
  return (
    <>
      <div className="mt-2 grid gap-2">
        <label>
          Only search these domains
          <input
            className={cls}
            type="text"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            maxLength={1200}
            value={allow}
            placeholder="e.g. docs.python.org, peps.python.org"
            onChange={(e) => changeAllow(e.target.value)}
          />
        </label>
        <label>
          Never search these domains
          <input
            className={cls}
            type="text"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            maxLength={1200}
            value={block}
            placeholder="e.g. unwanted.example.com"
            onChange={(e) => changeBlock(e.target.value)}
          />
        </label>
        <p className="text-xs text-muted">
          Optional. Separate domains with commas. Subdomains count; blocked sites take precedence.
          Leave the first list empty to search the wider web.
        </p>
      </div>
      {siteError && (
        <p className="text-xs" role="alert">
          {siteError}
        </p>
      )}
    </>
  );
}
export function RouterSearchSettings() {
  const s = useSol((x) => x.settings),
    patch = useSol((x) => x.patchSettings);
  return (
    <section className="sol-search-config">
      <p className="text-xs text-muted">
        Leave both lists empty to keep OpenRouter’s normal search engine. Setting either uses
        OpenRouter’s Exa search plugin, billed by OpenRouter. No Tavily key or calls are used.
      </p>
      <SiteInputs
        allow={s.routerAllowSites}
        block={s.routerBlockSites}
        changeAllow={(routerAllowSites) => patch({ routerAllowSites })}
        changeBlock={(routerBlockSites) => patch({ routerBlockSites })}
      />
    </section>
  );
}
export function SearchSettings({ threadId }: { threadId: string }) {
  const cfg = useSol((s) => s.search),
    set = useSol((s) => s.updateSearch),
    remember = useSol((s) => s.rememberKeys),
    b = useChatBudget(threadId);
  const [error, setError] = useState("");
  return (
    <section className="sol-search-config" aria-label="Tavily settings">
      <p className="text-sm text-muted">
        OpenRouter uses its own search. For any other provider, sol can send one search query to
        Tavily and give the model numbered excerpts to cite.
      </p>
      <label>
        Tavily API key
        <input
          className={cls}
          type="password"
          autoComplete="off"
          spellCheck={false}
          maxLength={8192}
          value={cfg.apiKey}
          placeholder="tvly-…"
          onChange={(e) =>
            set({ apiKey: e.target.value, ...(!e.target.value ? { enabled: false } : {}) })
          }
        />
      </label>
      <div className="flex items-center justify-between gap-2 text-xs text-muted">
        {remember
          ? "Saved in this site’s unencrypted local storage."
          : "This tab only; key persistence is off."}
        <button
          type="button"
          className="sol-inline-action"
          disabled={!cfg.apiKey}
          onClick={() => set({ apiKey: "", enabled: false })}
        >
          Forget Tavily key
        </button>
      </div>
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          className="accent-primary"
          checked={cfg.enabled}
          disabled={!cfg.apiKey.trim()}
          onChange={(e) => set({ enabled: e.target.checked })}
        />{" "}
        Enable search outside OpenRouter
      </label>
      <label>
        Search behavior
        <select
          className={cls}
          value={cfg.strategy}
          onChange={(e) => set({ strategy: e.target.value === "model" ? "model" : "always" })}
        >
          <option value="always">Search each message</option>
          <option value="model">Let the model decide</option>
        </select>
      </label>
      <p className="text-xs text-muted">
        {cfg.strategy === "model"
          ? "One extra model call writes a focused query or skips the lookup. It can use the preceding reply’s Tavily query to understand a follow-up—not prior messages or files."
          : "Searches the latest written question (up to 400 characters), not attachments or chat history."}{" "}
        Don’t include secrets in your question.
      </p>
      <div className="grid grid-cols-2 gap-3">
        <label>
          Search depth
          <select
            className={cls}
            value={cfg.depth}
            onChange={(e) => set({ depth: e.target.value === "advanced" ? "advanced" : "basic" })}
          >
            <option value="basic">Basic</option>
            <option value="advanced">Advanced</option>
          </select>
        </label>
        <label>
          Results per call
          <select
            className={cls}
            value={cfg.results}
            onChange={(e) => set({ results: Number(e.target.value) })}
          >
            {[1, 2, 3, 4, 5].map((n) => (
              <option key={n}>{n}</option>
            ))}
          </select>
        </label>
      </div>
      <p className="text-xs text-muted">
        Safe Search is always on for Tavily. Results per call is a maximum, not a target. Only
        sources linked in the answer appear below it.
      </p>
      <details className="text-sm">
        <summary className="cursor-pointer">
          Trusted and blocked sites
          {cfg.allowSites.trim() || cfg.blockSites.trim() ? " · configured" : ""}
        </summary>
        <SiteInputs
          allow={cfg.allowSites}
          block={cfg.blockSites}
          changeAllow={(allowSites) => set({ allowSites })}
          changeBlock={(blockSites) => set({ blockSites })}
        />
      </details>
      <label>
        Search instructions
        <textarea
          className={cls}
          rows={2}
          value={cfg.instructions}
          maxLength={600}
          placeholder="Prefer primary sources; flag conflicting evidence."
          onChange={(e) => set({ instructions: e.target.value })}
        />
      </label>
      <label className="block">
        Tavily calls per conversation <strong>{b.limit}</strong>
        <input
          aria-label="Tavily calls per conversation"
          className="block mt-2 w-full accent-primary"
          type="range"
          min={10}
          max={50}
          step={1}
          value={b.limit}
          disabled={!threadId}
          onChange={(e) => {
            setError("");
            void changeLimit(threadId, Number(e.target.value)).catch(() =>
              setError("Could not save this conversation’s limit."),
            );
          }}
        />
      </label>
      <p className="text-xs text-muted">
        {b.used} used · {Math.max(0, b.limit - b.used)} left in this chat. Each dispatched search
        counts, including retries or failures. Advanced search can use more credits per call.
        OpenRouter is separate.
      </p>
      <p className="text-xs text-muted">
        Automatic and sol relay send the Tavily key through this deployment to Tavily only. Browser
        only calls Tavily directly. The model receives excerpts, not the search key.
      </p>
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
export function ProviderBookmark({ base, reset }: { base: string; reset: () => void }) {
  const saved = useSol((s) => s.customProviders[base]),
    save = useSol((s) => s.saveProvider),
    remove = useSol((s) => s.removeProvider);
  const [name, setName] = useState(saved ?? new URL(base).hostname),
    [note, setNote] = useState(""),
    [confirm, setConfirm] = useState(false);
  return (
    <div className="mb-4">
      <label className="text-sm text-muted">
        Provider name
        <input
          className={cls}
          value={name}
          maxLength={64}
          onChange={(e) => {
            setName(e.target.value);
            setNote("");
          }}
        />
      </label>
      <div className="flex flex-wrap gap-4">
        <button
          className="sol-inline-action"
          type="button"
          onClick={() => {
            try {
              save(name);
              setNote("Saved to your provider list.");
            } catch (e) {
              setNote(e instanceof Error ? e.message : "Could not save provider.");
            }
          }}
        >
          {saved ? "Save name" : "Save provider"}
        </button>
        {saved && (
          <button
            className="sol-inline-action"
            type="button"
            onClick={() => {
              if (!confirm) {
                setConfirm(true);
                return;
              }
              remove(base);
              reset();
            }}
          >
            {confirm ? "Confirm removal" : "Remove provider"}
          </button>
        )}
        {confirm && (
          <button type="button" onClick={() => setConfirm(false)}>
            Cancel
          </button>
        )}
      </div>
      <p className="text-xs text-muted">
        {confirm ? "Removing also forgets this endpoint’s key and model. Chats are kept." : note}
      </p>
    </div>
  );
}
