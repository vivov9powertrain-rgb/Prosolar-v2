import { useEffect, useMemo, useRef, useState } from "react";
import { RefreshCw } from "lucide-react";
import { testConnection } from "@/lib/sol/complete";
import { providerAt } from "@/lib/sol/endpoints";
import { defaultFromCatalog } from "@/lib/sol/models";
import { useSol } from "@/lib/sol/store";

type Result = { generation: symbol; ids: string[]; note: string; failed: boolean };
const field = "w-full min-w-0 rounded-md border border-border bg-bg px-3 py-2 text-fg";
const none: string[] = [];
const compareIDs = new Intl.Collator("en", { numeric: true }).compare;

export function ModelPicker({ enabled }: { enabled: boolean }) {
  const { baseUrl, apiKey, model, transport } = useSol((s) => s.settings);
  const patch = useSol((s) => s.patchSettings);
  const isPublic = providerAt(baseUrl)?.publicModels === true;
  // Public catalogs do not receive a stored key. All other catalogs are requested only when selected.
  const key = isPublic ? "" : apiKey.trim();
  const canFetch = enabled && !!baseUrl && (isPublic || !!key);
  const [refresh, setRefresh] = useState(0),
    [result, setResult] = useState<Result | null>(null),
    [filter, setFilter] = useState(""),
    [manual, setManual] = useState(false);
  const manualRef = useRef(false);
  const request = useMemo(
    () => ({ baseUrl, key, transport, canFetch, refresh, generation: Symbol("model-list") }),
    [baseUrl, key, transport, canFetch, refresh],
  );
  const visible = result?.generation === request.generation ? result : null,
    ids = visible?.ids ?? none;
  const pending = canFetch && !visible;
  useEffect(() => {
    const { baseUrl, key, transport, canFetch, generation } = request;
    if (!canFetch) return;
    const ctrl = new AbortController();
    let alive = true,
      timedOut = false;
    let deadline: number | undefined;
    const stillCurrent = () => {
      const now = useSol.getState().settings;
      return (
        alive &&
        now.baseUrl === baseUrl &&
        now.transport === transport &&
        (isPublic || now.apiKey.trim() === key)
      );
    };
    const timer = window.setTimeout(
      async () => {
        deadline = window.setTimeout(() => {
          timedOut = true;
          ctrl.abort();
        }, 18000);
        try {
          const { listed, ids } = await testConnection(baseUrl, key, transport, ctrl.signal);
          if (!stillCurrent()) return;
          const state = useSol.getState();
          if (ids.length && !manualRef.current && !state.connections[baseUrl]?.pinned) {
            const next = defaultFromCatalog(baseUrl, state.settings.model, ids);
            if (next !== state.settings.model) state.suggestModel(baseUrl, next);
          }
          setResult({
            generation,
            ids: ids.sort(compareIDs),
            failed: false,
            note: ids.length
              ? `${ids.length} ${ids.length === 1 ? "model" : "models"} listed${isPublic ? " · public catalog" : ""}.`
              : listed
                ? "The provider returned an empty model list. You can still enter a model ID."
                : "This endpoint does not expose a model list. Enter a model ID to chat.",
          });
        } catch (e) {
          if (!stillCurrent()) return;
          setResult({
            generation,
            ids: [],
            failed: true,
            note: timedOut
              ? "Model list timed out. Refresh or enter a model ID."
              : e instanceof Error
                ? e.message
                : "Could not load models.",
          });
        } finally {
          window.clearTimeout(deadline);
        }
      },
      isPublic ? 0 : 500,
    );
    return () => {
      alive = false;
      window.clearTimeout(timer);
      window.clearTimeout(deadline);
      ctrl.abort();
    };
  }, [request, isPublic]);
  const listed = ids.includes(model),
    showManual = enabled && (manual || (!!visible && !ids.length));
  const query = ids.length > 24 ? filter.trim().toLowerCase() : "",
    filtered = ids.filter((id) => !query || id.toLowerCase().includes(query));
  const status =
    !enabled || !baseUrl
      ? "Enter a valid base URL first."
      : !canFetch
        ? "Enter this provider’s API key to load models."
        : pending
          ? "Loading models…"
          : visible?.note;
  return (
    <div className="mb-5 min-w-0">
      <div className="mb-1 flex items-center justify-between gap-2">
        <label htmlFor="sol-model-choice" className="text-sm text-muted">
          Model
        </label>
        <button
          type="button"
          className="sol-inline-action"
          aria-label="Refresh models"
          title="Fetch the model list again"
          disabled={!canFetch || pending}
          onClick={() => setRefresh((x) => x + 1)}
        >
          <RefreshCw size={13} aria-hidden="true" /> Refresh
        </button>
      </div>
      {ids.length > 24 && (
        <input
          type="search"
          aria-label="Filter models"
          className={`${field} mb-1 text-sm`}
          value={filter}
          placeholder={`Filter ${ids.length} models…`}
          onChange={(e) => setFilter(e.target.value)}
        />
      )}
      <select
        id="sol-model-choice"
        className={field}
        disabled={!enabled || !baseUrl}
        value={manual ? "manual" : model ? "id:" + model : ""}
        onChange={(e) => {
          const v = e.target.value;
          manualRef.current = v === "manual";
          setManual(v === "manual");
          if (v.startsWith("id:")) patch({ model: v.slice(3) });
        }}
      >
        {!model && (
          <option value="" disabled>
            {pending ? "Loading models…" : "Choose a model"}
          </option>
        )}
        {model && (!listed || !filtered.includes(model)) && (
          <option value={"id:" + model}>
            {model}
            {visible && ids.length && !listed ? " (saved · not listed)" : ""}
          </option>
        )}
        {filtered.map((id) => (
          <option key={id} value={"id:" + id}>
            {id}
          </option>
        ))}
        {query && !filtered.length && <option disabled>No matching models</option>}
        <option value="manual">Enter a model ID…</option>
      </select>
      {showManual && (
        <label className="mt-2 block text-sm text-muted">
          Manual model ID
          <input
            maxLength={1024}
            className={`${field} mt-1`}
            value={model}
            placeholder="Exact provider model ID"
            autoComplete="off"
            spellCheck={false}
            onChange={(e) => {
              manualRef.current = true;
              setManual(true);
              patch({ model: e.target.value });
            }}
          />
        </label>
      )}
      <p
        role="status"
        aria-live="polite"
        className={`mt-1.5 break-words text-xs ${visible?.failed ? "text-danger" : "text-muted"}`}
      >
        {status}
      </p>
    </div>
  );
}
