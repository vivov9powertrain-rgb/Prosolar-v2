import { useRef, useState, type ReactNode } from "react";
import { Activity, Brain, Globe2, Paperclip, FileText, X } from "lucide-react";
import { ACCEPT, prepareFiles, type Attachment, type DraftFile } from "@/lib/sol/files";
import { isRouter } from "@/lib/sol/protocol";
import { useSol } from "@/lib/sol/store";
import type { Settings } from "@/lib/sol/types";
import { budgetSuggestion, modeKey, modeFor, reasonRule, type Mode } from "@/lib/sol/reasoning";
import { useChatBudget } from "@/lib/sol/use-chat-budget";
export function Files({ files, remove }: { files: Attachment[]; remove?: (id: string) => void }) {
  if (!files.length) return null;
  return (
    <ul className="file-chips" aria-label="Attached files">
      {files.map((f) => (
        <li key={f.id}>
          <FileText size={14} />
          <span title={f.name}>{f.name}</span>
          <small>{Math.max(1, Math.ceil(f.size / 1024))} KB</small>
          {remove && (
            <button type="button" aria-label={"Remove " + f.name} onClick={() => remove(f.id)}>
              <X size={14} />
            </button>
          )}
        </li>
      ))}
    </ul>
  );
}
function Chip({
  children,
  on,
  disabled,
  title,
  click,
}: {
  children: ReactNode;
  on: boolean;
  disabled: boolean;
  title: string;
  click: () => void;
}) {
  return (
    <button
      type="button"
      className="tool-chip"
      aria-pressed={on}
      title={title}
      disabled={disabled}
      onClick={click}
    >
      {children}
    </button>
  );
}
export function ChatTools({
  settings,
  files,
  setFiles,
  locked,
  reading,
  setReading,
  onError,
  threadId,
  openSearch,
}: {
  settings: Settings;
  files: DraftFile[];
  setFiles: (f: DraftFile[]) => void;
  locked: boolean;
  reading: boolean;
  setReading: (b: boolean) => void;
  onError: (s: string) => void;
  threadId: string;
  openSearch: () => void;
}) {
  const input = useRef<HTMLInputElement>(null),
    router = isRouter(settings.baseUrl),
    patch = useSol((s) => s.patchSettings);
  const cfg = useSol((s) => s.search),
    updateSearch = useSol((s) => s.updateSearch),
    budget = useChatBudget(threadId);
  const rule = reasonRule(settings.baseUrl, settings.model),
    mode = modeFor(settings.baseUrl, settings.model, settings.reasoningModes),
    goal =
      router && settings.highReasoning
        ? 4096
        : budgetSuggestion(settings.baseUrl, settings.model, mode);
  const [help, setHelp] = useState(false);
  return (
    <div className="sol-tools">
      <Files
        files={files.map((f) => f.ref)}
        remove={
          locked || reading ? undefined : (id) => setFiles(files.filter((f) => f.ref.id !== id))
        }
      />
      <div className="tool-row" role="group" aria-label="Message tools">
        <input
          ref={input}
          className="hidden"
          type="file"
          multiple
          accept={ACCEPT}
          aria-label="Files to attach"
          onChange={async (e) => {
            const selected = Array.from(e.target.files || []);
            e.target.value = "";
            if (!selected.length) return;
            setReading(true);
            onError("");
            try {
              setFiles([...files, ...(await prepareFiles(selected, files, router))]);
            } catch (err) {
              onError(err instanceof Error ? err.message : "Could not read file.");
            } finally {
              setReading(false);
            }
          }}
        />
        <button
          type="button"
          className="tool-chip"
          disabled={locked || reading}
          onClick={() => input.current?.click()}
          title="Attach up to 3 files · 2 MiB total"
        >
          <Paperclip size={14} />
          {reading ? "Reading…" : "Attach"}
        </button>
        <Chip
          on={settings.streaming}
          disabled={locked}
          title="Show the reply as it arrives"
          click={() => patch({ streaming: !settings.streaming })}
        >
          <Activity size={14} />
          Streaming
        </Chip>
        {router ? (
          <Chip
            on={settings.highReasoning}
            disabled={locked}
            title="Request high effort from a reasoning-capable model. Uses output tokens."
            click={() => patch({ highReasoning: !settings.highReasoning })}
          >
            <Brain size={14} />
            High reasoning
          </Chip>
        ) : (
          <label
            className="tool-chip sol-effort"
            title={
              rule
                ? "Provider-specific reasoning control"
                : "No documented reasoning override for this model."
            }
          >
            <Brain size={14} />
            <span>Reasoning</span>
            <select
              aria-label="Reasoning mode"
              disabled={locked || !rule}
              value={mode}
              onChange={(e) =>
                patch({
                  reasoningModes: {
                    ...settings.reasoningModes,
                    [modeKey(settings.baseUrl, settings.model)]: e.target.value as Mode,
                  },
                })
              }
            >
              <option value="default">{rule ? "Default" : "N/A"}</option>
              {rule?.modes.map((m) => (
                <option key={m} value={m}>
                  {m === "none" ? "Off" : m === "on" ? "On" : m[0].toUpperCase() + m.slice(1)}
                </option>
              ))}
            </select>
          </label>
        )}
        <Chip
          on={router ? settings.webSearch : cfg.enabled}
          disabled={locked}
          title={
            router
              ? "Search via OpenRouter; no Tavily key is used."
              : "Search via Tavily. Charges may apply."
          }
          click={() => {
            if (router) patch({ webSearch: !settings.webSearch });
            else if (!cfg.apiKey.trim() && !cfg.enabled) openSearch();
            else updateSearch({ enabled: !cfg.enabled });
          }}
        >
          <Globe2 size={14} />
          Web search
        </Chip>
        <button
          type="button"
          className="tool-info"
          title="About message tools"
          aria-label="About message tools"
          aria-expanded={help}
          onClick={() => setHelp(!help)}
        >
          ?
        </button>
      </div>
      {help && (
        <p className="tool-hint">
          Attach up to 3 files, 2 MiB total. Text files must be UTF-8 and at most 128 KiB. Images
          need a vision model; PDFs use OpenRouter text extraction. Files are saved on this device
          and included in later requests in this chat. Reasoning controls reflect the selected
          model. Default leaves its normal behavior unchanged. Search uses OpenRouter there and
          Tavily everywhere else; both may cost extra.
        </p>
      )}
      {router && (settings.webSearch || settings.model.split(":").includes("online")) && (
        <p className="tool-hint">
          <button type="button" onClick={openSearch}>
            OpenRouter search sites
          </button>{" "}
          · Uses OpenRouter credits, not Tavily.
        </p>
      )}
      {!router && (cfg.enabled || help) && (
        <p className="tool-hint">
          <button type="button" onClick={openSearch}>
            Tavily settings · {budget.used}/{budget.limit} calls
          </button>
          {cfg.enabled ? " · Web search is on." : ""}
        </p>
      )}
      {goal > 0 && settings.maxTokens < goal && (
        <p className="tool-hint">
          Reasoning shares your {settings.maxTokens}-token budget.{" "}
          <button type="button" disabled={locked} onClick={() => patch({ maxTokens: goal })}>
            Use {goal.toLocaleString("en-US")} tokens
          </button>
        </p>
      )}
    </div>
  );
}
