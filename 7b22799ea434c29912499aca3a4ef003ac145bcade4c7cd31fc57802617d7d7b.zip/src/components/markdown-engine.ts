// Adapted from the supplied MarkdownRenderer. Keep its KaTeX extraction/healing, but
// treat all message and search text as untrusted. Only generated KaTeX receives a rich markup sink.
import { Marked } from "marked";
import katex from "katex";
import "katex/contrib/mhchem";
import "katex/dist/katex.min.css";
import DOMPurify from "dompurify";
import { sourceUrl, sourceIdentity } from "@/lib/sol/source-policy";
import { safeLink, sourceNumber, type Source } from "@/lib/sol/protocol";
interface MathItem {
  token: string;
  math: string;
  isBlock: boolean;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Standard LaTeX command names that KaTeX supports
const KNOWN_LATEX_COMMANDS = new Set([
  "frac",
  "dfrac",
  "cfrac",
  "sqrt",
  "text",
  "textbf",
  "textit",
  "textrm",
  "mathrm",
  "mathbf",
  "mathit",
  "mathcal",
  "mathbb",
  "ce",
  "pu",
  "times",
  "cdot",
  "div",
  "pm",
  "mp",
  "leq",
  "geq",
  "le",
  "ge",
  "neq",
  "approx",
  "sim",
  "simeq",
  "infty",
  "propto",
  "sum",
  "prod",
  "int",
  "iint",
  "iiint",
  "oint",
  "lim",
  "inf",
  "sup",
  "min",
  "max",
  "sin",
  "cos",
  "tan",
  "cot",
  "sec",
  "csc",
  "sinh",
  "cosh",
  "tanh",
  "log",
  "ln",
  "exp",
  "det",
  "dim",
  "ker",
  "deg",
  "partial",
  "nabla",
  "d",
  "dx",
  "dy",
  "dt",
  "alpha",
  "beta",
  "gamma",
  "delta",
  "epsilon",
  "varepsilon",
  "zeta",
  "eta",
  "theta",
  "vartheta",
  "iota",
  "kappa",
  "lambda",
  "mu",
  "nu",
  "xi",
  "pi",
  "varpi",
  "rho",
  "varrho",
  "sigma",
  "varsigma",
  "tau",
  "upsilon",
  "phi",
  "varphi",
  "chi",
  "psi",
  "omega",
  "Gamma",
  "Delta",
  "Theta",
  "Lambda",
  "Xi",
  "Pi",
  "Sigma",
  "Upsilon",
  "Phi",
  "Psi",
  "Omega",
  "left",
  "right",
  "big",
  "Big",
  "bigg",
  "Bigg",
  "begin",
  "end",
  "overline",
  "underline",
  "hat",
  "check",
  "breve",
  "acute",
  "grave",
  "tilde",
  "bar",
  "vec",
  "dot",
  "ddot",
  "arrow",
  "rightarrow",
  "leftarrow",
  "implies",
  "iff",
  "Rightarrow",
  "Leftarrow",
  "longrightarrow",
  "longleftarrow",
  "to",
  "mapsto",
  "quad",
  "qquad",
  "hspace",
  "vspace",
  "phantom",
  "color",
  "over",
  "atop",
  "degree",
  "celcius",
  "celsius",
  "ohm",
  "micro",
  "unit",
  "circ",
  "angle",
  "perp",
  "parallel",
  "therefore",
  "because",
  "bold",
  "cancel",
]);

const KATEX_MACROS = {
  "\\d": "\\mathrm{d}",
  "\\degree": "^\\circ",
  "\\celcius": "^\\circ\\mathrm{C}",
  "\\celsius": "^\\circ\\mathrm{C}",
  "\\ohm": "\\Omega",
  "\\micro": "\\mu",
  "\\unit": "\\mathrm{#1}",
  "\\cancel": "\\not{#1}",
  "\\bold": "\\mathbf{#1}",
};

// Auto-heals common model LaTeX syntax slips before falling back
function renderMathWithHealing(rawMath: string, isBlock: boolean): string {
  if (rawMath.length > 6000) return `<span class="katex-fallback">${escapeHtml(rawMath)}</span>`;
  const tryRender = (m: string) => {
    return katex.renderToString(m, {
      displayMode: isBlock,
      throwOnError: true,
      strict: false,
      output: "htmlAndMathml",
      trust: false,
      macros: { ...KATEX_MACROS },
      maxExpand: 500,
      maxSize: 20,
    });
  };

  try {
    return tryRender(rawMath);
  } catch (err: any) {
    let healed = rawMath;

    // 1. Balance unclosed braces
    const openBraces = (healed.match(/\{/g) || []).length;
    const closeBraces = (healed.match(/\}/g) || []).length;
    if (openBraces > closeBraces) {
      healed += "}".repeat(openBraces - closeBraces);
    } else if (closeBraces > openBraces) {
      healed = "{".repeat(closeBraces - openBraces) + healed;
    }

    // 2. Fix unknown control sequence from KaTeX error message (e.g., \Take -> \text{Take})
    const undefinedMatch = (err?.message || "").match(
      /Undefined control sequence:\s*\\([a-zA-Z]+)/,
    );
    if (undefinedMatch) {
      const badCmd = undefinedMatch[1];
      healed = healed.replace(new RegExp("\\\\" + badCmd + "\\b", "g"), `\\text{${badCmd}}`);
    }

    try {
      return tryRender(healed);
    } catch {
      // 3. Last attempt: strip any remaining backslashes before non-standard commands
      try {
        const sanitized = healed.replace(/\\([a-zA-Z]+)/g, (match, cmd) => {
          return KNOWN_LATEX_COMMANDS.has(cmd) ? match : `\\text{${cmd}}`;
        });
        return tryRender(sanitized);
      } catch {
        // Fallback display
        return `<span class="katex-fallback font-mono text-cyan-300 text-sm bg-zinc-900/70 px-1.5 py-0.5 rounded border border-zinc-800">${escapeHtml(rawMath)}</span>`;
      }
    }
  }
}

const parser = new Marked({
  gfm: true,
  breaks: true,
  async: false,
  renderer: {
    html({ text }) {
      return escapeHtml(text);
    },
    image({ href, text }) {
      const url = safeLink(href);
      return url
        ? `<a href="${escapeHtml(url)}">Image: ${escapeHtml(text || "Open image")}</a>`
        : escapeHtml(text);
    },
    link({ href, tokens }) {
      const label = this.parser.parseInline(tokens),
        url = safeLink(href);
      return url ? `<a href="${escapeHtml(url)}">${label}</a>` : label;
    },
  },
});
type RenderedMessage = { html: string; cited: Source[] };
export function messageHtml(
  content: string,
  webSources?: Source[],
  nativeWeb = false,
): RenderedMessage {
  if (!content) return { html: "", cited: [] };
  if (typeof document === "undefined" || !DOMPurify.isSupported || content.length > 180000)
    return { html: `<pre>${escapeHtml(content)}</pre>`, cited: [] };
  try {
    const mathItems: MathItem[] = [],
      code: string[] = [];
    let tokenCounter = 0,
      prefix = "KATEXMATH";
    while (content.includes(prefix))
      prefix = "SOLMATH" + crypto.randomUUID().replaceAll("-", "") + "Q";
    const stash = (v: string) => `${prefix}CODE${code.push(v) - 1}END`;
    let processed = content;
    // Protect code before normalizing backslashes or scanning dollars. Preserve the exact original
    // fenced content, including an unfinished fence while a response streams.
    const lines = processed.split("\n");
    const blocks: string[] = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const quote = line.match(/^(?: {0,3}>[ \t]?)+/)?.[0] ?? "";
      const f = /^(\s*)(`{3,}|~{3,})(.*)$/.exec(line.slice(quote.length));
      if (!f) {
        blocks.push(line);
        continue;
      }
      const close = new RegExp("^\\s*" + f[2][0] + "{" + f[2].length + ",}\\s*$");
      let j = i + 1;
      const view = (s: string) => (quote ? s.replace(/^(?: {0,3}>[ \t]?)+/, "") : s);
      while (
        j < lines.length &&
        (!quote || /^ {0,3}>/.test(lines[j])) &&
        !close.test(view(lines[j]))
      )
        j++;
      const end = j < lines.length && close.test(view(lines[j])) ? j + 1 : j;
      if (/^(?:math|latex)$/i.test(f[3].trim())) {
        const token = `${prefix}BLOCK${tokenCounter++}END`;
        mathItems.push({
          token,
          math: lines
            .slice(i + 1, j)
            .map(view)
            .join("\n")
            .trim(),
          isBlock: true,
        });
        blocks.push(quote + f[1] + token);
      } else blocks.push(stash(lines.slice(i, end).join("\n")));
      i = end - 1;
    }
    processed = blocks.join("\n");
    if (/^(?: {4}|\t)/m.test(processed)) {
      // Let Marked distinguish top-level indented code from list-continuation math.
      const indented = parser
        .lexer(processed)
        .filter((t) => t.type === "code" && t.codeBlockStyle === "indented");
      for (const t of indented) {
        const literal = t.raw.replace(/\n+$/, "");
        if (literal) processed = processed.replace(literal, () => stash(literal));
      }
    }
    processed = processed.replace(/(`+)(?!`)([\s\S]*?)\1(?!`)/g, (x) => stash(x));
    // Keep indented code and JSON literals intact; unwrap only the original explicit KaTeX repair prompts.
    processed = processed.replace(
      /^(?:why\s+is\s+my\s+katex\s+broken[^{]*|still\s+did(?:n'?t)?\s+fix[^{]*)\{([\s\S]*)\}\s*$/i,
      "$1",
    );
    if ((processed.match(/(?<!\\)\$\$/g) || []).length % 2) processed += "\n$$";
    // 1. Double backslash normalization in LaTeX commands often returned by JSON APIs
    processed = processed.replace(
      /\\\\(frac|sqrt|times|alpha|beta|gamma|delta|theta|lambda|pi|sigma|omega|text|mathbf|mathrm|ce|pu|left|right|begin|end|sum|int|lim|to|infty|approx|pm|cdot|vec|hat|bar|quad|qquad|Delta|nabla)/g,
      "\\$1",
    );

    // 2. Extract markdown math codeblocks ```math ... ``` or ```latex ... ```
    processed = processed.replace(/```(?:math|latex)\s*([\s\S]*?)```/gi, (_, math) => {
      const token = `${prefix}BLOCK${tokenCounter++}END`;
      mathItems.push({
        token,
        math: math.trim(),
        isBlock: true,
      });
      return token;
    });

    // 3. Extract display block math $$...$$
    // Note: Preserve line indentation (${indent}) instead of injecting blank lines so Markdown lists don't break into indented code blocks
    processed = processed.replace(/(^[ \t]*)\$\$([\s\S]*?)\$\$/gm, (_, indent, math) => {
      const token = `${prefix}BLOCK${tokenCounter++}END`;
      mathItems.push({
        token,
        math: math.trim(),
        isBlock: true,
      });
      return `${indent}${token}`;
    });
    processed = processed.replace(/\$\$([\s\S]*?)\$\$/g, (_, math) => {
      const token = `${prefix}BLOCK${tokenCounter++}END`;
      mathItems.push({
        token,
        math: math.trim(),
        isBlock: true,
      });
      return token;
    });

    // 4. Extract display math \[...\]
    processed = processed.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => {
      const token = `${prefix}BLOCK${tokenCounter++}END`;
      mathItems.push({
        token,
        math: math.trim(),
        isBlock: true,
      });
      return token;
    });

    // 5. Extract standalone LaTeX environments (align, matrix, cases, etc.)
    processed = processed.replace(
      /\\begin\{(align|aligned|gather|gathered|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|equation|cases|split|eqnarray|array)\*?\}([\s\S]*?)\\end\{\1\*?\}/g,
      (fullMatch) => {
        const token = `${prefix}BLOCK${tokenCounter++}END`;
        mathItems.push({
          token,
          math: fullMatch.trim(),
          isBlock: true,
        });
        return token;
      },
    );

    // 6. Extract inline math \(...\)
    processed = processed.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => {
      const token = `${prefix}INLINE${tokenCounter++}END`;
      mathItems.push({
        token,
        math: math.trim(),
        isBlock: false,
      });
      return token;
    });

    // 8. Extract inline math $...$
    processed = processed.replace(
      /(?<!\\|\$)\$([^\s$](?:[^$\n\r]*?[^\s$])?)\$(?!\$)/g,
      (match, math) => {
        const trimmed = math.trim();
        if (!trimmed) {
          return match;
        }
        const token = `${prefix}INLINE${tokenCounter++}END`;
        mathItems.push({
          token,
          math: trimmed,
          isBlock: false,
        });
        return token;
      },
    );

    // 7. Extract standalone \ce{...} (Chemistry equations)
    processed = processed.replace(/(?<![$\\])\\ce\{([^{}]+(?:\{[^{}]*\}[^{}]*)*)\}/g, (_, chem) => {
      const token = `${prefix}INLINE${tokenCounter++}END`;
      mathItems.push({
        token,
        math: `\\ce{${chem}}`,
        isBlock: false,
      });
      return token;
    });

    // 10. Auto-separate formulas accidentally fused with English sentences in remaining text:
    // e.g. \text{Area} = \frac{1}{2} \Take a deep breath -> \text{Area} = \frac{1}{2} \n\nTake a deep breath
    processed = processed.replace(
      /(\\(?:text|frac|sqrt|vec|mathrm|mathbf)\{[^}]+\}[^.!?\n]*?=\s*(?:\\frac\{[^}]+\}\{[^}]+\}|\d+(?:\/\d+)?))\s*\\?([A-Z][a-z]+)/g,
      "$1\n\n$2",
    );

    // 11. Fix stray backslashes before regular conversational English words in prose
    processed = processed.replace(/\\([A-Za-z]+)(\s+)/g, (match, cmd, trailingSpace) => {
      if (KNOWN_LATEX_COMMANDS.has(cmd)) {
        return match;
      }
      return `${cmd}${trailingSpace}`;
    });

    // 12. Wrap raw LaTeX display equations on their own lines missing $$ delimiters:
    // e.g. \text{Area}_{\text{top}} = \frac{1}{2} \times (\text{Top} + \text{Bottom}) \times \text{Height}
    const rawLines = processed.split("\n");
    processed = rawLines
      .map((line) => {
        const trimmed = line.trim();
        if (!trimmed) return line;
        if (trimmed.startsWith(prefix)) return line;
        if (/^[#*>\-|]/.test(trimmed)) return line;
        if (/[\uD800-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27BF]/.test(trimmed)) return line;
        if (/[!?]/.test(trimmed)) return line;

        const hasLatex =
          /\\(text|frac|sqrt|vec|mathbf|mathrm|times|cdot|pm|approx|left|right|sum|int|lim)/.test(
            trimmed,
          );
        if (!hasLatex) return line;

        const startsMath =
          /^(\\text\{|\\frac\{|\\sqrt\{|\\vec\{|\\mathbf\{|\\mathrm\{|\\displaystyle|[a-zA-Z\\][a-zA-Z0-9_{}\\]*\s*=)/.test(
            trimmed,
          );
        if (startsMath) {
          const token = `${prefix}BLOCK${tokenCounter++}END`;
          mathItems.push({
            token,
            math: trimmed,
            isBlock: true,
          });
          return line.replace(trimmed, token);
        }
        return line;
      })
      .join("\n");

    // 13. Auto-wrap naked standalone math symbols in PROSE ONLY (all real math delimiters were already extracted)
    processed = processed.replace(
      /(?<![A-Za-z0-9\\])\\(rightarrow|leftarrow|leftrightarrow|implies|iff)(?![A-Za-z])/g,
      (_, sym) => {
        const token = `${prefix}INLINE${tokenCounter++}END`;
        mathItems.push({
          token,
          math: `\\${sym}`,
          isBlock: false,
        });
        return token;
      },
    );

    // 14. Auto-wrap naked fractions in prose
    processed = processed.replace(
      /(?<![A-Za-z0-9\\])\\frac\{([^{}]+)\}\{([^{}]+)\}/g,
      (_, num, den) => {
        const token = `${prefix}INLINE${tokenCounter++}END`;
        mathItems.push({
          token,
          math: `\\frac{${num}}{${den}}`,
          isBlock: false,
        });
        return token;
      },
    );

    processed = processed.replace(
      new RegExp(prefix + "CODE(\\d+)END", "g"),
      (_, n) => code[Number(n)] ?? "",
    );
    // Definitions preserve the ID in the evidence actually given to the model, even when
    // the only retained citation on reload is S3. Never infer citations from raw text/code.
    const accepted = new Map<string, Source>(),
      used = new Map<string, Source>();
    const refs = (webSources ?? []).slice(0, nativeWeb ? 20 : 5).flatMap((s, i) => {
      const url = sourceUrl(s.url),
        id = sourceNumber(s, i);
      if (!url) return [];
      const key = sourceIdentity(url)!,
        positioned =
          nativeWeb &&
          Number.isInteger(s.startIndex) &&
          Number.isInteger(s.endIndex) &&
          s.startIndex! >= 0 &&
          s.endIndex! > s.startIndex! &&
          s.endIndex! <= content.length &&
          !!content.slice(s.startIndex, s.endIndex).trim();
      const source: Source = {
        title: s.title,
        url,
        ...(nativeWeb
          ? positioned
            ? { startIndex: s.startIndex, endIndex: s.endIndex }
            : {}
          : { id }),
      };
      accepted.set(key, source);
      if (positioned) used.set(key, source); // Some native providers use character spans instead of inline Markdown.
      return nativeWeb ? [] : [`[S${id}]: <${url}>`];
    });
    if (refs.length) processed = refs.join("\n") + "\n\n" + processed;
    const raw = parser.parse(processed, { async: false });
    const tree = DOMPurify.sanitize(raw, {
      RETURN_DOM_FRAGMENT: true,
      ALLOWED_TAGS: [
        "p",
        "br",
        "hr",
        "blockquote",
        "pre",
        "code",
        "ul",
        "ol",
        "li",
        "em",
        "strong",
        "del",
        "a",
        "table",
        "thead",
        "tbody",
        "tr",
        "th",
        "td",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "input",
      ],
      ALLOWED_ATTR: ["href", "align", "start", "type", "disabled", "checked"],
      ALLOW_DATA_ATTR: false,
      ALLOW_ARIA_ATTR: false,
      ALLOWED_URI_REGEXP: /^https?:\/\//i,
    });
    for (const a of tree.querySelectorAll("a")) {
      const u = safeLink(a.getAttribute("href"));
      const match =
        webSources !== undefined && u ? accepted.get(sourceIdentity(u) ?? "") : undefined;
      const label = a.textContent?.trim() ?? "",
        marker = /^\[?S(\d+)\]?$/i.exec(label);
      if (
        !u ||
        (webSources !== undefined &&
          (!match || (!nativeWeb && marker && Number(marker[1]) !== match.id)))
      ) {
        // Preserve prose and code. Do not print an unknown bare URL as a suggested destination.
        if (webSources !== undefined && /^(?:https?:\/\/|www\.)/i.test(label))
          a.replaceWith(document.createTextNode("[link not in search results]"));
        else a.replaceWith(...a.childNodes);
        continue;
      }
      if (match) used.set(sourceIdentity(match.url)!, match);
      a.href = match?.url ?? u;
      a.target = "_blank";
      a.rel = "noopener noreferrer nofollow";
    }
    for (const input of tree.querySelectorAll("input")) {
      input.type = "checkbox";
      input.disabled = true;
    }
    const walker = document.createTreeWalker(tree, NodeFilter.SHOW_TEXT),
      texts: Text[] = [];
    while (walker.nextNode()) texts.push(walker.currentNode as Text);
    const pattern = new RegExp(prefix + "(?:BLOCK|INLINE)\\d+END", "g"),
      tokens = new Map(mathItems.map((x) => [x.token, x]));
    let rendered = 0;
    for (const text of texts) {
      if (text.parentElement?.closest("code,pre") || !text.data.includes(prefix)) continue;
      let at = 0;
      const nodes: Node[] = [];
      for (const m of text.data.matchAll(pattern)) {
        const item = tokens.get(m[0]);
        if (!item) continue;
        const idx = m.index!;
        nodes.push(document.createTextNode(text.data.slice(at, idx)));
        const el = document.createElement("span");
        el.className = item.isBlock ? "katex-display-wrapper" : "katex-inline-wrapper";
        if (item.isBlock) el.style.display = "block";
        if (rendered++ < 256) el.innerHTML = renderMathWithHealing(item.math, item.isBlock);
        else el.textContent = item.math;
        nodes.push(el);
        at = idx + m[0].length;
      }
      if (nodes.length) {
        nodes.push(document.createTextNode(text.data.slice(at)));
        text.replaceWith(...nodes);
      }
    }
    for (const pre of tree.querySelectorAll("pre")) {
      const frame = document.createElement("div"),
        bar = document.createElement("div"),
        label = document.createElement("span"),
        btn = document.createElement("button");
      frame.className = "sol-code";
      bar.className = "code-bar";
      label.textContent = "Code";
      btn.type = "button";
      btn.setAttribute("aria-label", "Copy code");
      btn.dataset.solCopy = "1";
      btn.textContent = "Copy";
      pre.tabIndex = 0;
      pre.replaceWith(frame);
      bar.append(label, btn);
      frame.append(bar, pre);
    }
    for (const t of tree.querySelectorAll("table")) {
      const frame = document.createElement("div");
      frame.className = "md-table";
      frame.setAttribute("role", "region");
      frame.setAttribute("aria-label", "Scrollable table");
      frame.tabIndex = 0;
      t.replaceWith(frame);
      frame.append(t);
    }
    const root = document.createElement("div");
    root.append(tree);
    return { html: root.innerHTML, cited: [...used.values()] };
  } catch {
    return { html: `<pre>${escapeHtml(content)}</pre>`, cited: [] };
  }
}
