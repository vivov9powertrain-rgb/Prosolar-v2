import { memo, useMemo } from "react";
import { Sources } from "./source-links";
import { messageHtml } from "./markdown-engine";
import type { Source } from "@/lib/sol/protocol";
export const MarkdownRenderer = memo(function MarkdownRenderer({
  content,
  webSources,
  pending = false,
  nativeWeb = false,
}: {
  content: string;
  webSources?: Source[];
  pending?: boolean;
  nativeWeb?: boolean;
}) {
  const { html, cited } = useMemo(
    () => messageHtml(content, webSources, nativeWeb),
    [content, webSources, nativeWeb],
  );
  return (
    <>
      <div
        className="sol-md"
        onClick={(e) => {
          const btn =
            e.target instanceof Element
              ? e.target.closest<HTMLButtonElement>("button[data-sol-copy]")
              : null;
          if (!btn || !e.currentTarget.contains(btn)) return;
          const text = btn.closest(".sol-code")?.querySelector("pre code")?.textContent ?? "";
          void (async () => {
            try {
              await navigator.clipboard.writeText(text);
              btn.textContent = "Copied";
            } catch {
              btn.textContent = "Select code to copy";
            }
          })();
        }}
        dangerouslySetInnerHTML={{ __html: html }}
      />
      {webSources !== undefined &&
        (cited.length ? (
          <Sources sources={cited} grounded={!nativeWeb} />
        ) : (
          !pending && (
            <p className="tool-hint">
              {nativeWeb
                ? "No matching OpenRouter citation for this answer."
                : "No web source was cited in this answer."}
            </p>
          )
        ))}
    </>
  );
});
