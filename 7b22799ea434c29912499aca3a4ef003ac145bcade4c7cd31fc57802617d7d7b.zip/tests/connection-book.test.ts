import assert from "node:assert/strict";
import test from "node:test";
import {
  changeSettings,
  deviceForDisk,
  restoreDevice,
  switchEndpoint,
} from "../src/lib/sol/connections.ts";
import { defaultFromCatalog, parseCatalog } from "../src/lib/sol/models.ts";
import { relayChat } from "../src/lib/sol/relay.ts";
import { testConnection } from "../src/lib/sol/complete.ts";
const or = "https://openrouter.ai/api/v1",
  nv = "https://integrate.api.nvidia.com/v1",
  google = "https://generativelanguage.googleapis.com/v1beta/openai";
const custom = "https://tenant.example.org/a/v1";

test("upgrade imports the prior active key only at its explicit canonical endpoint", () => {
  const upgraded = restoreDevice({
    settings: {
      baseUrl: google + "/chat/completions/",
      provider: "custom",
      apiKey: "old-fixture",
      model: "gemini-chosen",
      streaming: false,
    },
  });
  assert.equal(upgraded.settings.provider, "google");
  assert.equal(upgraded.settings.apiKey, "old-fixture");
  assert.equal(upgraded.settings.streaming, false);
  const disk = deviceForDisk(upgraded);
  assert.equal(disk.settings?.apiKey, undefined);
  assert.deepEqual(Object.keys(disk.connections!), [google]);
  assert.equal(disk.connections?.[google]?.pinned, true);
  assert.equal(restoreDevice(disk).settings.apiKey, "old-fixture");
  assert.equal(switchEndpoint(upgraded, nv).settings.apiKey, "");
  for (const legacy of [
    { apiKey: "orphan" },
    { baseUrl: "https://tenant.example.org/v1?key=orphan", apiKey: "orphan" },
  ])
    assert.doesNotMatch(
      JSON.stringify(deviceForDisk(restoreDevice({ settings: legacy }))),
      /orphan/,
    );
});
test("only equivalent endpoints share keys; keys and chosen models survive multiple switches and a reload", () => {
  let s = restoreDevice();
  const visit = (url: string) => {
    s = { ...s, ...switchEndpoint(s, url) };
  };
  const edit = (key: string, model: string) => {
    s = { ...s, ...changeSettings(s, { apiKey: key, model }) };
  };
  edit("or-fixture", "or/one");
  visit(google);
  assert.equal(s.settings.apiKey, "");
  edit("g-fixture", "gemini-two");
  visit(custom);
  edit("a-fixture", "custom-3");
  for (const other of [
    "https://tenant.example.org/b/v1",
    "https://sub.tenant.example.org/a/v1",
    "https://tenant.example.org:8080/a/v1",
    "http://tenant.example.org/a/v1",
    "not a URL",
  ]) {
    visit(other);
    assert.equal(s.settings.apiKey, "");
  }
  s = restoreDevice(deviceForDisk(s));
  visit(custom + "/models");
  assert.equal(s.settings.apiKey, "a-fixture");
  visit(google + "/");
  assert.equal(s.settings.model, "gemini-two");
  visit(or + "/chat/completions");
  assert.equal(s.settings.model, "or/one");
  assert.equal(s.settings.apiKey, "or-fixture");
  assert.equal(Object.keys(s.connections).length, 3);
});
test("forget is per endpoint; session-only mode removes every credential from disk, not model preferences", () => {
  let s = restoreDevice();
  s = { ...s, ...changeSettings(s, { apiKey: "fixture-first", model: "first-model" }) };
  s = { ...s, ...switchEndpoint(s, nv) };
  s = { ...s, ...changeSettings(s, { apiKey: "fixture-second", model: "second-model" }) };
  const forgotten = { ...s, ...changeSettings(s, { apiKey: "" }) };
  const snap = deviceForDisk(forgotten);
  assert.doesNotMatch(JSON.stringify(snap), /fixture-second/);
  assert.equal(snap.connections![or].apiKey, "fixture-first");
  assert.equal(
    restoreDevice({ ...snap, settings: { ...snap.settings, apiKey: "stale" } }).settings.apiKey,
    "",
  );
  const session = { ...s, rememberKeys: false };
  const privateDisk = deviceForDisk(session);
  assert.doesNotMatch(JSON.stringify(privateDisk), /fixture-first|fixture-second/);
  assert.equal(session.settings.apiKey, "fixture-second");
  const after = restoreDevice(privateDisk);
  assert.equal(after.settings.apiKey, "");
  assert.equal(switchEndpoint(after, or).settings.model, "first-model");
  assert.equal(after.rememberKeys, false);
});
test("deduplicates and normalizes Gemini IDs only on the exact Google API; picks a listed default without replacing a valid choice", () => {
  const data = [
    { id: "models/gemini-2.5-pro" },
    { id: " models/gemini-3.5-flash " },
    { id: "gemini-3.5-flash" },
    { id: "models/gemini-2.5-flash" },
    null,
    { id: "" },
    { id: 42 },
    { id: "not-chat", architecture: { output_modalities: ["image"] } },
  ];
  const catalog = parseCatalog(google, { data });
  assert.deepEqual(catalog, {
    listed: true,
    ids: ["gemini-2.5-pro", "gemini-3.5-flash", "gemini-2.5-flash"],
  });
  assert.equal(defaultFromCatalog(google, "", catalog.ids), "gemini-3.5-flash");
  assert.equal(defaultFromCatalog(google, "gemini-2.5-pro", catalog.ids), "gemini-2.5-pro");
  assert.equal(parseCatalog(custom, { data }).ids[0], "models/gemini-2.5-pro");
  assert.deepEqual(parseCatalog(nv, {}), { listed: false, ids: [] });
  assert.deepEqual(parseCatalog(nv, { data: [] }), { listed: true, ids: [] });
  assert.equal(
    defaultFromCatalog(nv, "", ["another", "google/gemma-3-12b-it"]),
    "google/gemma-3-12b-it",
  );
  assert.equal(defaultFromCatalog(or, "absent", ["a", "openrouter/free"]), "openrouter/free");
});
test("relay permits anonymous GET /models only for the exact OpenRouter and NVIDIA APIs; all chats still require keys", async () => {
  const run = (body: object, stub: (url: string, init: RequestInit) => Promise<Response>) =>
    relayChat(
      new Request("https://sol.example/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      }),
      stub,
    );
  for (const baseUrl of [or, nv]) {
    let sent = false;
    const r = await run(
      { baseUrl: baseUrl + "/chat/completions", probe: "models" },
      async (url, init) => {
        sent = true;
        assert.equal(url, baseUrl + "/models");
        assert.equal(init.method, "GET");
        assert.equal(init.body, undefined);
        assert.equal(new Headers(init.headers).has("authorization"), false);
        return Response.json({ data: [] });
      },
    );
    assert.equal(r.status, 200);
    assert.equal(sent, true);
  }
  for (const body of [
    {
      baseUrl: nv,
      model: "test",
      stream: false,
      max_tokens: 10,
      messages: [{ role: "user", content: "x" }],
    },
    ...[
      google,
      custom,
      nv + "/private",
      or.replace("openrouter.ai", "openrouter.ai.example.org"),
    ].map((baseUrl) => ({ baseUrl, probe: "models" })),
  ]) {
    let sent = false;
    const r = await run(body, async () => {
      sent = true;
      return Response.json({ data: [] });
    });
    assert.equal(r.status, 400);
    assert.equal(sent, false);
  }
});
test("Google /openai/models uses Bearer in headers, never the URL or body; real auth failures remain actionable", async (t) => {
  const key = "fixture-private";
  let status = 200;
  t.mock.method(globalThis, "fetch", async (url: string, init: RequestInit) => {
    assert.equal(url, google + "/models");
    assert.equal(init.method, "GET");
    assert.equal(new Headers(init.headers).get("authorization"), "Bearer " + key);
    assert.equal(init.body, undefined);
    return status === 200
      ? Response.json({ data: [{ id: "models/gemini-chat" }] })
      : Response.json({ error: { message: "Invalid " + key } }, { status: 401 });
  });
  assert.deepEqual(await testConnection(google, key, "browser"), {
    listed: true,
    ids: ["gemini-chat"],
  });
  status = 401;
  await assert.rejects(testConnection(google, key, "browser"), /HTTP 401 · Invalid \[redacted\]/);
});
