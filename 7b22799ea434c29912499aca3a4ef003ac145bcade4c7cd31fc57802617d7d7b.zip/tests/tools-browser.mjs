// Mobile flow through the real UI. Fixtures intercept every provider/search request before it leaves the browser.
import assert from "node:assert/strict";
import { chromium } from "playwright";
const site = new URL(process.env.SOL_LOCAL_TEST_URL || "http://127.0.0.1:8081");
if (!["localhost", "127.0.0.1"].includes(site.hostname)) throw Error("Use a local preview");
const browser = await chromium.launch(),
  ctx = await browser.newContext({ viewport: { width: 390, height: 844 } }),
  page = await ctx.newPage();
page.setDefaultTimeout(6500);
const or = "https://openrouter.ai/api/v1",
  custom = "https://provider.example.org/team/v1",
  g = "https://generativelanguage.googleapis.com/v1beta/openai",
  nv = "https://integrate.api.nvidia.com/v1",
  groq = "https://api.groq.com/openai/v1";
const ids = {
  [or]: "openai/gpt-5.4-mini",
  [custom]: "local/chat",
  [g]: "gemini-2.5-flash",
  [nv]: "google/gemma-4-31b-it",
  [groq]: "openai/gpt-oss-20b",
};
const searchKey = "fixture-tavily-only",
  modelKey = (x) => "fixture-for-" + new URL(x).hostname;
const searches = [],
  chats = [],
  errors = [],
  bad = [];
page.on("pageerror", (e) => errors.push(e.message));
let rejectNext = false,
  emptyNext = false,
  noCiteNext = false;
const query = "Konark Sun Temple opening hours",
  planned = "Konark Sun Temple Odisha";
const junk = [
  {
    title: "Aquarium opening hours",
    url: "https://example.org/aquarium",
    content: "The aquarium opens later for special events in Boston. See the winter opening hours.",
    score: 0.99,
  },
  {
    title: "Konark Sun Temple opening hours",
    url: "https://blocked.example.org/konark",
    content: "Konark Sun Temple opening hours guide fixture from a blocked forum.",
    score: 0.99,
  },
  {
    title: "Free spins no deposit",
    url: "https://example.org/spam",
    content: "A promotional page repeating Konark Sun Temple and the opening hours.",
    score: 0.99,
  },
];
const math =
  '## Evidence\n\nBacked by [S2]. `[S1]` is a code example. [Invented link](https://unverified.example.com/a). Inline $x^2$; chemistry \\ce{H2O}.\n\n$$\\frac{1}{2}$$\n\n```latex\n\\sqrt{9}\n```\n\n`$cash$`\n\n```txt\n"$literal$"\n```\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n![Not loaded](https://image.example.org/p.png)';
await ctx.route("**/*", async (route) => {
  const req = route.request(),
    url = new URL(req.url()),
    auth = req.headers().authorization || "";
  const reply = (code, body, h = {}) =>
    route.fulfill({
      status: code,
      headers: {
        "content-type": "application/json",
        "access-control-allow-origin": site.origin,
        ...h,
      },
      body: JSON.stringify(body),
    });
  if (
    (url.origin === site.origin && url.pathname === "/api/search") ||
    url.href === "https://api.tavily.com/search"
  ) {
    const b = req.postDataJSON();
    searches.push(b);
    if (
      auth !== "Bearer " + searchKey ||
      req.postData().includes("fixture-for-") ||
      req.postData().includes(searchKey)
    )
      bad.push("search credentials");
    if (rejectNext) {
      rejectNext = false;
      return reply(429, {}, { "x-sol-search": "1" });
    }
    const results = emptyNext
      ? junk
      : [
          ...junk,
          {
            title: "Konark Sun Temple opening hours",
            url: "https://example.org/guide",
            score: 0.98,
            content: "Konark Sun Temple in Odisha publishes opening hours in a visitor guide.",
          },
          {
            title: "Konark Sun Temple · visitor reference",
            url: "https://example.org/source",
            score: 0.82,
            content:
              "The Konark Sun Temple visitor reference contains the opening hours in Odisha. This is the search evidence fixture.",
          },
        ];
    emptyNext = false;
    return reply(200, { results }, { "x-sol-search": "1", "x-sol-search-policy": "2" });
  }
  let target, op, b;
  if (url.origin === site.origin) {
    if (url.pathname !== "/api/chat") return route.continue();
    b = req.postDataJSON();
    target = b.baseUrl;
    op = b.probe ? "models" : "chat";
  } else {
    const t = Object.keys(ids).find(
      (x) => url.href === x + "/models" || url.href === x + "/chat/completions",
    );
    if (!t) {
      bad.push("unexpected URL " + url.origin);
      return route.abort();
    }
    target = t;
    op = req.method() === "GET" ? "models" : "chat";
    b = op === "models" ? {} : req.postDataJSON();
  }
  if ((auth && auth !== "Bearer " + modelKey(target)) || (req.postData() ?? "").includes(searchKey))
    bad.push("LLM credentials");
  const h = { "x-sol-relay": "1" };
  if (op === "models") return reply(200, { data: [{ id: ids[target] }] }, h);
  chats.push({ target, b });
  let content = math;
  let annotations;
  if (String(b.messages[0].content).startsWith("Decide whether"))
    content = String(b.messages[1].content).includes("skip")
      ? '{"search":false}'
      : JSON.stringify({ search: true, query: planned });
  else if (noCiteNext) {
    noCiteNext = false;
    content =
      "## Unverified answer\n\nNo excerpt confirms this. `[S1]` is not a citation. [Invented link](https://unverified.example.com/a).";
  } else if (target === or && b.messages.at(-1).content === "restricted native search") {
    content =
      "## Native evidence\n\n[Document](https://papers.example.net/report) and [invented](https://unverified.example.com/a). Confirmed by the record.";
    annotations = [
      {
        type: "url_citation",
        url_citation: {
          title: "Positional citation",
          url: "https://papers.example.net/record",
          start_index: content.indexOf("Confirmed"),
          end_index: content.length,
        },
      },
      {
        type: "url_citation",
        url_citation: { title: "Uncited suggestion", url: "https://papers.example.net/unrelated" },
      },
      {
        type: "url_citation",
        url_citation: {
          title: "Bad span",
          url: "https://papers.example.net/outside",
          start_index: 800,
          end_index: 900,
        },
      },
      {
        type: "url_citation",
        url_citation: { title: "Approved native source", url: "https://papers.example.net/report" },
      },
      {
        type: "url_citation",
        url_citation: {
          title: "Blocked native source",
          url: "https://blocked.papers.example.net/report",
        },
      },
    ];
  }
  return reply(
    200,
    {
      choices: [
        { message: { content, ...(annotations ? { annotations } : {}) }, finish_reason: "stop" },
      ],
    },
    h,
  );
});
try {
  const btn = (n) => page.getByRole("button", { name: n, exact: true }),
    field = (n) =>
      ["Results per call", "Search behavior", "Search depth"].includes(n)
        ? page.getByRole("combobox", { name: n, exact: true })
        : page.getByLabel(n, { exact: true }),
    provider = field("Provider"),
    model = field("Model"),
    gear = () => btn("Connection settings").click(),
    close = () => btn("Close").click();
  const disk = () => page.evaluate(() => JSON.parse(localStorage.getItem("hearth-v1")).state),
    done = () => btn("Stop").waitFor({ state: "hidden" });
  const send = async (q) => {
    await field("Message").fill(q);
    await btn("Send").click();
  };
  const result = async (n) => {
    await page
      .getByRole("heading", { name: "Evidence", exact: true })
      .nth(n - 1)
      .waitFor();
    await done();
  };
  const budget = () =>
    page.evaluate(() => {
      const t = JSON.parse(localStorage.getItem("hearth-v1")).state.activeThreadId;
      return JSON.parse(localStorage.getItem("sol:search-budget:" + t) || '{"limit":10,"used":0}');
    });
  const searchSettings = () =>
    page.locator("summary").filter({ hasText: "Web search · Tavily" }).click();
  const slider = field("Tavily calls per conversation");
  await page.goto(site.href);
  await page.getByRole("heading", { name: "Start a conversation." }).waitFor();
  await gear();
  await provider.selectOption("custom");
  await field("Base URL").fill(custom + "/chat/completions");
  await field("Base URL").press("Enter");
  await field("Provider name").fill("Workshop");
  await btn("Save provider").click();
  await field("API key").fill(modelKey(custom));
  await model.locator("option").filter({ hasText: "local/chat" }).waitFor({ state: "attached" });
  await searchSettings();
  await field("Tavily API key").fill(searchKey);
  await field("Enable search outside OpenRouter").check();
  await field("Search instructions").fill("Prefer primary sources.");
  await page.locator("summary").filter({ hasText: "Trusted and blocked sites" }).click();
  await field("Only search these domains").fill("example.org");
  await field("Never search these domains").fill("blocked.example.org");
  await field("Results per call").selectOption("4");
  await field("Search depth").selectOption("advanced");
  assert.equal(await slider.getAttribute("min"), "10");
  assert.equal(await slider.getAttribute("max"), "50");
  await slider.press("End");
  await page.getByText(/50 left in this chat/).waitFor();
  await close();
  await page.reload();
  await gear();
  assert.equal(await provider.inputValue(), "saved:" + custom);
  await provider.selectOption("openrouter");
  await provider.selectOption({ label: "Workshop" });
  assert.equal(await field("API key").inputValue(), modelKey(custom));
  await searchSettings();
  assert.equal(await field("Tavily API key").inputValue(), searchKey);
  assert.equal(await slider.inputValue(), "50");
  await slider.press("Home");
  await page.getByText(/10 left in this chat/).waitFor();
  await close();
  await send(query);
  await result(1);
  assert.equal((await budget()).used, 1);
  assert.equal(searches.length, 1);
  assert.equal(searches[0].query, query);
  assert.deepEqual(searches[0].include_domains, ["example.org"]);
  assert.equal(searches[0].search_depth, "advanced");
  assert.equal(searches[0].max_results, 4);
  const evidence = chats.at(-1).b.messages.at(-1).content;
  assert.ok(evidence.includes("search evidence fixture"));
  assert.doesNotMatch(evidence, /aquarium|blocked.example.org|example.org\/spam/);
  const article = page
    .locator("article")
    .filter({ has: page.getByRole("heading", { name: "Evidence" }) })
    .first();
  assert.equal(await article.locator(".katex").count(), 4);
  assert.equal(await article.locator("pre code").innerText(), '"$literal$"\n');
  assert.equal(
    await article.getByRole("link", { name: "S2", exact: true }).getAttribute("href"),
    "https://example.org/source",
  );
  assert.equal(await article.getByRole("table").count(), 1);
  assert.equal(await article.locator("img").count(), 0);
  assert.equal(await article.getByRole("list", { name: "Cited sources" }).locator("a").count(), 1);
  assert.equal(
    await article
      .locator('a[href*="unverified"],a[href*="/guide"],a[href*="/spam"],a[href*="blocked"]')
      .count(),
    0,
  );
  await article.locator("summary").filter({ hasText: "Tavily search query" }).click();
  assert.equal(await article.locator(".sol-query p").innerText(), query);
  const st = await disk(),
    last = st.threads.find((t) => t.id === st.activeThreadId).messages.at(-1);
  assert.deepEqual(last.sources, [
    { url: "https://example.org/source", title: "Konark Sun Temple · visitor reference", id: 2 },
  ]);
  await page.reload();
  await article.getByRole("link", { name: "S2", exact: true }).waitFor();
  assert.equal(await article.locator('a[href*="/guide"]').count(), 0);
  // Simulate a pre-upgrade chat with an uncited first result and no explicit ID field.
  await page.evaluate(() => {
    const snap = JSON.parse(localStorage.getItem("hearth-v1")),
      state = snap.state;
    const msg = state.threads.find((t) => t.id === state.activeThreadId).messages.at(-1);
    msg.sources = [
      { url: "https://example.org/legacy-unused", title: "Old unrelated suggestion" },
      { url: "https://example.org/source", title: "Konark Sun Temple · visitor reference" },
    ];
    delete msg.webQuery;
    localStorage.setItem("hearth-v1", JSON.stringify(snap));
  });
  await page.reload();
  await article.getByRole("link", { name: "S2", exact: true }).waitFor();
  assert.equal(await article.locator('a[href*="legacy-unused"]').count(), 0);
  await gear();
  await searchSettings();
  await field("Search behavior").selectOption("model");
  await close();
  await send("skip lookup");
  await result(2);
  assert.equal(searches.length, 1);
  assert.equal((await budget()).used, 1);
  await page.getByText("The model skipped web search for this reply.").waitFor();
  const priorMessages = JSON.stringify(chats.at(-1).b.messages);
  assert.equal(priorMessages.includes("legacy-unused"), false);
  assert.ok(priorMessages.includes("S2: https://example.org/source"));
  await send("Where is the Konark Sun Temple?");
  await result(3);
  assert.equal(searches.at(-1).query, planned);
  assert.equal((await budget()).used, 2);
  // A follow-up gets only the last actual public query as context, not private chat, files or evidence.
  emptyNext = true;
  const chatBeforeEmpty = chats.length,
    searchBeforeEmpty = searches.length;
  await send("And the opening hours?");
  await page.getByText(/I couldn’t find a source that matched this search/).waitFor();
  await done();
  assert.equal(chats.length, chatBeforeEmpty + 1);
  assert.equal(searches.length, searchBeforeEmpty + 1);
  assert.deepEqual(JSON.parse(chats.at(-1).b.messages[1].content), {
    question: "And the opening hours?",
    previousSearch: planned,
  });
  assert.equal((await budget()).used, 3);
  await page.reload();
  await page.getByText(/I couldn’t find a source that matched this search/).waitFor();
  noCiteNext = true;
  await send("Konark Sun Temple visitor guide");
  await page.getByText("No web source was cited in this answer.").waitFor();
  await done();
  const unverified = page
    .locator("article")
    .filter({ has: page.getByRole("heading", { name: "Unverified answer" }) });
  assert.equal(await unverified.getByRole("link").count(), 0);
  assert.equal((await budget()).used, 4);
  // Move the fixture to the final available slot; regenerate, reload and switching providers must not reset it.
  await page.evaluate(() => {
    const t = JSON.parse(localStorage.getItem("hearth-v1")).state.activeThreadId;
    localStorage.setItem("sol:search-budget:" + t, JSON.stringify({ limit: 10, used: 9 }));
    window.dispatchEvent(new Event("sol-budget"));
  });
  await btn("Regenerate").click();
  await page.getByRole("button", { name: /Tavily settings · 10\/10/ }).waitFor();
  await done();
  const before = chats.length,
    sc = searches.length;
  await send("out of calls");
  await page.getByRole("alert").filter({ hasText: "Search limit reached (10/10)" }).waitFor();
  assert.equal(chats.length, before);
  assert.equal(searches.length, sc);
  await page.reload();
  await gear();
  await searchSettings();
  await slider.press("ArrowRight");
  await page.getByText(/1 left in this chat/).waitFor();
  await close();
  rejectNext = true;
  await send("rate limit check");
  await page.getByRole("alert").filter({ hasText: "Tavily HTTP 429" }).waitFor();
  assert.deepEqual(await budget(), { limit: 11, used: 11 });
  // OpenRouter still works at an exhausted Tavily limit and uses its own web plugin only.
  const tavilyCalls = searches.length;
  await gear();
  await provider.selectOption("openrouter");
  await field("API key").fill(modelKey(or));
  await close();
  await btn("Web search").click();
  await send("native search");
  await result(5);
  await page.getByText("No matching OpenRouter citation for this answer.").waitFor();
  assert.equal(searches.length, tavilyCalls);
  assert.deepEqual(chats.at(-1).b.plugins, [{ id: "web", max_results: 3 }]);
  await btn("OpenRouter search sites").click();
  assert.equal(await field("Only search these domains").inputValue(), "");
  await field("Only search these domains").fill("papers.example.net");
  await field("Never search these domains").fill("blocked.papers.example.net");
  await close();
  await send("restricted native search");
  await page.getByRole("heading", { name: "Native evidence" }).waitFor();
  await done();
  const native = page
    .locator("article")
    .filter({ has: page.getByRole("heading", { name: "Native evidence" }) });
  assert.equal(await native.getByRole("link", { name: "Approved native source" }).count(), 1);
  assert.equal(await native.getByRole("link", { name: "Document", exact: true }).count(), 1);
  assert.equal(await native.getByRole("link", { name: "Positional citation" }).count(), 1);
  assert.equal(await native.locator('a[href*="/outside"],a[href*="/unrelated"]').count(), 0);
  assert.equal(await native.locator('a[href*="unverified"],a[href*="blocked"]').count(), 0);
  assert.deepEqual(chats.at(-1).b.plugins, [
    {
      id: "web",
      max_results: 3,
      engine: "exa",
      include_domains: ["papers.example.net"],
      exclude_domains: ["blocked.papers.example.net"],
    },
  ]);
  assert.equal(searches.length, tavilyCalls);
  await btn("New chat").click();
  await page.getByRole("heading", { name: "Start a conversation." }).waitFor();
  assert.deepEqual(await budget(), { limit: 10, used: 0 });
  for (const [id, base, mode] of [
    ["google", g, "high"],
    ["groq", groq, "low"],
    ["nvidia", nv, "on"],
  ]) {
    await gear();
    await provider.selectOption(id);
    await field("API key").fill(modelKey(base));
    await model.locator("option").filter({ hasText: ids[base] }).waitFor({ state: "attached" });
    await close();
    const reasoning = field("Reasoning mode");
    await reasoning.selectOption(mode);
    if ((await btn("Web search").getAttribute("aria-pressed")) === "true")
      await btn("Web search").click();
    await send("answer " + id);
    await page.waitForFunction(
      (id) =>
        JSON.parse(localStorage.getItem("hearth-v1")).state.threads.some((t) =>
          t.messages.some(
            (m, i) => m.role === "assistant" && t.messages[i - 1]?.content === "answer " + id,
          ),
        ),
      id,
    );
    const b = chats.at(-1).b;
    assert.equal(chats.at(-1).target, base);
    if (id === "nvidia") assert.deepEqual(b.chat_template_kwargs, { enable_thinking: true });
    else assert.equal(b.reasoning_effort, mode);
  }
  await gear();
  await provider.selectOption({ label: "Workshop" });
  await field("Provider name").fill("My endpoint");
  await btn("Save name").click();
  await close();
  await page.reload();
  await gear();
  assert.equal(await provider.locator("option:checked").innerText(), "My endpoint");
  await btn("Remove provider").click();
  await btn("Confirm removal").click();
  assert.equal((await disk()).customProviders[custom], undefined);
  assert.equal((await disk()).connections[custom], undefined);
  await searchSettings();
  await btn("Forget Tavily key").click();
  assert.equal((await disk()).search.apiKey, undefined);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  assert.deepEqual(errors, []);
  assert.deepEqual(bad, []);
  console.log(
    "PASS: safe/relevant retrieval, restricted sites, sparse citation IDs, unverified links suppressed, no-source abstention, OpenRouter annotations/site filters; named endpoints, key isolation, per-chat 10–50 slider/ceiling across retries, failure and reload; planner skip/search; native OpenRouter bypass; all three reasoning transports; Marked/KaTeX/mhchem, clickable source IDs, code and tables.",
  );
} finally {
  await browser.close();
}
