import { test } from "node:test";
import assert from "node:assert/strict";
import { rankHits } from "../src/lib/sol/search-ranking.ts";
import { sourceUrl, siteRules, domainList } from "../src/lib/sol/source-policy.ts";
import { focusedQuery, missingSubject } from "../src/lib/sol/search-query.ts";
import { fetchSearch, relaySearchBody, searchBody, TAVILY_URL } from "../src/lib/sol/tavily.ts";
import { searchRelay } from "../src/lib/sol/search-relay.server.ts";
import { relayChat } from "../src/lib/sol/relay.ts";
import { DEFAULT_SETTINGS, type Character } from "../src/lib/sol/types.ts";
import { DEFAULT_SEARCH } from "../src/lib/sol/search-settings.ts";
import { buildPayload, type WireMessage } from "../src/lib/sol/protocol.ts";
import { parseDecision, prepareLookup } from "../src/lib/sol/grounding.ts";
import { toApiMessages } from "../src/lib/sol/prompt.ts";
const signal = new AbortController().signal;
const q = "Konark Sun Temple opening hours Odisha";
const good = {
  title: "Konark Sun Temple · visitor hours",
  url: "https://heritage.example.org/konark?lang=en&utm_source=ad#hours",
  content: "The visitor information for Konark Sun Temple in Odisha lists opening hours by season.",
  score: 0.94,
};
const guide = {
  title: "Konark Sun Temple in Odisha",
  url: "https://museum.example.org/guide",
  content: "Our visitor guide includes the hours for the heritage site in Odisha.",
  score: 0.83,
};
const bad = [
  {
    title: "Opening hours and ticket prices",
    url: "https://museum.example.org/boston",
    content: "Opening hours for Boston boat tours are extended in the summer.",
    score: 0.99,
  },
  { ...good, title: "Watch free xxx videos", url: "https://example.org/unfit", score: 0.99 },
  { ...good, url: "https://example.xxx/temple" },
  { ...good, url: "https://bit.ly/opaque" },
  { ...good, url: "https://blocked.example.org/konark" },
  { ...good, url: "https://heritage.example.org.fakesite.com/konark" },
  { ...good, score: 0.14, url: "https://museum.example.org/keyword-spam" },
  { ...good, url: "javascript:void(0)" },
  {
    ...good,
    title: "News",
    content: "An unrelated calendar of school events.",
    url: "https://museum.example.org/wrong",
    score: 0.99,
  },
];
const rules = siteRules("example.org", "blocked.example.org");
const results = [
  ...bad,
  { ...good, score: 0.81, url: "https://heritage.example.org/konark?lang=en&utm_source=other" },
  guide,
  good,
];
const cfg = {
  ...DEFAULT_SEARCH,
  apiKey: "tavily-fixture",
  enabled: true,
  allowSites: "example.org",
  blockSites: "blocked.example.org",
};
const clean = "https://heritage.example.org/konark?lang=en#hours";
const llm = {
  ...DEFAULT_SETTINGS,
  baseUrl: "https://model.example.org/v1",
  apiKey: "model-fixture",
  model: "chat",
};
const wire: WireMessage[] = [
  { role: "user", content: "private chat content not for the search engine" },
];
const req = (path: string, body: unknown, auth = "tavily-fixture") =>
  new Request("https://sol.example/" + path, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: "Bearer " + auth },
    body: JSON.stringify(body),
  });

test("filters off-topic matches on generic hours, adult landing pages, weak scores, shorteners, blocked and deceptive hosts; does not pad the limit", () => {
  const hits = rankHits({ results }, 5, q, rules);
  assert.deepEqual(
    hits.map((h) => h.url),
    [clean, guide.url],
  );
  assert.equal(hits[0].score, 0.94);
  assert.deepEqual(rankHits({ results: bad }, 5, q, rules), []);
  assert.deepEqual(rankHits({ results: hits }, 5, q, rules), hits);
});
test("missing scores need stronger topical evidence; quoted phrases and Unicode survive; no out-of-window evidence", () => {
  assert.deepEqual(
    rankHits({ results: [{ ...good, score: undefined }] }, 3, q).map((x) => x.url),
    [clean],
  );
  assert.deepEqual(
    rankHits(
      {
        results: [
          {
            ...good,
            title: "Museum news",
            content: "The museum hosts a visitor event in Odisha.",
            score: undefined,
          },
        ],
      },
      3,
      q,
    ),
    [],
  );
  assert.deepEqual(
    rankHits(
      {
        results: [
          { ...good, title: "Konark Sun Temple", content: "x".repeat(1250) + "accessible ramp" },
        ],
      },
      3,
      'Konark "accessible ramp"',
    ),
    [],
  );
  const odia = {
    title: "କୋଣାର୍କ ସୂର୍ଯ୍ୟ ମନ୍ଦିର",
    content: "ଓଡ଼ିଶାର କୋଣାର୍କ ସୂର୍ଯ୍ୟ ମନ୍ଦିର ବିଷୟରେ ସୂଚନା।",
    url: good.url,
    score: 0.9,
  };
  assert.equal(rankHits({ results: [odia] }, 3, "କୋଣାର୍କ ସୂର୍ଯ୍ୟ ମନ୍ଦିର").length, 1);
  assert.deepEqual(
    rankHits(
      {
        results: [
          {
            ...good,
            title: "Different book in 2026",
            content: "A collection of recipes published in 2026.",
          },
        ],
      },
      3,
      "Odisha 2026",
    ),
    [],
  );
});
test("domain boundaries are literal, block wins, invalid/empty input cannot broaden a restricted request", () => {
  assert.deepEqual(domainList("Example.Org, *.example.org.\n museum.example.org"), [
    "example.org",
    "museum.example.org",
  ]);
  assert.equal(sourceUrl(clean, rules), clean);
  assert.equal(sourceUrl("https://example.org.evilexample.com/", rules), undefined);
  assert.equal(sourceUrl("https://sub.blocked.example.org/", rules), undefined);
  assert.equal(sourceUrl("https://name:pwd@example.org/", rules), undefined);
  assert.throws(() => siteRules("https://example.org/path"));
  assert.throws(() => siteRules("museum.example.org", "example.org"));
  assert.throws(() => domainList(Array.from({ length: 13 }, (_, i) => "m" + i + ".example.org")));
  assert.equal("include_domains_mode" in searchBody(q, "basic", 4), false);
});
for (const direct of [true, false])
  test(`${direct ? "direct" : "relay round trip"}: a single fixed Safe Search POST, bounded candidates, identical accepted IDs and no model credential`, async (t) => {
    const posted: Record<string, unknown>[] = [];
    const upstream: typeof fetch = async (url, init) => {
      assert.equal(String(url), TAVILY_URL);
      assert.equal(new Headers(init?.headers).get("authorization"), "Bearer tavily-fixture");
      posted.push(JSON.parse(String(init?.body)));
      return Response.json({ results, answer: "not model evidence" });
    };
    t.mock.method(globalThis, "fetch", async (url: RequestInfo | URL, init?: RequestInit) =>
      String(url) === "/api/search"
        ? searchRelay(new Request("https://sol.example/api/search", init), upstream)
        : upstream(url, init),
    );
    const hits = await fetchSearch(q, cfg, direct, signal);
    assert.deepEqual(
      hits.map((x) => x.url),
      [clean, guide.url],
    );
    assert.equal(posted.length, 1);
    assert.deepEqual(posted[0], {
      query: q,
      search_depth: "basic",
      max_results: 6,
      safe_search: true,
      include_answer: false,
      include_images: false,
      include_raw_content: false,
      auto_parameters: false,
      include_domains: ["example.org"],
      include_domains_mode: "restrict",
      exclude_domains: ["blocked.example.org"],
    });
    assert.doesNotMatch(
      JSON.stringify(posted),
      /model-fixture|tavily-fixture|private chat content/,
    );
  });
test("old relay cannot silently search without Safe Search; invalid site lists do not reach Tavily", async (t) => {
  t.mock.method(globalThis, "fetch", async () =>
    Response.json({ results: [good] }, { headers: { "x-sol-search": "1" } }),
  );
  await assert.rejects(fetchSearch(q, cfg, false, signal), /requires Safe Search/);
  let sent = false;
  const res = await searchRelay(
    req("api/search", { ...relaySearchBody(q, "basic", 3), include_domains: ["invalid/path"] }),
    async () => {
      sent = true;
      return Response.json({});
    },
  );
  assert.equal(res.status, 400);
  assert.equal(sent, false);
});
test("planner drift uses the original question, retains explicit version and quotes, resolves only a known subject", () => {
  assert.equal(focusedQuery(q, "Boston opening hours"), q);
  const v = 'Does Python 3.13 support "tomllib"?';
  assert.equal(focusedQuery(v, "Python tomllib 3.10"), v);
  assert.equal(
    focusedQuery(v, "Python 3.13 TOMLLIB documentation"),
    "Python 3.13 TOMLLIB documentation",
  );
  assert.equal(missingSubject("Tell me more about it?"), true);
  assert.equal(
    focusedQuery("And the opening hours?", "Konark temple visiting hours", q),
    "Konark temple visiting hours",
  );
  assert.throws(
    () => focusedQuery("And the opening hours?", "Boston museum hours", q),
    /What should I look up/,
  );
  assert.throws(() => parseDecision('{"clarify":true}'), /No search call was used/);
});
test("no match is a first-class outcome, not evidence; missing subject, credentials and invalid lists use no dispatch", async () => {
  const log: string[] = [];
  const io = {
    budget: () => ({ limit: 10, used: 1 }),
    reserve: async () => {
      log.push("reserve");
      return { limit: 10, used: 2 };
    },
    plan: async () => {
      log.push("planner");
      return q;
    },
    search: async () => {
      log.push("search");
      return [];
    },
  };
  const run = (question: string, c = cfg) =>
    prepareLookup(llm, c, "t", question, wire, signal, () => {}, io);
  for (const [question, c] of [
    ["What about it?", cfg],
    [q, { ...cfg, allowSites: "bad/path" }],
    ["look up model-fixture", cfg],
  ] as const)
    await assert.rejects(run(question, c));
  assert.deepEqual(log, []);
  const out = await run(q);
  assert.equal(out.kind, "no-sources");
  assert.equal(out.wire, wire);
  assert.equal(out.query, q);
  assert.deepEqual(log, ["reserve", "search"]);
});
test("earlier cited evidence retains its original ID and destination in model history", async () => {
  const ch: Character = {
    id: "sol:plain",
    name: "sol",
    tagline: "",
    description: "",
    personality: "",
    scenario: "",
    firstMessage: "",
    example: "",
    extra: "",
    hue: 10,
  };
  const m = await toApiMessages(ch, llm, [
    {
      id: "a",
      role: "assistant",
      content: "Reference [S3].",
      webLookup: "tavily",
      sources: [{ id: 3, url: clean, title: good.title }],
    },
  ]);
  assert.match(String(m[0].content), /S3: https:\/\/heritage/);
  assert.doesNotMatch(String(m[0].content), /S1:/);
});
test("OpenRouter defaults unchanged; optional independent domains use one Exa plugin on direct AND relay, never Tavily settings", async () => {
  const online = { ...DEFAULT_SETTINGS, model: "example/model:free:online" };
  assert.equal(buildPayload(online, wire).plugins, undefined);
  assert.deepEqual(buildPayload({ ...DEFAULT_SETTINGS, webSearch: true }, wire).plugins, [
    { id: "web", max_results: 3 },
  ]);
  const direct = buildPayload(
    { ...online, routerAllowSites: "university.edu", routerBlockSites: "forum.university.edu" },
    wire,
  );
  assert.equal(direct.model, "example/model:free");
  assert.deepEqual(direct.plugins, [
    {
      id: "web",
      max_results: 3,
      engine: "exa",
      include_domains: ["university.edu"],
      exclude_domains: ["forum.university.edu"],
    },
  ]);
  const r = await relayChat(
    req("api/chat", { ...direct, baseUrl: online.baseUrl }, "model-fixture"),
    async (url, init) => {
      assert.equal(String(url), online.baseUrl + "/chat/completions");
      assert.deepEqual(JSON.parse(String(init.body)), direct);
      return Response.json({});
    },
  );
  assert.equal(r.status, 200);
  assert.equal(
    buildPayload({ ...llm, routerAllowSites: "invalid/path", webSearch: true }, wire).plugins,
    undefined,
  );
});
