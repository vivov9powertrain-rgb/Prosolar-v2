import test from "node:test";
import assert from "node:assert/strict";
import { buildPayload, presetBase, safeLink, MAX_BODY } from "../src/lib/sol/protocol.ts";
import { readReply } from "../src/lib/sol/replies.ts";
import { relayChat } from "../src/lib/sol/relay.ts";
import { prepareFiles } from "../src/lib/sol/files.ts";
import { DEFAULT_SETTINGS } from "../src/lib/sol/types.ts";
const baseUrl = "https://openrouter.ai/api/v1";
const s = {
  ...DEFAULT_SETTINGS,
  baseUrl,
  model: "test/model",
  highReasoning: true,
  webSearch: true,
  streaming: false,
};
const chat = [{ role: "user" as const, content: "Hello" }];
const pdf = {
  type: "file" as const,
  file: { filename: "paper.pdf", file_data: "data:application/pdf;base64,JVBERi0=" },
};
test("request options compose; other providers are not given OpenRouter-only fields", () => {
  const p = buildPayload(s, [{ role: "user", content: [pdf] }]);
  assert.equal(p.stream, false);
  assert.equal(p.max_tokens, s.maxTokens);
  assert.equal(p.reasoning?.effort, "high");
  assert.deepEqual(
    p.plugins?.map((v) => v.id),
    ["web", "file-parser"],
  );
  assert.equal(p.temperature, undefined);
  const q = buildPayload({ ...s, baseUrl: "https://api.openai.com/v1" }, chat);
  assert.equal(q.reasoning, undefined);
  assert.equal(q.plugins, undefined);
  assert.equal(q.temperature, s.temperature);
  assert.throws(
    () =>
      buildPayload({ ...s, baseUrl: "https://api.openai.com/v1" }, [
        { role: "user", content: [pdf] },
      ]),
    /OpenRouter/,
  );
  assert.equal(buildPayload({ ...s, model: "test:online" }, chat).plugins, undefined);
  assert.equal(
    buildPayload({ ...s, webSearch: false, highReasoning: false }, chat).reasoning,
    undefined,
  );
});
test("canonical endpoints, safe sources and legacy defaults", () => {
  assert.equal(presetBase(baseUrl + "/chat/completions/"), baseUrl);
  assert.equal(presetBase("https://example.org/v1"), undefined);
  assert.equal(safeLink("javascript:void(0)"), undefined);
  assert.equal(safeLink("https://example.org/guide"), "https://example.org/guide");
  assert.equal(DEFAULT_SETTINGS.streaming, true);
  assert.equal(DEFAULT_SETTINGS.highReasoning, false);
});
const cite = {
  type: "url_citation",
  url_citation: { title: "Guide", url: "https://example.org/guide" },
};
test("split UTF-8 SSE, heartbeats, CRLF, trailing frame, sources without duplicates", async () => {
  const raw =
    ": ping\r\n\r\n" +
    [
      { delta: { reasoning: "not an answer" } },
      { delta: { content: "Rain ☔" } },
      { delta: { content: " clears.", annotations: [cite, cite] } },
      { delta: {}, finish_reason: "stop" },
    ]
      .map((c) => "data: " + JSON.stringify({ choices: [c] }) + "\r\n\r\n")
      .join("") +
    "data: [DONE]";
  const buf = new TextEncoder().encode(raw);
  let n = 0;
  const stream = new ReadableStream({
    pull(c) {
      if (n < buf.length) {
        c.enqueue(buf.slice(n, n + 2));
        n += 2;
      } else c.close();
    },
  });
  let out = "",
    count = 0,
    thinking = 0;
  await readReply(new Response(stream, { headers: { "content-type": "text/event-stream" } }), {
    onDelta: (s) => (out += s),
    onSources: (s) => (count = s.length),
    onThinking: () => thinking++,
  });
  assert.equal(out, "Rain ☔ clears.");
  assert.equal(count, 1);
  assert.equal(thinking, 1);
});
test("non-streaming JSON returns answer only plus safe sources; empty, length and upstream errors are actionable", async () => {
  let out = "",
    n = 0;
  await readReply(
    Response.json({
      choices: [
        {
          message: {
            content: "Answer",
            reasoning: "not text to display",
            annotations: [cite, { type: "url_citation", url_citation: { url: "data:,x" } }],
          },
          finish_reason: "stop",
        },
      ],
    }),
    { onDelta: (s) => (out += s), onSources: (v) => (n = v.length) },
  );
  assert.equal(out, "Answer");
  assert.equal(n, 1);
  for (const [packet, expected] of [
    [{ error: { message: "Insufficient credits" } }, /credits/],
    [{ choices: [{ message: { content: "" }, finish_reason: "length" }] }, /limit/],
    [{ choices: [] }, /No answer/],
  ] as const)
    await assert.rejects(readReply(Response.json(packet), { onDelta() {} }), expected);
});
test("interrupted streams keep partial text and report interruption", async () => {
  let text = "";
  await assert.rejects(
    readReply(
      new Response('data: {"choices":[{"delta":{"content":"partial"}}]}\n\n', {
        headers: { "content-type": "text/event-stream" },
      }),
      { onDelta: (s) => (text += s) },
    ),
    /ended before/,
  );
  assert.equal(text, "partial");
});
function req(body: unknown) {
  return new Request("https://example.org/api/chat", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}
test("relay preserves both response modes, search, reasoning, and inline files; drops credentials from body", async () => {
  for (const streaming of [false, true]) {
    const p = buildPayload({ ...s, streaming }, [{ role: "user", content: [pdf] }]);
    let called = false;
    const res = await relayChat(req({ ...p, baseUrl, apiKey: "test-only" }), async (url, init) => {
      called = true;
      assert.equal(url, baseUrl + "/chat/completions");
      assert.deepEqual(JSON.parse(String(init?.body)), p);
      assert.equal(init?.redirect, "error");
      return new Response("ok", {
        headers: { "content-type": streaming ? "text/event-stream" : "application/json" },
      });
    });
    assert.equal(res.status, 200);
    assert.equal(called, true);
    assert.match(res.headers.get("cache-control") || "", /no-store/);
  }
});
test("invalid attachment, oversize, missing fields and private relay destination rejected before upstream", async () => {
  const p = { ...buildPayload(s, chat), baseUrl, apiKey: "test-only" };
  for (const b of [
    null,
    { ...p, baseUrl: "http://localhost/v1" },
    {
      ...p,
      messages: [
        {
          role: "user",
          content: [{ type: "image_url", image_url: { url: "https://example.org/image" } }],
        },
      ],
    },
  ])
    assert.equal(
      (
        await relayChat(req(b), async () => {
          throw Error("unexpected");
        })
      ).status,
      400,
    );
  assert.equal((await relayChat(req({ ...p, extra: "a".repeat(MAX_BODY) }))).status, 413);
});
test("file picker limits, supported formats, signatures and PDF provider gate", async () => {
  const f = new File(["hello"], "notes.md");
  assert.equal((await prepareFiles([f], [], true))[0].ref.kind, "text");
  await assert.rejects(prepareFiles([new File(["abc"], "book.pdf")], [], true), /file type/);
  await assert.rejects(prepareFiles([new File(["%PDF-1.4"], "book.pdf")], [], false), /OpenRouter/);
  await assert.rejects(prepareFiles([new File(["a"], "doc.docx")], [], true), /Unsupported/);
  await assert.rejects(prepareFiles(Array(4).fill(f), [], true), /3 files/);
  await assert.rejects(
    prepareFiles([new File(["a".repeat(2 * 1024 * 1024 + 1)], "n.pdf")], [], true),
    /2 MiB/,
  );
  await assert.rejects(
    prepareFiles([new File([new Uint8Array([255, 255])], "n.txt")], [], true),
    /UTF-8/,
  );
});
