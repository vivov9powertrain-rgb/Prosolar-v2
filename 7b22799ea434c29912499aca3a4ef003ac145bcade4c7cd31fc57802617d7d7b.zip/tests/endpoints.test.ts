import assert from "node:assert/strict";
import test from "node:test";
import { apiBase, endpoint, sameApi, relayEligible } from "../src/lib/sol/endpoints.ts";
import { routeFor } from "../src/lib/sol/complete.ts";
import { pickAddress, publicAddress } from "../src/lib/sol/public-provider.server.ts";
import { relayChat } from "../src/lib/sol/relay.ts";
import { buildPayload } from "../src/lib/sol/protocol.ts";
import { DEFAULT_SETTINGS } from "../src/lib/sol/types.ts";
const nv = "https://integrate.api.nvidia.com/v1",
  z = "https://api.z.ai/api/paas/v4",
  custom = "https://provider.example.org/openai/v1";
for (const base of [nv, z, "https://generativelanguage.googleapis.com/v1beta/openai", custom])
  test(`base, models and completion URL select the same relay for ${new URL(base).hostname}`, async () => {
    for (const raw of [
      base,
      base + "/",
      base + "/models",
      base + "/chat/completions",
      base + "/chat/completions/",
    ]) {
      assert.equal(apiBase(raw), base);
      assert.equal(sameApi(raw, base), true);
      assert.equal(routeFor(raw, "auto"), "relay");
      assert.equal(routeFor(raw, "browser"), "browser");
      for (const stream of [true, false]) {
        const p = buildPayload(
          {
            ...DEFAULT_SETTINGS,
            baseUrl: raw,
            model: "fixture/model",
            streaming: stream,
            highReasoning: true,
            webSearch: true,
          },
          [{ role: "user", content: "test" }],
        );
        const req = new Request("https://sol.example.org/api/chat", {
          method: "POST",
          headers: { Authorization: "Bearer fixture-only", "Content-Type": "application/json" },
          body: JSON.stringify({ baseUrl: raw, ...p }),
        });
        let sent = 0;
        const response = await relayChat(req, async (url, init) => {
          sent++;
          assert.equal(url, endpoint(base, "chat/completions"));
          assert.equal(init.method, "POST");
          const wire = JSON.parse(String(init.body));
          assert.equal(wire.stream, stream);
          assert.equal(wire.apiKey, undefined);
          assert.equal(wire.reasoning, undefined);
          assert.equal(wire.plugins, undefined);
          assert.equal(new Headers(init.headers).get("authorization"), "Bearer fixture-only");
          return new Response(stream ? "data: [DONE]\n\n" : "{}", {
            headers: { "content-type": stream ? "text/event-stream" : "application/json" },
          });
        });
        assert.equal(response.status, 200);
        assert.equal(response.headers.get("x-sol-relay"), "1");
        assert.equal(sent, 1);
      }
    }
  });
test("local APIs stay browser-only; explicit relay requires standard public HTTPS", () => {
  for (const raw of [
    "http://localhost:11434/v1",
    "https://localhost/v1",
    "https://127.0.0.1/",
    "https://provider.example.org:8080/v1",
  ]) {
    assert.equal(relayEligible(raw), false);
    assert.equal(routeFor(raw), "browser");
    assert.throws(() => routeFor(raw, "relay"), /public HTTPS/);
  }
  for (const raw of [
    "https://me:pw@provider.example.org/v1",
    "https://provider.example.org/v1?key=test",
    "https://provider.example.org/v1#path",
  ])
    assert.throws(() => apiBase(raw));
  assert.equal(routeFor(DEFAULT_SETTINGS.baseUrl), "browser");
  assert.equal(routeFor(DEFAULT_SETTINGS.baseUrl, "relay"), "relay");
});
test("pinned transport rejects empty, private, reserved, and mixed DNS results", () => {
  for (const ip of [
    "127.0.0.1",
    "10.1.1.1",
    "100.64.0.1",
    "169.254.1.1",
    "172.16.0.1",
    "192.168.1.1",
    "198.18.1.1",
    "224.0.0.1",
    "::1",
    "::",
    "fc00::1",
    "fe80::1",
    "::ffff:127.0.0.1",
    "2001:db8::1",
    "2002::1",
    "64:ff9b::1",
  ])
    assert.equal(publicAddress(ip), false, ip);
  assert.equal(publicAddress("8.8.8.8"), true);
  assert.equal(publicAddress("2606:4700:4700::1111"), true);
  assert.throws(() => pickAddress([]));
  assert.throws(() =>
    pickAddress([
      { address: "8.8.8.8", family: 4 },
      { address: "10.0.0.1", family: 4 },
    ]),
  );
});
test("an HTTP auth error stays an auth error, without echoing credentials", async () => {
  const req = new Request("https://sol.example.org/api/chat", {
    method: "POST",
    headers: { Authorization: "Bearer fixture-only", "Content-Type": "application/json" },
    body: JSON.stringify({ baseUrl: z + "/chat/completions", probe: "models" }),
  });
  const res = await relayChat(req, async (url, init) => {
    assert.equal(url, z + "/models");
    assert.equal(init.method, "GET");
    assert.equal(init.body, undefined);
    return Response.json({ error: { message: "Invalid key: fixture-only" } }, { status: 401 });
  });
  assert.equal(res.status, 401);
  assert.doesNotMatch(await res.text(), /fixture-only/);
});
test("cross-site browser requests and destinations excluded by deployment policy do not call upstream", async () => {
  const prior = process.env.SOL_RELAY_BASE_URLS;
  process.env.SOL_RELAY_BASE_URLS = "https://trusted.example.org/v1";
  let called = false;
  try {
    for (const [baseUrl, origin] of [
      [custom, "https://sol.example.org"],
      [nv, "https://different.example.org"],
    ]) {
      const r = await relayChat(
        new Request("https://sol.example.org/api/chat", {
          method: "POST",
          headers: {
            Authorization: "Bearer fixture-only",
            "Content-Type": "application/json",
            Origin: origin,
          },
          body: JSON.stringify({ baseUrl, probe: "models" }),
        }),
        async () => {
          called = true;
          return Response.json({ data: [] });
        },
      );
      assert.equal(r.status, 403);
    }
    assert.equal(called, false);
  } finally {
    if (prior === undefined) delete process.env.SOL_RELAY_BASE_URLS;
    else process.env.SOL_RELAY_BASE_URLS = prior;
  }
});
