import test from "node:test";
import assert from "node:assert/strict";
import {
  reasonRule,
  reasonFields,
  modeFor,
  modeKey,
  modeFromWire,
} from "../src/lib/sol/reasoning.ts";
import { buildPayload, type WireMessage } from "../src/lib/sol/protocol.ts";
import { DEFAULT_SETTINGS } from "../src/lib/sol/types.ts";
import { relayChat } from "../src/lib/sol/relay.ts";
import { searchRelay } from "../src/lib/sol/search-relay.server.ts";
import { hitsFrom, relaySearchBody, searchBody, TAVILY_URL } from "../src/lib/sol/tavily.ts";
import { DEFAULT_SEARCH } from "../src/lib/sol/search-settings.ts";
import { budgetFrom, available } from "../src/lib/sol/search-budget.ts";
import { groundingMessages, parseDecision, prepareLookup } from "../src/lib/sol/grounding.ts";
import { namedProvider, restoreProviders } from "../src/lib/sol/custom-providers.ts";
import { deviceForDisk, restoreDevice } from "../src/lib/sol/connections.ts";
const google = "https://generativelanguage.googleapis.com/v1beta/openai",
  groq = "https://api.groq.com/openai/v1",
  nv = "https://integrate.api.nvidia.com/v1",
  custom = "https://provider.example.org/team/v1",
  or = DEFAULT_SETTINGS.baseUrl;
const wire: WireMessage[] = [{ role: "user", content: "Which sources are recent?" }],
  s = { ...DEFAULT_SETTINGS, baseUrl: google, model: "gemini-2.5-flash", apiKey: "llm-fixture" },
  cfg = { ...DEFAULT_SEARCH, apiKey: "tavily-fixture", enabled: true },
  hit = {
    title: "Transit news",
    url: "https://example.org/article",
    content: "Quoted evidence about the transit news bulletin.",
  };
const request = (body: unknown, headers: Record<string, string> = {}) =>
  new Request("https://sol.example/api/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer tavily-fixture",
      ...headers,
    },
    body: JSON.stringify(body),
  });
for (const [base, model, mode, fields] of [
  [groq, "openai/gpt-oss-20b", "high", { reasoning_effort: "high", include_reasoning: false }],
  [groq, "qwen/qwen3.8-27b", "medium", { reasoning_effort: "medium", reasoning_format: "hidden" }],
  [google, "gemini-2.5-flash", "none", { reasoning_effort: "none" }],
  [google, "gemini-3.1-pro-preview", "high", { reasoning_effort: "high" }],
  [
    nv,
    "nvidia/nemotron-3-super-120b-a12b",
    "on",
    { chat_template_kwargs: { enable_thinking: true } },
  ],
  [nv, "google/gemma-4-31b-it", "none", { chat_template_kwargs: { enable_thinking: false } }],
  [nv, "openai/gpt-oss-20b", "low", { reasoning_effort: "low" }],
] as const)
  test(`${model} ${mode}: direct and relay wire agree`, async () => {
    assert.deepEqual(reasonFields(base, model, mode), fields);
    assert.equal(modeFromWire(base, model, fields), mode);
    const p = buildPayload(
      { ...s, baseUrl: base, model, reasoningModes: { [modeKey(base, model)]: mode } },
      wire,
    );
    let calls = 0;
    const r = await relayChat(
      request({ ...p, baseUrl: base }, { Authorization: "Bearer llm-fixture" }),
      async (url, init) => {
        calls++;
        assert.equal(url, base + "/chat/completions");
        assert.equal(new Headers(init.headers).get("Authorization"), "Bearer llm-fixture");
        const w = JSON.parse(String(init.body));
        assert.deepEqual(w, p);
        assert.equal(w[base === groq ? "max_completion_tokens" : "max_tokens"], s.maxTokens);
        return Response.json({});
      },
    );
    assert.equal(r.status, 200);
    assert.equal(calls, 1);
  });
test("no provider fields on unknown endpoints/models; model-specific unsupported modes rejected", () => {
  for (const [base, model] of [
    [nv, "google/gemma-3-12b-it"],
    [groq, "llama-3.3-70b-versatile"],
    [custom, "gemini-2.5-flash"],
  ]) {
    assert.equal(reasonRule(base, model), undefined);
    assert.equal(modeFor(base, model, { [modeKey(base, model)]: "high" }), "default");
    assert.deepEqual(reasonFields(base, model, "default"), {});
  }
  assert.throws(() => reasonFields(google, "gemini-3-pro-preview", "medium"));
  assert.throws(() => reasonFields(google, "gemini-2.5-pro", "none"));
  assert.throws(() =>
    modeFromWire(nv, "google/gemma-4-31b-it", {
      chat_template_kwargs: { enable_thinking: true, extra: "not accepted" },
    }),
  );
});
test("fixed Tavily relay forwards only a single allowlisted search payload, returns bounded safe evidence", async () => {
  const r = await searchRelay(
    request({
      ...relaySearchBody(" recent news ", "advanced", 2),
      safe_search: false,
      baseUrl: "https://other.example.org",
      messages: wire,
      apiKey: "not-forwarded",
      include_raw_content: true,
    }),
    async (url, init) => {
      assert.equal(url, TAVILY_URL);
      assert.equal(init?.redirect, "error");
      assert.equal(new Headers(init?.headers).get("Authorization"), "Bearer tavily-fixture");
      assert.deepEqual(JSON.parse(String(init?.body)), searchBody("recent news", "advanced", 2));
      return Response.json({
        answer: "not forwarded",
        results: [
          { ...hit, url: "file:///private" },
          hit,
          hit,
          { ...hit, url: "https://example.org/b", content: "x".repeat(2000) },
        ],
      });
    },
  );
  assert.equal(r.status, 200);
  const data = await r.json();
  assert.equal(data.results.length, 2);
  assert.equal(data.results[1].content.length, 1200);
  assert.equal(data.answer, undefined);
  assert.equal(r.headers.get("x-sol-search"), "1");
});
test("invalid/cross-site search requests rejected before network, auth errors never echo a key", async () => {
  const body = relaySearchBody("test", "basic", 3);
  for (const [req, status] of [
    [request(body, { Authorization: "" }), 401],
    [request(body, { Origin: "https://else.example" }), 403],
    [request({ ...body, max_results: 50 }), 400],
    [request({ ...body, query: "a".repeat(500) }), 400],
    [request({ ...body, data: "a".repeat(12000) }), 413],
  ] as const) {
    let sent = false;
    const res = await searchRelay(req, async () => {
      sent = true;
      return Response.json({});
    });
    assert.equal(res.status, status);
    assert.equal(sent, false);
  }
  const denied = await searchRelay(
    request(body),
    async () => new Response("secret tavily-fixture", { status: 401 }),
  );
  assert.equal(denied.status, 401);
  assert.doesNotMatch(await denied.text(), /tavily-fixture/);
});
test("OpenRouter and search off bypass Tavily, planner and conversation ledger entirely", async () => {
  const io = {
    budget: () => {
      throw Error("unexpected");
    },
    reserve: async () => {
      throw Error();
    },
    plan: async () => {
      throw Error();
    },
    search: async () => {
      throw Error();
    },
  };
  for (const [settings, config] of [
    [{ ...s, baseUrl: or, webSearch: true }, cfg],
    [s, { ...cfg, enabled: false }],
  ] as const) {
    const v = await prepareLookup(
      settings,
      config,
      "a",
      "hello",
      wire,
      new AbortController().signal,
      () => {},
      io,
    );
    assert.deepEqual(v, { wire, hits: [] });
  }
});
test("model-led skip uses no search slot; real lookup reserves exactly once before dispatch; evidence is user-role data", async () => {
  const log: string[] = [];
  let decision: string | null = null;
  const io = {
    budget: () => ({ limit: 12, used: 3 }),
    plan: async () => {
      log.push("plan");
      return decision;
    },
    reserve: async () => {
      log.push("reserve");
      return { limit: 12, used: 4 };
    },
    search: async (q: string) => {
      assert.equal(q, "public transit timetable");
      log.push("search");
      return [hit];
    },
  };
  const go = () =>
    prepareLookup(
      s,
      { ...cfg, strategy: "model" },
      "thread",
      "latest transit report",
      wire,
      new AbortController().signal,
      () => {},
      io,
    );
  assert.equal((await go()).kind, "skipped");
  assert.deepEqual(log, ["plan"]);
  log.length = 0;
  decision = "public transit timetable";
  const v = await go();
  assert.equal(v.kind, "tavily");
  assert.deepEqual(log, ["plan", "reserve", "search"]);
  assert.match(String(v.wire[0].content), /untrusted/);
  assert.doesNotMatch(String(v.wire[0].content), /Quoted evidence/);
  assert.match(String(v.wire.at(-1)?.content), /Quoted evidence/);
  assert.deepEqual(wire, [{ role: "user", content: "Which sources are recent?" }]);
  io.budget = () => ({ limit: 10, used: 10 });
  log.length = 0;
  await assert.rejects(go(), /Search limit reached/);
  assert.deepEqual(log, []);
});
test("attachment data is never the search query; grounding preserves multimodal parts and handles unsafe sources", () => {
  const original: WireMessage[] = [
    { role: "system", content: "Profile" },
    {
      role: "user",
      content: [
        { type: "text", text: "my question" },
        { type: "image_url", image_url: { url: "data:image/png;base64,QUJD" } },
      ],
    },
  ];
  const out = groundingMessages(original, [hit], "Use primary sources");
  assert.equal(out.length, 2);
  assert.match(String(out[0].content), /Use primary sources/);
  assert.ok(Array.isArray(out[1].content));
  assert.deepEqual(out[1].content[1], (original[1].content as unknown[])[1]);
  assert.deepEqual(hitsFrom({ results: [{ url: "data:,x", content: "x" }] }, 3, "transit"), []);
  assert.equal(parseDecision('```json\n{"search":true,"query":"  topic  "}\n```'), "topic");
  assert.equal(parseDecision('{"search":false}'), null);
  assert.throws(() => parseDecision("probably search"));
});
test("conversation limit and provider bookmarks round trip without persisting secrets in session-only mode", () => {
  assert.deepEqual(budgetFrom(null), { limit: 10, used: 0 });
  for (const v of [9, 51, 12.4])
    assert.throws(() => budgetFrom(JSON.stringify({ limit: v, used: 0 })));
  assert.throws(() => available({ limit: 50, used: 50 }));
  const names = namedProvider({}, custom + "/chat/completions", "Work");
  assert.deepEqual(names, { [custom]: "Work" });
  assert.throws(() => namedProvider(names, "https://second.example.org/v1", "Work"));
  assert.throws(() => namedProvider({}, or, "Other"));
  assert.deepEqual(restoreProviders({ ...names, broken: 42 }), names);
  const dev = restoreDevice({ search: cfg, customProviders: names });
  assert.equal(deviceForDisk(dev).search?.apiKey, cfg.apiKey);
  assert.equal(deviceForDisk({ ...dev, rememberKeys: false }).search?.apiKey, undefined);
  assert.deepEqual(deviceForDisk({ ...dev, rememberKeys: false }).customProviders, names);
});
