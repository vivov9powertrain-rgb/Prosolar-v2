// Run against a local build only. Synthetic, in-browser provider; no key or charges.
import assert from "node:assert/strict";
import { chromium } from "playwright";
const base = process.env.SOL_LOCAL_TEST_URL || "http://127.0.0.1:8081";
if (!["localhost", "127.0.0.1"].includes(new URL(base).hostname))
  throw Error("Use a local preview.");
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
const page = await context.newPage();
page.setDefaultTimeout(7000);
const errors = [];
page.on("pageerror", (err) => errors.push(String(err)));
await context.route("**/*", (route) =>
  new URL(route.request().url()).origin === new URL(base).origin ? route.continue() : route.abort(),
);
await context.addInitScript(() => {
  window.fixtureBodies = [];
  const original = window.fetch.bind(window);
  window.fetch = async (url, init) => {
    if (String(url) === "https://openrouter.ai/api/v1/models")
      return Response.json({ data: [{ id: "openai/gpt-5.4-mini" }] });
    if (String(url) !== "https://openrouter.ai/api/v1/chat/completions") return original(url, init);
    const body = JSON.parse(init.body);
    window.fixtureBodies.push(body);
    const citations = [
      {
        type: "url_citation",
        url_citation: { url: "https://example.org/paper", title: "Source paper" },
      },
      {
        type: "url_citation",
        url_citation: { url: "https://example.org/paper", title: "Duplicate" },
      },
    ];
    const md =
      "## Report\n\n- First point\n- Second point\n\n| Column | Value |\n| --- | --- |\n| A | 12 |\n\n```js\nconst n = 12;\n```\n\n[Read more](https://example.org/paper)";
    if (!body.stream)
      return Response.json({
        choices: [{ message: { content: md, annotations: citations }, finish_reason: "stop" }],
      });
    const encoder = new TextEncoder();
    const signal = init.signal;
    return new Response(
      new ReadableStream({
        start(c) {
          const send = (v) =>
            c.enqueue(encoder.encode("data: " + JSON.stringify({ choices: [v] }) + "\n\n"));
          send({ delta: { reasoning: "private fixture" } });
          send({ delta: { content: "## Live heading\n\n" } });
          let id = setTimeout(() => {
            send({
              delta: { content: "Last token.", annotations: citations },
              finish_reason: "stop",
            });
            c.enqueue(encoder.encode("data: [DONE]"));
            c.close();
            signal.removeEventListener("abort", abort);
          }, 1200);
          const abort = () => {
            clearTimeout(id);
            c.error(new DOMException("Stopped", "AbortError"));
          };
          signal.addEventListener("abort", abort, { once: true });
        },
      }),
      { headers: { "content-type": "text/event-stream" } },
    );
  };
});
try {
  await page.goto(base);
  await page.getByRole("heading", { name: "Start a conversation." }).waitFor();
  assert.equal(await page.title(), "sol");
  assert.deepEqual(
    await page.evaluate(() => JSON.parse(localStorage.getItem("hearth-v1")).state.characters),
    [],
  );
  const button = (n) => page.getByRole("button", { name: n, exact: true });
  assert.equal(await button("High reasoning").isDisabled(), false);
  assert.equal(await button("Streaming").getAttribute("aria-pressed"), "true");
  await button("Connection settings").click();
  await page.getByRole("combobox", { name: "Provider", exact: true }).selectOption("openrouter");
  await page.getByLabel("API key", { exact: true }).fill("local-fixture-only");
  await button("Close").click();
  await button("High reasoning").click();
  await button("Use 4,096 tokens").click();
  await button("Web search").click();
  await button("Streaming").click();
  const picker = page.getByLabel("Files to attach");
  await picker.setInputFiles({
    name: "bad.zip",
    mimeType: "application/zip",
    buffer: Buffer.from("not accepted"),
  });
  await page.getByRole("alert").filter({ hasText: "Unsupported file" }).waitFor();
  await picker.setInputFiles([
    { name: "notes.txt", mimeType: "text/plain", buffer: Buffer.from("fixture-only notes") },
    {
      name: "paper.pdf",
      mimeType: "application/pdf",
      buffer: Buffer.from("%PDF-1.4\nfixture\n%%EOF"),
    },
    {
      name: "pixel.png",
      mimeType: "image/png",
      buffer: Buffer.from(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jSv0AAAAASUVORK5CYII=",
        "base64",
      ),
    },
  ]);
  await button("Remove notes.txt").waitFor();
  await button("Send").click();
  await page.getByRole("heading", { name: "Report", exact: true }).waitFor();
  const first = await page.evaluate(() => window.fixtureBodies[0]);
  assert.equal(first.stream, false);
  assert.equal(first.reasoning.effort, "high");
  assert.equal(first.max_tokens, 4096);
  assert.deepEqual(
    first.plugins.map((p) => p.id),
    ["web", "file-parser"],
  );
  assert.deepEqual(
    first.messages.at(-1).content.map((p) => p.type),
    ["text", "text", "file", "image_url"],
  );
  assert.equal(first.messages.at(-1).content[1].text.includes("fixture-only notes"), true);
  assert.equal(await page.getByRole("table").count(), 1);
  assert.equal(await page.locator("pre code").textContent(), "const n = 12;\n");
  assert.equal(await page.getByRole("link", { name: "Source paper" }).count(), 1);
  assert.equal(
    await page.evaluate(() => localStorage.getItem("hearth-v1").includes("base64,")),
    false,
  );
  await page.reload();
  await button("Streaming").waitFor();
  assert.equal(await button("High reasoning").getAttribute("aria-pressed"), "true");
  assert.equal(await button("Streaming").getAttribute("aria-pressed"), "false");
  await button("Streaming").click();
  await button("Web search").click();
  await page.getByRole("textbox", { name: "Message", exact: true }).fill("Follow up");
  await button("Send").click();
  await page.getByRole("heading", { name: "Live heading", exact: true }).waitFor();
  await button("Stop").waitFor();
  assert.equal(await page.getByText("private fixture", { exact: true }).count(), 0);
  await page.getByText("Last token.", { exact: true }).waitFor();
  const next = await page.evaluate(() => window.fixtureBodies[0]);
  assert.equal(next.stream, true);
  assert.deepEqual(
    next.plugins.map((p) => p.id),
    ["file-parser"],
  );
  assert.ok(
    next.messages.some(
      (m) => Array.isArray(m.content) && m.content.some((p) => p.type === "image_url"),
    ),
  );
  await page.getByRole("textbox", { name: "Message", exact: true }).fill("Stop this one");
  await button("Send").click();
  await page.getByRole("heading", { name: "Live heading", exact: true }).nth(1).waitFor();
  await button("Stop").click();
  await button("Stop").waitFor({ state: "hidden" });
  assert.equal(await page.getByText("Last token.", { exact: true }).count(), 1);
  assert.equal(
    await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
    true,
  );
  assert.deepEqual(errors, []);
  console.log(
    "PASS: mobile chat, settings, toggles, validation, file-only send, binary/text payloads, Markdown, citations, reload/follow-up, incremental streaming, stop and no overflow.",
  );
} finally {
  await browser.close();
}
