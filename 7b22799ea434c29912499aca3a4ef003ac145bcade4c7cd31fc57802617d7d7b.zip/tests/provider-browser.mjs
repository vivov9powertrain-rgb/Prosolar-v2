// Local Playwright fixtures only. Each provider gets a different made-up credential.
import assert from "node:assert/strict";
import { chromium } from "playwright";
const site = new URL(process.env.SOL_LOCAL_TEST_URL || "http://127.0.0.1:8081");
if (!["localhost", "127.0.0.1"].includes(site.hostname)) throw Error("Use a local preview");
const or = "https://openrouter.ai/api/v1",
  nv = "https://integrate.api.nvidia.com/v1",
  g = "https://generativelanguage.googleapis.com/v1beta/openai",
  z = "https://api.z.ai/api/paas/v4",
  custom = "https://provider.example.org/workspace/a/v1",
  other = custom.replace("/a/", "/b/");
const keys = {
  [or]: "fixture-router-only",
  [nv]: "fixture-nvidia-only",
  [g]: "fixture-gemini-only",
  [z]: "fixture-zai-only",
  [custom]: "fixture-custom-A",
  [other]: "fixture-custom-B",
};
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
const page = await ctx.newPage();
page.setDefaultTimeout(8000);
const calls = [],
  violations = [],
  errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const routerIDs = [
  "router/legacy",
  "router/chosen",
  ...Array.from({ length: 28 }, (_, i) => "router/variant-" + (i + 1)),
];
let releaseSlow,
  startSlow,
  slow = false;
await ctx.addInitScript(
  ({ origin, or, key }) => {
    if (location.origin !== origin || localStorage.getItem("hearth-v1")) return;
    localStorage.setItem(
      "hearth-v1",
      JSON.stringify({
        version: 0,
        state: {
          characters: [],
          threads: [],
          activeThreadId: null,
          settings: {
            provider: "openrouter",
            baseUrl: or + "/chat/completions",
            apiKey: key,
            model: "router/legacy",
            streaming: false,
            userName: "Existing user",
          },
        },
      }),
    );
  },
  { origin: site.origin, or, key: keys[or] },
);
await ctx.route("**/*", async (route) => {
  const req = route.request(),
    url = new URL(req.url());
  let target, kind, body;
  if (url.origin === site.origin) {
    if (url.pathname !== "/api/chat") return route.continue();
    body = req.postDataJSON();
    target = body.baseUrl;
    kind = body.probe === "models" ? "models" : "chat";
  } else if (url.origin === new URL(or).origin && url.pathname === "/api/v1/models") {
    target = or;
    kind = "models";
  } else {
    violations.push(`unexpected external ${url.origin}${url.pathname}`);
    return route.abort();
  }
  const auth = req.headers().authorization || "";
  calls.push({ target, kind, auth, body });
  if (
    !Object.hasOwn(keys, target) ||
    (auth &&
      auth !== "Bearer " + keys[target] &&
      !(target === g && auth === "Bearer fixture-rejected"))
  )
    violations.push("credential sent to wrong endpoint: " + target);
  for (const key of Object.values(keys))
    if ((req.postData() ?? "").includes(key) || req.url().includes(key))
      violations.push("credential found in URL or body");
  const reply = (status, json) =>
    route.fulfill({
      status,
      headers: {
        "X-Sol-Relay": "1",
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": site.origin,
      },
      body: JSON.stringify(json),
    });
  if (kind === "models") {
    if (target === g && slow) {
      slow = false;
      startSlow?.();
      await new Promise((resolve) => {
        releaseSlow = resolve;
      });
    }
    if (auth === "Bearer fixture-rejected")
      return reply(401, { error: { message: "Invalid test credential" } });
    if (![or, nv].includes(target) && !auth) violations.push("missing credential: " + target);
    if ([custom, other, z].includes(target))
      return reply(405, { error: { message: "Unsupported model list" } });
    const ids =
      target === or
        ? routerIDs
        : target === nv
          ? ["nvidia/another-chat", "google/gemma-3-12b-it"]
          : ["models/gemini-2.5-pro", "models/gemini-3.5-flash", "models/gemini-3.5-flash"];
    return reply(200, { data: ids.map((id) => ({ id })) }).catch((e) => {
      if (!req.failure()) throw e;
    });
  }
  if (auth !== "Bearer " + keys[target]) violations.push("chat did not carry the correct key");
  if (target === z) return reply(401, { error: { message: "Provider rejected this test key" } });
  return reply(200, {
    choices: [{ message: { content: "Fixture answer for " + body.model }, finish_reason: "stop" }],
  });
});
try {
  const btn = (n) => page.getByRole("button", { name: n, exact: true }),
    field = (n) => page.getByLabel(n, { exact: true });
  const prov = page.getByRole("combobox", { name: "Provider", exact: true }),
    model = field("Model"),
    key = field("API key"),
    url = field("Base URL"),
    status = page.getByRole("dialog").getByRole("status");
  const open = () => btn("Connection settings").click(),
    close = () => btn("Close").click(),
    select = (p) => prov.selectOption(p);
  const got = (id) =>
    model.locator("option").filter({ hasText: id }).first().waitFor({ state: "attached" });
  const setUrl = async (base) => {
    await url.fill(base);
    await url.press("Enter");
  };
  const disk = () => page.evaluate(() => JSON.parse(localStorage.getItem("hearth-v1")));
  const send = async (msg) => {
    await field("Message").fill(msg);
    await btn("Send").click();
  };
  await page.goto(site.href);
  await page.getByRole("heading", { name: "Start a conversation." }).waitFor();
  await open();
  await got("router/chosen");
  assert.equal(await key.inputValue(), keys[or]);
  assert.equal(await model.inputValue(), "id:router/legacy");
  assert.equal((await disk()).version, 1);
  assert.equal(await field("Your name").inputValue(), "Existing user");
  await field("Filter models").fill("chosen");
  assert.equal(await model.locator("option").filter({ hasText: "variant-22" }).count(), 0);
  await model.selectOption({ label: "router/chosen" });
  assert.ok(calls.some((c) => c.target === or && c.kind === "models" && c.auth === ""));
  assert.equal((await disk()).state.settings.apiKey, undefined);
  await select("nvidia");
  await got("nvidia/another-chat");
  assert.equal(await key.inputValue(), "");
  assert.equal(await model.inputValue(), "id:google/gemma-3-12b-it");
  await key.fill(keys[nv]);
  await model.selectOption({ label: "nvidia/another-chat" });
  await setUrl(nv + "/chat/completions/");
  assert.equal(await key.inputValue(), keys[nv]);
  assert.equal(await model.inputValue(), "id:nvidia/another-chat");
  assert.ok(calls.some((c) => c.target === nv && c.kind === "models" && !c.auth));
  await btn("Test connection").click();
  await page.getByText(/Model list reachable \(2\)/).waitFor();
  await select("google");
  await status.filter({ hasText: "Enter this provider’s API key" }).waitFor();
  assert.equal(await key.inputValue(), "");
  assert.equal(await url.inputValue(), g);
  assert.equal(calls.filter((c) => c.target === g).length, 0);
  await key.fill("fixture-rejected");
  await status.filter({ hasText: "HTTP 401" }).waitFor();
  await key.fill(keys[g]);
  await got("gemini-2.5-pro");
  assert.equal(await model.inputValue(), "id:gemini-3.5-flash");
  await model.selectOption({ label: "gemini-2.5-pro" });
  await close();
  await send("Google chat fixture");
  await page.getByText("Fixture answer for gemini-2.5-pro", { exact: true }).waitFor();
  assert.ok(
    calls.some(
      (c) =>
        c.target === g &&
        c.kind === "chat" &&
        c.auth === "Bearer " + keys[g] &&
        c.body.model === "gemini-2.5-pro",
    ),
  );
  await page.reload();
  await open();
  await got("gemini-3.5-flash");
  assert.equal(await key.inputValue(), keys[g]);
  assert.equal(await model.inputValue(), "id:gemini-2.5-pro");
  await select("openrouter");
  await got("router/legacy");
  assert.equal(await key.inputValue(), keys[or]);
  assert.equal(await model.inputValue(), "id:router/chosen");
  await select("google");
  await got("gemini-3.5-flash");
  slow = true;
  const started = new Promise((resolve) => {
    startSlow = resolve;
  });
  await btn("Refresh models").click();
  await started;
  await select("nvidia");
  await got("nvidia/another-chat");
  releaseSlow?.();
  assert.equal(await model.inputValue(), "id:nvidia/another-chat");
  assert.equal(await key.inputValue(), keys[nv]);
  assert.equal(await model.locator("option").filter({ hasText: "gemini-2.5-pro" }).count(), 0);
  await select("custom");
  assert.equal(await key.inputValue(), "");
  await setUrl(custom + "/chat/completions");
  await key.fill(keys[custom]);
  await status.filter({ hasText: "does not expose a model list" }).waitFor();
  await field("Manual model ID").fill("custom/chat");
  await close();
  await send("Custom fixture");
  await page.getByText("Fixture answer for custom/chat", { exact: true }).waitFor();
  await open();
  await setUrl(other);
  assert.equal(await key.inputValue(), "");
  await key.fill(keys[other]);
  await setUrl(custom + "/models");
  assert.equal(await key.inputValue(), keys[custom]);
  assert.equal(await model.inputValue(), "id:custom/chat");
  await setUrl(z + "/chat/completions");
  assert.equal(await prov.inputValue(), "zai");
  assert.equal(await key.inputValue(), "");
  await key.fill(keys[z]);
  await close();
  await send("Invalid Z.ai fixture");
  await page.getByRole("alert").filter({ hasText: "HTTP 401" }).waitFor();
  await open();
  await select("custom");
  assert.equal(await url.inputValue(), custom);
  assert.equal(await key.inputValue(), keys[custom]);
  await select("google");
  await btn("Forget key").click();
  await status.filter({ hasText: "Enter this provider’s API key" }).waitFor();
  assert.ok(!JSON.stringify(await disk()).includes(keys[g]));
  await select("openrouter");
  assert.equal(await key.inputValue(), keys[or]);
  await select("google");
  assert.equal(await key.inputValue(), "");
  await select("nvidia");
  assert.equal(await key.inputValue(), keys[nv]);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await field("Remember keys on this device").uncheck();
  const saved = JSON.stringify(await disk());
  for (const value of Object.values(keys)) assert.ok(!saved.includes(value));
  assert.equal(await key.inputValue(), keys[nv]);
  await page.reload();
  await open();
  assert.equal(await key.inputValue(), "");
  assert.equal(await model.inputValue(), "id:nvidia/another-chat");
  await select("openrouter");
  assert.equal(await key.inputValue(), "");
  assert.equal(await model.inputValue(), "id:router/chosen");
  assert.deepEqual(violations, []);
  assert.deepEqual(errors, []);
  console.log(
    "PASS: legacy key migration; independent key/model recall across switches and reload; public/authenticated catalogs, filter, auto-selection, refresh and stale results; Google/NVIDIA/Custom/Z.ai routes, chat and 401s; forget key and session-only storage.",
  );
} finally {
  releaseSlow?.();
  await browser.close();
}
